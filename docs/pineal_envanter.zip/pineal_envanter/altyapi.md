# ALTYAPI VE DAĞITIM — konteyner, CI, sürümleme, betikler

## 1) Dockerfile

- WORKDIR /app/frontend
- COPY frontend/package.json frontend/package-lock.json ./
- RUN npm ci --no-audit --no-fund
- COPY frontend/ ./
- RUN npm run build
- RUN apt-get update && apt-get install -y --no-install-recommends \
- WORKDIR /app
- COPY requirements.lock ./
- RUN pip install --default-timeout=300 -r requirements.lock
- RUN pip install --default-timeout=120 "websockets==17.1"
- RUN PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT=300000 python -m playwright install --with-deps chromium || \
- COPY backend/ ./backend/
- COPY agent_core/ ./agent_core/
- COPY config/ ./config/
- COPY main.py scraper.py ./
- COPY --from=frontend /app/frontend/dist ./frontend/dist
- RUN mkdir -p /app/memory /app/cache
- EXPOSE 8000
- HEALTHCHECK --interval=30s --timeout=5s --start-period=15s \
- CMD ["sh", "-c", "uvicorn backend.api:app --host 0.0.0.0 --port ${PORT:-${PINEAL_PORT:-8000}}"]

## 2) docker-compose.yml servisleri

| Servis | Rol (ölçüldü) |
|---|---|
| `redis` | olay veri yolu (pub/sub) |
| `pineal` | API + arayüz konteyneri |
| `beacon-mirror-truth` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-autonomous-verifier` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-human-behavior` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-passion-mapper` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-friction-detector` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-cognitive-profiler` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-resonance-calculator` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-pattern-interrupt` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-osint-investigator` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-authenticity-auditor` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-depth-analyst` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `beacon-resonance-synthesizer` | canlılık işaretçisi (liveness beacon) — ANALİZ YÜRÜTMEZ |
| `pineal_memory` | veri hacmi |
| `pineal_cache` | veri hacmi |
| `pineal_vault` | veri hacmi |
| `pineal_redis` | veri hacmi |

## 3) CI iş akışları

### `.github/workflows/ci.yml` — “CI”
- İşler: push, pull_request, backend, frontend, smoke, rust-core, android | Adım sayısı: 24
  - Install dependencies (requirements.lock = production image tree)
  - Lint with ruff
  - Run backend tests with coverage gate
  - Audit regression guard (E0 — 24 denetim bulgusu makine bekçisinde)
  - Verify routing shadows committed fresh
  - Verify inventory page committed fresh
  - Verify skills package committed fresh
  - Verify provider catalog contract (OpenRouter + Nous)
  - Install dependencies
  - Check Svelte types
  - Build frontend
  - Verify real Svelte build
  - Install Python dependencies (requirements.lock)
  - Build frontend (so smoke tests the real dist)
  - uvicorn smoke
  - MCP stdio handshake smoke
  - Cargo check (core, no tauri feature)
  - Cargo test

### `.github/workflows/preflight.yml` — “9Router Preflight Verification”
- İşler: schedule, workflow_dispatch, preflight-probe | Adım sayısı: 4
  - Checkout Repository
  - Set up Python
  - Install Dependencies
  - Execute 9Router Preflight Probe

### `.github/workflows/release-gates.yml` — “Release Gates”
- İşler: workflow_dispatch, live-llm-e2e, docker-chromium-smoke | Adım sayısı: 11
  - Install dependencies (Dockerfile ile aynı deterministik lock)
  - Fail-closed secret kontrolu
  - Canli LLM E2E gate (docs/reports/RELEASE_EVIDENCE Bölüm 8 kriterleri)
  - .env hazirla (production fail-closed auth icin)
  - Imaji build et ve kaldir (gerçek compose paketi)
  - Health bekle (ready|degraded → HTTP 200)
  - UI servis kontrolu (gerçek Svelte dist imajda)
  - Production auth kontrolu (401 → 200)
  - Konteyner ici Chromium smoke (Playwright launch + page.goto)
  - Tani (kopus durumunda loglar)
  - Temizle (volume'lar dahil)

## 4) Sürüm ve sürüm kapıları

- `VERSION` = `3.0.0-rc.2` (tek kaynak; Python/npm/Cargo/Tauri buradan okur)
- `release/3.0.0-rc.1.json` (30 satır)
- `release/3.0.0-rc.2.json` (84 satır)
- `release/release-gates.yml` (117 satır)

## 5) Betikler (shell/ps1/bat)

- `android/gradlew.bat` (94 satır): Bu dosya Android istemcisine ait (Kotlin/Compose). Komutlar: echo, exit, goto, if, set.
- `baslat.bat` (76 satır): Bu dosya depo kökünde çalıştırılan bir kabuk/başlatma betiği. Komutlar: call, cd, curl, echo, exit, goto, if, npm, pip, python.
- `scripts/backup_restore.sh` (154 satır): Bu dosya bir BETİK: elle veya CI'da çalıştırılan denetim/kurulum/doğrulama işi yapar. Komutlar: bash, cd, docker, echo, exit, if, set.
- `scripts/test_disaster_recovery.ps1` (46 satır): Bu dosya bir BETİK: elle veya CI'da çalıştırılan denetim/kurulum/doğrulama işi yapar. Komutlar: docker, echo, exit, if.
- `scripts/test_disaster_recovery.sh` (138 satır): Bu dosya bir BETİK: elle veya CI'da çalıştırılan denetim/kurulum/doğrulama işi yapar. Komutlar: bash, cd, docker, echo, exit, if, set, timeout.