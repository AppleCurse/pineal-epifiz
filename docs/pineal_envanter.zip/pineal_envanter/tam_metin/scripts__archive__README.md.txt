# DOSYA: scripts/archive/README.md
# SATIR: 20 | SHA-256: 1932ef2d7da4daab88a11b19fe28bf902771b22e83a4ff9f4a4fb51ccce86aa3 | TÜR: md
# Biçim: satırno|tür|içerik

01|metin    |# scripts/archive — tek seferlik prob/deneme scriptleri
02|boş      |
03|metin    |Bu dizindeki scriptler **üretim akışında, CI'da ve test paketinde kullanılmaz**
04|metin    |(`pytest.ini: testpaths = tests`). Tarihsel kanıt/deneme amaçlı saklanır:
05|boş      |
06|metin    || Script | Ne idi |
07|metin    ||---|---|
08|metin    || `analyze_target_instagram.py` | tek-profil canlı demo (Chrome ister) |
09|metin    || `benchmark_download.py` | indirme kıyaslaması |
10|metin    || `e2e_test.py` | elle çalıştırılan canlı LLM provası |
11|metin    || `flow_roentgen.py` | akış röntgeni ölçüm aracı (`docs/reports/AKIS_RONTGENI_2026-09-21.md`) |
12|metin    || `live_provider_probe.py` | canlı sağlayıcı probu |
13|metin    || `test_e2e_fixture.py` | uçtan uca prova (canlı) |
14|metin    || `test_live_holistic.py` | bütüncül canlı çözümleme (canlı) |
15|metin    || `ws_leak_probe.py` | WS sızıntı probu (`docs/ZERO_TRUST_VERIFICATION_2026-09-18.md`) |
16|boş      |
17|metin    |Aktif operasyonel scriptler bir üst dizinde kalır: `run_task.py`,
18|metin    |`generate_routing_shadows.py`, `verify_openrouter_catalog.py`,
19|metin    |`preflight_9router.py`, `smoke_test_browser.py`, `backup_restore.sh`,
20|metin    |`test_disaster_recovery.sh/.ps1`.
