# DOSYA: frontend/README.md
# SATIR: 47 | SHA-256: 2846a9d94ccb90e4ac8016686f7137ebb08480aed2e2f6f9f185a28ce0016469 | TÜR: md
# Biçim: satırno|tür|içerik

01|metin    |# Svelte + TS + Vite
02|boş      |
03|metin    |This template should help get you started developing with Svelte and TypeScript in Vite.
04|boş      |
05|metin    |## Recommended IDE Setup
06|boş      |
07|metin    |[VS Code](https://code.visualstudio.com/) + [Svelte](https://marketplace.visualstudio.com/items?itemName=svelte.svelte-vscode).
08|boş      |
09|metin    |## Need an official Svelte framework?
10|boş      |
11|metin    |Check out [SvelteKit](https://github.com/sveltejs/kit#readme), which is also powered by Vite. Deploy anywhere with its serverless-first approach and adapt to various platforms, with out of the box support for TypeScript, SCSS, and Less, and easily-added support for mdsvex, GraphQL, PostCSS, Tailwind CSS, and more.
12|boş      |
13|metin    |## Technical considerations
14|boş      |
15|metin    |**Why use this over SvelteKit?**
16|boş      |
17|metin    |- It brings its own routing solution which might not be preferable for some users.
18|metin    |- It is first and foremost a framework that just happens to use Vite under the hood, not a Vite app.
19|boş      |
20|metin    |This template contains as little as possible to get started with Vite + TypeScript + Svelte, while taking into account the developer experience with regards to HMR and intellisense. It demonstrates capabilities on par with the other `create-vite` templates and is a good starting point for beginners dipping their toes into a Vite + Svelte project.
21|boş      |
22|metin    |Should you later need the extended capabilities and extensibility provided by SvelteKit, the template has been structured similarly to SvelteKit so that it is easy to migrate.
23|boş      |
24|metin    |**Why `global.d.ts` instead of `compilerOptions.types` inside `jsconfig.json` or `tsconfig.json`?**
25|boş      |
26|metin    |Setting `compilerOptions.types` shuts out all other types not explicitly listed in the configuration. Using triple-slash references keeps the default TypeScript setting of accepting type information from the entire workspace, while also adding `svelte` and `vite/client` type information.
27|boş      |
28|metin    |**Why include `.vscode/extensions.json`?**
29|boş      |
30|metin    |Other templates indirectly recommend extensions via the README, but this file allows VS Code to prompt the user to install the recommended extension upon opening the project.
31|boş      |
32|metin    |**Why enable `allowJs` in the TS template?**
33|boş      |
34|metin    |While `allowJs: false` would indeed prevent the use of `.js` files in the project, it does not prevent the use of JavaScript syntax in `.svelte` files. In addition, it would force `checkJs: false`, bringing the worst of both worlds: not being able to guarantee the entire codebase is TypeScript, and also having worse typechecking for the existing JavaScript. In addition, there are valid use cases in which a mixed codebase may be relevant.
35|boş      |
36|metin    |**Why is HMR not preserving my local component state?**
37|boş      |
38|metin    |HMR state preservation comes with a number of gotchas! It has been disabled by default in both `svelte-hmr` and `@sveltejs/vite-plugin-svelte` due to its often surprising behavior. You can read the details [here](https://github.com/rixo/svelte-hmr#svelte-hmr).
39|boş      |
40|metin    |If you have state that's important to retain within a component, consider creating an external store which would not be replaced by HMR.
41|boş      |
42|metin    |```ts
43|metin    |// store.ts
44|metin    |// An extremely simple external store
45|metin    |import { writable } from 'svelte/store'
46|metin    |export default writable(0)
47|metin    |```
