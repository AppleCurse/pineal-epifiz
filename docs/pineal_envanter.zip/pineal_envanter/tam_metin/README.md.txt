# DOSYA: README.md
# SATIR: 231 | SHA-256: 4400c7757803b04a993a1859f2b3162874fb6d539fbfee2177a367858c4abb4a | TÜR: md
# Biçim: satırno|tür|içerik

001|metin    |# PINEAL-HERETIC (İçgörü Asistanı)
002|boş      |
003|metin    |Merhaba! Pineal-Heretic, sosyal medya (özellikle Instagram ve X) üzerindeki herkese açık profilleri inceleyen, gördüklerini sizin yerinize "insani bir gözle" okuyup analiz eden akıllı bir asistandır.
004|boş      |
005|metin    |Bu program **kesinlikle bir hacker aracı değildir**, şifre kırmaz veya gizli hesaplara sızmaz. Sadece internetteki herkese açık resimleri, yazıları ve paylaşım saatlerini alır, tıpkı sizin günlerce ekrana bakarak yapacağınız gibi okur, ancak bunu saniyeler içinde yaparak size anlaşılır, dürüst bir "profil özeti" sunar.
006|metin    |---
007|boş      |
008|metin    |```
009|metin    |                       ╔═══════════════════════════════════════════╗
010|metin    |                       ║        P I N E A L   E P İ F İ Z          ║
011|metin    |                       ║       v5.1 ADLİ BİLİŞSEL İSTASYON         ║
012|metin    |                       ╚═══════════════════════════════════════════╝
013|boş      |
014|metin    |    [ 🌐 ÇOK KANALLI OSINT ]       [ 🧠 7 MATEMATİKSEL DALGA MOTORU ]       [ 👁️ ATLAS GÖZLEMEVİ ]
015|metin    |   Instagram · LinkedIn · X/Web       Frequency · Seismos · Void                 %12.2 Pirinç Halka
016|metin    |   Tavily · Exa · SerpAPI             Strata · Gravity · Pulse · Key             Organik Yaşayan Göz
017|metin    |               │                                      │                                  │
018|metin    |               └──────────────────────┬───────────────┴──────────────────────────────────┘
019|metin    |                                      │
020|metin    |                         [ ⚡ 12 UZMAN ANALİZ ROLÜ ]
021|metin    |                  Orkestratör süreç içinde yürütür · Canlı Rack
022|metin    |                                      │
023|metin    |                         [ ⚔️ TAKTİK MUHAREBE MASASI ]
024|metin    |                       100% Şeffaf Adli Teftiş & Kara Kutu
025|metin    |                                      │
026|metin    |                   [ 🛡️ ÇOKLU SAĞLAYICI LLM GÜVENLİK HAVUZU ]
027|metin    |               9Router Local Hub + Google Gemini + Groq + DeepSeek
028|metin    |```
029|boş      |
030|metin    |---
031|boş      |
032|metin    |## 1. Pineal Epifiz Nedir? (Felsefe ve Çekirdek Mantık)
033|boş      |
034|metin    |Pineal (Epifiz bezi); biyolojide ışığı, sirkadiyen döngüleri ve görünmeyen zaman frekanslarını algılayan, insan bedeninin ana saat kulesidir. 
035|boş      |
036|metin    |**PINEAL-HERETIC**, bu biyolojik ilkeyi dijital adli tıbba uyarlar:
037|metin    |Bir hedefin açık kaynaklı dijital ayak izlerini (sosyal paylaşımları, metinlerini, fotoğraflarını, zamansal etkileşim ritimlerini) toplayan, bunları **yapay zekaya asla fal baktırmadan**, saf matematiksel dalga motorlarıyla analiz eden **yerel bir adli psikodinamik profil ve rezonans istasyonudur**.
038|boş      |
039|metin    |### Sistemin 4 Dokunulmaz İlkesi:
040|metin    |> **Tüzük:** bu ilkeler artık [`docs/PINEAL_TUZUK.md`](docs/PINEAL_TUZUK.md) v2 içinde **Madde 1–4** olarak yaşar (2026-10-05). İlkeler değişmedi; bağlamı büyüdü: uyum/ilk temas artık sistemin tanımı değil, **kullanım sahalarından biridir** (tüzük Madde 0 ve Madde 9). Aşağıdaki dört ilke, tüzüğün kısa okumasıdır.
041|metin    |1. **LLM'ler Falcı Değildir:** Karakter analizi, bastırılmış narsisizm veya derin travmalar LLM'lere "tahmin ettirilmez". 7 adet saf matematiksel dalga motoru metin ve zaman serisini doğrudan fizik/istatistik formülleriyle ölçer. LLM'ler yalnızca en son aşamada dil sentezi, diyalog tasarımı ve çapraz denetim için kullanılır.
042|metin    |2. **Kanıt Mührü (Fail-Closed):** Verisi veya kanıtı olmayan hiçbir iddia üretilemez (`InsufficientEvidenceError`). Sistem boşlukları sallayarak doldurmaz; veri yoksa o kanalı dürüstçe kapatır veya işlemi durdurur.
043|metin    |3. **100% Şeffaflık & Sıfır Sahte Simülasyon:** Arayüzde rastgele yanan sahte LED'ler veya yapay zamanlayıcılar (`demoMode`) kesinlikle bulunmaz. Ekranda görülen her durum, güven puanı ve log, doğrudan FastAPI WebSocket, Redis Pub/Sub ve Tauri IPC'den akan gerçek telemetridir.
044|metin    |4. **Kasa (Vault Interlock) Koruması:** Fiziksel anahtar mandalı kilitliyken (`vault_locked: true`), dış dünyaya tek bir OSINT veya scraper isteği çıkamaz. Operatör mandalı çevirmeden dış ağa erişim imkansızdır.
045|boş      |
046|metin    |---
047|boş      |
048|metin    |## 2. Çift Modlu Taktik Komuta Arayüzü (v5.1 Mimarisi)
049|boş      |
050|metin    |> Router tüm ajanları zorunlu sırayla çalıştırmaz. Diyagram, koşullu dalları özetler. Yedi pillar motorunun kendi hesaplamaları LLM çağrısı yapmaz; deterministik kod hesaplarıdır. Sonuçları yine de betimleyici/heuristik kaynak ölçümleridir, psikometrik test değildir.
051|boş      |
052|metin    |PINEAL-HERETIC v5.1, operatöre hem derin sinematik sezgi hem de cerrahi şeffaflık sunan **çift modlu (Dual-Mode)** bir komuta köprüsü ile donatılmıştır. İki mod arasında sağ üstteki hap butondan anında geçiş yapılır ve tercih tarayıcıda (`localStorage.pineal_view_mode`) saklanır.
053|boş      |
054|metin    |### MOD 1: Atlas Epifiz Gözlemevi (`AtlasPinealCockpit.svelte`)
055|metin    |*Kayıpsız 16:9 Master Şasi Üzerinde Yaşayan Epifiz Gözü ve Sokratik Terminal.*
056|boş      |
057|metin    |- **Orijinal %12.2 Pirinç Yuvalı Yaşayan Organik Göz:**
058|metin    |  - Pirinç yuva içinde yaşayan organik epifiz gözü (`living_pineal_disk.png`).
059|metin    |  - Operatörün fare hareketini nazikçe takip eder, arka planda organik drift (`Math.sin`/`Math.cos`) ve operasyon anında hafif bilişsel titreşim (`processingFlutter`) sergiler.
060|metin    |- **Holografik Rezonans Ağı (`HolographicResonanceMesh.svelte`):**
061|metin    |  - Pirinç yuva arkasında dönen üç boyutlu matematiksel tel kafes. Sistem yüküne ve rezonans şiddetine göre form değiştirir.
062|metin    |- **Aspasia Canlı CRT Konsolu (`/api/aspasia/chat`):**
063|metin    |  - Sol alt güvertedeki retro monokrom CRT ekranı. Aspasia üst akıl denetçisiyle doğrudan canlı Sokratik diyalog kurulmasını sağlar.
064|metin    |- **Kasa Güvenlik Mandalı (Vault LED):**
065|metin    |  - Sol alttaki interaktif mandal. Yeşil (`OPEN`) ve kırmızı (`VAULT LOCKED`) durumları arasında anında kilit değiştirir (`POST /api/vault/status`).
066|metin    |- **Canlı Agent Rack Yuvası (`AgentRack.svelte`):**
067|metin    |  - Sağ taraftan açılıp kapanabilen 12 rollü analiz rack'i. Buradaki herhangi bir ajana tıklandığında sistem otomatik olarak Muharebe Masası'na geçer ve o ajanı doğrudan röntgene alır.
068|boş      |
069|metin    |---
070|boş      |
071|metin    |### MOD 2: Taktik Muharebe Masası (`TacticalWarRoom.svelte`)
072|metin    |*100% Şeffaf, Gerçek Zamanlı Adli Teftiş ve Müdahale Güvertesi.*
073|boş      |
074|metin    |1. **12 Rol Kumanda Matrisi (Sol Kolon):**
075|metin    |   - 12 ajanın tamamını anlık durum pilleriyle (`ACTIVE`, `DONE`, `HALTED`, `WAIT`) gösterir.
076|metin    |   - Her ajanın gerçek zamanlı güven barı ve o anda ne yaptığına dair Türkçe operasyonel adım kartları (örn: *"LinkedIn ve Instagram profilleri bağlandı"*, *"3 jürili panelce incelendi"*).
077|metin    |2. **Hedef & Açık Kanıt Radarı (Orta Kolon):**
078|metin    |   - **Tespit Edilen Sosyal Profiller:** Instagram, LinkedIn, X, web siteleri tıklanabilir çipler olarak anında listelenir.
079|metin    |   - **Kişilik Özü Kartı & İlk Temas Köprüsü:** Tespit edilen öz-frekans ve hedefe yönelik sahici açılış mesajı.
080|metin    |   - **Açık Kaynak Kanıt Snippet'ları:** Web taramasından gelen ham metin parçacıkları.
081|metin    |3. **Derin Adli Ajan Röntgeni (Sağ Kolon):**
082|metin    |   - Seçilen ajanı 4 sekmeli derin muayeneye tabi tutar:
083|metin    |     - `[BULGULAR / OUTPUT]`: Ajanın ürettiği özet, ham çıkarımlar, varsa durma/hata nedeni.
084|metin    |     - `[GİRDİ / INPUT]`: Ajanın istemine (prompt) beslenen hedef verileri ve bağlam.
085|metin    |     - `[GÜVEN & KARAR]`: Ajanın matematiksel güven puanı, jüri oyları veya kosinüs benzerliği.
086|metin    |     - `[HAM VERİ / RAW JSON]`: Backend'den dönen birebir JSON sözleşmesi.
087|metin    |4. **Kara Kutu Canlı Uçuş Kaydedicisi (Alt Güverte):**
088|metin    |   - `ALL`, `OSINT`, `LLM`, `DECISION`, `ERRORS` filtreleriyle canlı log akışı sağlayan, otomatik kaydırmalı adli terminal.
089|boş      |
090|metin    |---
091|boş      |
092|metin    |## Teknik akış, API ve geliştirme
093|boş      |
094|metin    |### Temel kod yolları
095|boş      |
096|metin    |- API ve görev başlatma: `backend/api.py` → `run_mission()` → `agent_core/task_executor.py`
097|metin    |- Ajan seçimi: `agent_core/services/cognitive_router.py`
098|metin    |- Ajan envanteri ve altı soruluk kod ayrıntısı: [README_TECHNICAL.md](README_TECHNICAL.md)
099|metin    |- **Tam depo envanteri (680+ dosya, klasör klasör, aranabilir): [docs/envanter.html](docs/envanter.html)**
100|metin    |  — üretilen sayfa; `python scripts/generate_inventory_page.py` ile yenilenir,
101|metin    |  CI `--check` ile bayatlamayı yakalar. `.env.example`'ın 98 ayarı ve `config/*`
102|metin    |  içeriği tek tek açıklanmıştır.
103|metin    |- Scraper/görsel/pillar: `agent_core/scraper/`, `agent_core/services/`, `agent_core/engines/`
104|metin    |- UI: `frontend/src/`
105|boş      |
106|metin    |### Başlıca yüzeyler
107|boş      |
108|metin    || Yüzey | Rol |
109|metin    ||---|---|
110|metin    || `POST /api/initiate` | Ana profil görevi; aynı `run_mission` akışını başlatır. |
111|metin    || `POST /api/aspasia/chat` | Kullanıcıya görev/kanıt durumu yanıtı. |
112|metin    || `POST /api/aspasia/command` | Sınırlı doğal dil intent'i; desteklenen açık Instagram URL'si doğrulanır ve aynı görev akışına dispatch edilir. |
113|metin    || `GET /api/media/status` | Medya hattı: yt-dlp/ffmpeg/opencv ve transkript motorunun GERÇEK durumu. |
114|metin    || `POST /api/media/analyze` | Paylaşılan medyayı indirir, kare kare ölçer, yazıya döker, görsel benzerlik arar. Ölçülmeyen iddia edilmez. |
115|metin    || `GET /api/report/status` | Hangi rapor formatı GERÇEKTEN üretilebilir (reportlab/Pillow/ffmpeg sebepleriyle). |
116|metin    || `POST /api/report/build` | Kanıt satırlarından PDF/diyagram/video paketi üretir; manifest eser hash'lerini ve kanıt kimliklerini taşır. |
117|metin    || `GET /api/company/status` | Kurum hedefi modlarının gerçek durumu (theHarvester · açık SEO · kişi künyesi). Kapı kapalıysa "hazır" denmez. |
118|metin    || `POST /api/company/scan` | Alan adını omurgadan tarar; mod başına kanıt satırları kaynak URL ile döner. Uydurma SEO puanı yok. |
119|metin    || `GET /api/jury/status` | Yerel jürinin durumu: kaç BAĞIMSIZ koltuk, uç yerel mi, yeter sayı. Model yoksa `available: false`. |
120|metin    || `POST /api/jury/vote` | Aynı kanıtı birden çok yerel modele bağımsız oylatır; kural (oybirliği/çoğunluk) ve koltuk dökümü döner. Konsensüs yoksa karar iddia edilmez. |
121|metin    || `GET /api/mcp/status` | MCP ihracının durumu: kaç yetenek araç olarak açık, hangi protokol sürümleri, kasa mandalı. Yetenek KOŞTURMAZ. |
122|metin    || `POST /api/experimental/shadow/analyze` | Deneysel Shadow analiz endpoint'i; normal UI akışından ayrı. |
123|metin    || `POST /api/experimental/shadow/generate` | Deneysel Shadow taslak üretim endpoint'i; normal UI akışından ayrı. |
124|metin    || `POST /api/experimental/chat/respond` | Deneysel, oturumlu DialogueManager yanıtı; normal UI çağırmaz. |
125|metin    || `run_lilith.py` | Ana analiz hattı dışında, CLI'dan Lilith içerik paketi üretimi. |
126|metin    || `/api/experimental/interpreter/execute` | Yalnız opt-in Interpreter yapılandırmasında bulunan deneysel kod görevi yolu. |
127|boş      |
128|metin    |---
129|boş      |
130|metin    |## Ne İşe Yarar ve Nasıl Çalışır?
131|boş      |
132|metin    |Diyelim ki bir hesabı incelemek istiyorsunuz. Programın içinde birbirinden farklı uzmanlıkları olan **12 Akıllı Ajan (Uzman)** bulunur. Görevi başlattığınızda şunlar olur:
133|metin    |1. **Veri Toplar:** Sizin verdiğiniz linkteki herkese açık resimleri ve yazıları çeker.
134|metin    |2. **Davranış ve Karakter Analizi Yazar:**
135|metin    |   - *Zamanlama Uzmanı*, kişinin hangi saatlerde daha aktif olduğunu söyler.
136|metin    |   - *İnsan Davranışı Analisti*, o kişinin paylaşımlarından ne tarz şeyleri sevdiğini, hobilerini ve karakter yapısını anlamaya çalışır.
137|metin    |   - Bütün uzmanlar kendi aralarında toplanıp hedefin profilini tartışarak tek, net bir rapor çıkarır.
138|metin    |3. **Kasa (Vault) Güvenliği:** Asistan, topladığı notları ve gördüğü fotoğrafları hiçbir zaman internette bırakmaz. Bilgisayarınızın derinlerinde yer alan, adına "Kasa (Vault)" dediğimiz şifreli bir odada tutar. **Ekranda kasayı kilitle derseniz**, sistem dış dünyayla (internetle) bağını tamamen koparır ve asla araştırma yapmaz.
139|metin    |4. **Çocuk Koruması (Kırmızı Çizgi):** Hedef hesaptaki kişi 18 yaşının altındaysa asistan bunu tespit eder etmez araştırmayı durdurur. Bu, sistemin üzerine kurulu olduğu değişmez, aşılamaz, en temel kuraldır.
140|boş      |
141|metin    |---
142|boş      |
143|metin    |## 💻 Mühendisler ve Geliştiriciler İçin Kurulum Rehberi
144|boş      |
145|metin    |> **Canlıya almadan önce:** [GO_LIVE.md](GO_LIVE.md) — port haritası, mimari
146|metin    |> şema, BLOCKER `.env` tablosu, tek komutla kaldırma ve **ölçülmüş** doğrulama
147|metin    |> sonuçları. Çok operatörlü kurulumda `PINEAL_OPERATOR_TOKENS` zorunludur;
148|metin    |> görev sahipliği mührü (§4) ve açık bulgular listesi (§5) oradadır.
149|metin    |## 4. Epifiz'in Yedi Nöro-Bilişsel Dalga Motoru (LLM'siz Saf Matematik)
150|boş      |
151|metin    |Bu motorlar `agent_core/engines/` dizininde bulunur. Sıfır LLM çağrısıyla, deterministik formüllerle çalışırlar:
152|boş      |
153|metin    |```
154|metin    |                      ┌── FrequencyEngine  (Sirkadiyen Ritim, Gece/Gündüz Dağılımı)
155|metin    |                      ├── SeismosEngine    (Kutup Değişimi, Davranışsal Fay Kırılmaları)
156|metin    |                      ├── VoidEngine       (Negatif Uzay: 10 Temel Konudan Bilinçli Kaçınma)
157|metin    |PillarOrchestrator ───┼── StrataEngine     (Zaman İçinde Değişen / Sönümlenen Maskeler)
158|metin    |                      ├── GravityEngine    (Anlatı Çekim Merkezleri, Sabit Fikirler)
159|metin    |                      ├── PulseEngine      (Dijital Soluk: Cümle & Noktalama Ritimleri)
160|metin    |                      └── KeyEngine        (6 Motorun Çıktısını Birleştiren Rezonans Vektörü)
161|metin    |```
162|boş      |
163|metin    || Dalga Motoru | Kaynak Dosya | Matematiksel / Analitik Görev |
164|metin    ||---|---|---|
165|metin    || **Frequency** | `frequency_engine.py` | Paylaşım zaman damgalarını sinüs/kosinüs dalgasına döker; gece uykusuzluğu ve biyolojik ritmi hesaplar. |
166|metin    || **Seismos** | `seismos_engine.py` | Duygusal durumlardaki ani faz sıçramalarını ve sismik kırılma noktalarını (`SeismicEvent`) saptar. |
167|metin    || **Void** | `void_engine.py` | İnsanın profilde ısrarla bahsetmediği negatif alanları (para, aile, zaaflar) bularak bastırılanı çıkarır. |
168|metin    || **Strata** | `strata_engine.py` | Yıllar içindeki üslup kaymalarını (`IdentityDrift`) ve terk edilen eski maskeleri ayrıştırır. |
169|metin    || **Gravity** | `gravity_engine.py` | Kişinin konuşmayı sürekli döndürdüğü ana çekim kuyularını (`GravityWell`) modeller. |
170|metin    || **Pulse** | `pulse_engine.py` | Metinlerdeki soluk ritmini, virgül, ünlem ve duraksama entropisini sayısallaştırır. |
171|metin    || **Key** | `key_engine.py` | Tüm motor çıktılarını normalize ederek birleşik `ResonanceVector` sentezler. |
172|boş      |
173|metin    |---
174|boş      |
175|metin    |## 5. 12 Uzman Analiz Rolü — Kanonik Boru Hattı
176|boş      |
177|metin    |> **Mimari not (2026-10-07 denetimi, Madde 3).** 12 rol, Docker'da birbirinden
178|metin    |> bağımsız çalışan **analiz yürütücüleri değildir**. Rolleri çekirdek
179|metin    |> orkestratör (`PinealExecutor`) **süreç içinde** (in-process) sırayla yürütür
180|metin    |> ve gerçek `active / ready / wait` geçişlerini yazar. `docker-compose.yml`
181|metin    |> içindeki 12 `beacon-*` servisi ise yalnızca **canlılık işaretçisidir**
182|metin    |> (liveness beacon): "yuva ayakta ve boşta" sinyalini kendi kanalına
183|metin    |> (`pineal:agent:beacon`) yayınlar; analiz yürütmez ve ajan durumunu **ezmez**.
184|boş      |
185|metin    |Sistemdeki 12 uzman rol orkestratör tarafından yürütülür; durumları Redis
186|metin    |Pub/Sub ve WebSocket üzerinden canlı olarak Rack'e yansır:
187|boş      |
188|metin    |```
189|metin    |[ OSINT Investigator ] ──> [ 7-Pillar Forensics ] ──> [ Mirror of Truth ]
190|metin    |          │                                                   │
191|metin    |          ▼                                                   ▼
192|metin    |[ Autonomous Verifier ] ──> [ Human Behavior ] ───> [ Passion Mapper ]
193|metin    |(3 Jürili Hakem Paneli)     (Cold Reading / Aşil)   (Akış & Neşe Haritası)
194|metin    |          │                                                   │
195|metin    |          ▼                                                   ▼
196|metin    |[ Friction & Bounds ]  ───> [ Cognitive Profiler ] ──> [ Resonance Calc ]
197|metin    |(Sınır & Stres Noktası)     (Dilbilimsel Düşünce)     (Numpy Vektör Kosinüs)
198|metin    |          │                                                   │
199|metin    |          ▼                                                   ▼
200|metin    |[ Pattern Interrupt ]  ───> [ Resonance Synth ] ───> [ Depth Analyst ]
201|metin    |(Beklenti Kırma Ağacı)      (İlk Temas Mesajı)        (Gerçeklik Endeksi & Mühür)
202|metin    |```
203|boş      |
204|metin    |Proje hem **Python** tabanlı, dağıtık otonom ajanlarla çalışan bir Backend'den hem de **Svelte** ile yazılmış hızlı bir arayüzden oluşur.
205|boş      |
206|metin    |### 1. Kurulum ve Başlatma
207|metin    |Sistemi sıfırdan kurmak ve çalıştırmak için:
208|metin    |- Gerekli kütüphaneleri yüklemek için (Backend):
209|metin    |  ```bash
210|metin    |  python3 -m venv .venv
211|metin    |  source .venv/bin/activate
212|metin    |  pip install -r requirements.lock
213|metin    |  ```
214|metin    |- Sistemi doğrudan başlatmak için Windows'ta `baslat.bat` dosyasını, Unix sistemlerde ise Docker komutunu (`docker compose up --build -d`) kullanabilirsiniz.
215|metin    |- Frontend'i (Ön Yüz) elle derlemek isterseniz:
216|metin    |  ```bash
217|metin    |  cd frontend
218|metin    |  npm ci
219|metin    |  npm run build
220|metin    |  ```
221|boş      |
222|metin    |### 2. Arayüze Erişim
223|metin    |Kurulum bittikten sonra internet tarayıcınızı (Chrome, Safari vb.) açıp **`http://localhost:8000`** adresine gidin. Karşınıza görev kontrol ekranı ve asistanınız "Aspasia" gelecektir.
224|boş      |
225|metin    |### 3. Yapılandırma ve Çalışma Prensibi (Kısa Mimari)
226|metin    |- Tüm sistem dışarıya çıkışlarını `agent_core/capabilities/` isimli omurgadan (backbone) geçirir. Asla dış kütüphaneler (örneğin OpenAI vb.) doğrudan kullanılamaz; daima bu geçit kapısından onay alır.
227|metin    |- Veri yetersizse sistem kendi kendine veri "uydurmaz". Analiz başarısız olur ve kırmızı bir uyarı basar (`Fail-Closed` kuralı).
228|boş      |
229|metin    |---
230|boş      |
231|metin    |*(Not: Eski yapay zeka denemeleri, bozuk kod parçaları ve kafa karıştırıcı dallar temizlenmiştir. Burası, uygulamanın çalışır ve insani en net halidir.)*
