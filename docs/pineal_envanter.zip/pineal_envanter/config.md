# config/* — ANAHTAR ANAHTAR AÇIKLAMA VE AJAN→MODEL TABLOSU

- `config/agent_tiers.json` (101 satır): Ajan→tier niyeti (heavy/vision/simple/verify/jury)
- `config/task_routing.json` (33 satır): Ajan→sıralı model anahtarı zinciri DELTA'sı (task_routing_resolver okur)
- `config/provider_catalog.json` (858 satır): Sağlayıcı kataloğu: uç, fiyat, yetenek, model aileleri
- `config/decision_config.yaml` (81 satır): Karar/belirsizlik eşikleri
- `config/rtk_policy.json` (25 satır): RTK token sıkıştırma bypass politikası (fail-open)
- `config/router.example.json` (52 satır): UnifiedRouter örnek yapılandırması

## 1) Ajan → Tier → Model zinciri (çalışan sınıftan okundu)

| Ajan | Tier | Kod zinciri | 9Router zinciri | Not |
|---|---|---|---|---|
| `aspasia` | heavy | anthropic/claude-sonnet-5 → google/gemini-3.7-flash | pineal-general-reasoning → pineal-deep-reasoning | Chief dialogue + only images= caller (aspasia_chief). |
| `authenticity_auditor` | heavy | deepseek/deepseek-v4-flash → google/gemini-3.7-flash → anthropic/claude-sonnet-5 | pineal-vision → pineal-general-reasoning | Audit judgment; cheap-first chain escalates to claude. |
| `autonomous_verifier` | verify | anthropic/claude-sonnet-5 → google/gemini-3.7-flash → x-ai/grok-4.6 | pineal-general-reasoning → pineal-fast-extract | Search-gated (tavily/serpapi/exa keys required or no_search_provider). |
| `autonomous_verifier_extract` | simple | openai/gpt-oss-120b → poolside/laguna-s-2.1:free | pineal-fast-extract → pineal-general-reasoning | Claim extraction; the ONLY task=fast caller. |
| `cognitive_profiler` | heavy | openai/gpt-oss-120b → google/gemini-3.7-flash → deepseek/deepseek-v4-flash | pineal-general-reasoning → pineal-fast-extract | Profile inference. REVIEW: downgrade candidate if workload is extraction-heavy. |
| `depth_analyst` | heavy | anthropic/claude-sonnet-5 → deepseek/deepseek-v4-pro → google/gemini-3.7-flash | pineal-general-reasoning → pineal-deep-reasoning | Psychodynamic depth reports; deepseek-first flip. |
| `dialogue_manager` | simple | — | — | DORMANT: no gateway callers; traffic-management intent. |
| `friction_detector` | heavy | anthropic/claude-sonnet-5 → google/gemini-3.7-flash → deepseek/deepseek-v4-pro | pineal-general-reasoning → pineal-fast-extract | Bounds judgment. |
| `human_behavior` | heavy | openai/gpt-oss-120b → google/gemini-3.7-flash | pineal-general-reasoning → pineal-fast-extract | Cold-reading inference over evidence (text path, no images). |
| `interpreter` | simple | — | pineal-general-reasoning → pineal-fast-extract | DORMANT in gateway (no callers); live path bypasses chains via interpreter_agent.py:37 hardcoded default (separate behav |
| `lilith_growth` | simple | openai/gpt-oss-120b → poolside/laguna-s-2.1:free | pineal-fast-extract → pineal-general-reasoning | CLI-only (run_lilith.py explicit model); bulk content generation = cost-sensitive intent. |
| `mirror_truth` | heavy | anthropic/claude-sonnet-5 → google/gemini-3.7-flash | pineal-general-reasoning → pineal-deep-reasoning | Truth-alignment judgment. |
| `osint_investigator` | heavy | google/gemini-3.7-flash → x-ai/grok-4.6 → deepseek/deepseek-v4-pro | pineal-general-reasoning → pineal-fast-extract | Synthesis over tool results; holds gateway but never queries (dormant chain). |
| `passion_mapper` | simple | openai/gpt-oss-120b → poolside/laguna-s-2.1:free | pineal-fast-extract → pineal-general-reasoning | Mapping/classification over scraped data. REVIEW: upgrade candidate if inference depth grows. |
| `pattern_interrupt` | simple | openai/gpt-oss-120b → poolside/laguna-s-2.1:free | pineal-fast-extract → pineal-general-reasoning | Short intervention generation; high-frequency cheap intent. |
| `pineal_juror_claude` | jury | pineal-juror-claude | pineal-juror-claude | Jüri koltuğu 2/3 — üreten Claude ise düşürülür. |
| `pineal_juror_google` | jury | pineal-juror-google | pineal-juror-google | Jüri koltuğu 1/3 — bağımsız hakem (Gemini ailesi). |
| `pineal_juror_open` | jury | pineal-juror-open | pineal-juror-open | Jüri koltuğu 3/3 — açık/harici hat, hakem. |
| `resonance_synthesizer` | heavy | openai/gpt-5.6-luna → google/gemini-3.7-flash → anthropic/claude-sonnet-5 | pineal-general-reasoning → pineal-deep-reasoning | Synthesis reasoning. |
| `shadow_executor` | heavy | — | pineal-general-reasoning → pineal-deep-reasoning | DORMANT: no gateway callers; evidence-gated execution intent. |
| `vision_analyzer` | vision | google/gemini-3.7-flash → x-ai/grok-4.6 | pineal-vision → pineal-general-reasoning | Only task=vision caller with images; gemini-first chain. |

### Görev (task) düzeyi zincirler

| Görev | Zincir |
|---|---|
| `depth` | anthropic/claude-sonnet-5 → deepseek/deepseek-v4-pro → google/gemini-3.7-flash |
| `vision` | google/gemini-3.7-flash → x-ai/grok-4.6 |
| `dialogue` | anthropic/claude-sonnet-5 → google/gemini-3.7-flash |
| `fast` | deepseek/deepseek-v4-flash → google/gemini-3.7-flash |

### MODEL_REGISTRY (21 kayıt)

| Anahtar | Model |
|---|---|
| `claude_sonnet_5` | anthropic/claude-sonnet-5 |
| `deepseek_v4_flash` | deepseek/deepseek-v4-flash |
| `deepseek_v4_pro` | deepseek/deepseek-v4-pro |
| `gemini_3_7_flash` | google/gemini-3.7-flash |
| `glm_5_2` | z-ai/glm-5.2 |
| `gpt_5_6_luna` | openai/gpt-5.6-luna |
| `gpt_oss_120b` | openai/gpt-oss-120b |
| `grok_4_6` | x-ai/grok-4.6 |
| `laguna_s_2_1_free` | poolside/laguna-s-2.1:free |
| `ling_3_flash` | inclusionai/ling-3.0-flash |
| `pineal_deep_reasoning` | pineal-deep-reasoning |
| `pineal_fast_extract` | pineal-fast-extract |
| `pineal_general_reasoning` | pineal-general-reasoning |
| `pineal_intelligence_lane` | pineal-intelligence-lane |
| `pineal_juror_claude` | pineal-juror-claude |
| `pineal_juror_google` | pineal-juror-google |
| `pineal_juror_open` | pineal-juror-open |
| `pineal_truth_lane` | pineal-truth-lane |
| `pineal_vision` | pineal-vision |
| `pineal_vision_lane` | pineal-vision-lane |
| `solar_pro4` | upstage/solar-pro4 |

## 2) decision_config.yaml — çözümlenmiş anahtarlar

| Anahtar | Değer |
|---|---|
| `version` | "1.0" |
| `pipeline.default.min_data_score` | 0.60 |
| `pipeline.default.min_llm_confidence` | 0.65 |
| `pipeline.default.graceful_degradation` | true |
| `pipeline.default.agent_timeout_seconds` | 120 |
| `agents.pineal_7pillar.graceful_degradation` | false |
| `agents.pineal_7pillar.timeout_seconds` | 60 |
| `agents.depth_analyst.timeout_seconds` | 150 |
| `agents.passion_mapper.min_data_score` | 0.57 |
| `agents.passion_mapper.min_llm_confidence` | 0.70 |
| `agents.passion_mapper.graceful_degradation` | true |
| `agents.passion_mapper.field_weights.core_passions` | 0.30 |
| `agents.passion_mapper.field_weights.energizing_topics` | 0.25 |
| `agents.passion_mapper.field_weights.flow_triggers` | 0.20 |
| `agents.passion_mapper.field_weights.evidence_quotes` | 0.15 |
| `agents.passion_mapper.field_weights.sentiment_polarity` | 0.10 |
| `agents.passion_mapper.empty_list_penalty` | 0.12 |
| `agents.mirror_truth.min_llm_confidence` | 0.65 |
| `agents.mirror_truth.min_data_score` | 0.60 |
| `agents.mirror_truth.field_weights.user_core_frequency` | 0.3 |
| `agents.mirror_truth.field_weights.surface_persona` | 0.3 |
| `agents.mirror_truth.field_weights.alignment_score` | 0.2 |
| `agents.mirror_truth.field_weights.authentic_anchors` | 0.2 |
| `agents.mirror_truth.empty_list_penalty` | 0.08 |
| `agents.friction_detector.min_data_score` | 0.55 |
| `agents.friction_detector.min_llm_confidence` | 0.60 |
| `agents.friction_detector.graceful_degradation` | true |
| `agents.shadow_executor.min_data_score` | 0.52 |
| `agents.shadow_executor.min_llm_confidence` | 0.60 |
| `agents.shadow_executor.graceful_degradation` | true |
| `agents.shadow_executor.field_weights.dark_profile` | 0.30 |
| `agents.shadow_executor.field_weights.strategy` | 0.25 |
| `agents.shadow_executor.field_weights.nlp_sequence` | 0.25 |
| `agents.shadow_executor.field_weights.message` | 0.20 |
| `agents.shadow_executor.empty_list_penalty` | 0.08 |
| `agents.osint_investigator.min_data_score` | 0.40 |
| `agents.osint_investigator.min_llm_confidence` | 0.55 |
| `agents.osint_investigator.graceful_degradation` | true |
| `agents.osint_investigator.field_weights.associated_platforms` | 0.30 |
| `agents.osint_investigator.field_weights.digital_footprint_score` | 0.25 |
| `agents.osint_investigator.field_weights.connected_emails` | 0.20 |
| `agents.osint_investigator.field_weights.connected_phones` | 0.15 |
| `agents.osint_investigator.field_weights.dark_web_hits` | 0.10 |
| `agents.osint_investigator.empty_list_penalty` | 0.05 |

## 3) rtk_policy.json

- `enabled` = True, `default_level` = conservative
- bypass: {"_comment": "Bu task/agent adlarına RTK sıkıştırması UYGULANMAZ. DEEP_REASONING kategorisi (4 kanallı gerilim matrisi, mikro-dilbilimsel ritim analizi gibi nüans-kritik görevler) tamamen dışlanmıştır.", "tasks": ["depth