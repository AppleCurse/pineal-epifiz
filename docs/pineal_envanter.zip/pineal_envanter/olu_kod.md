# ÖLÜ KOD RAPORU — import edilmeyen / çağrılmayan dosyalar

Yöntem: (1) AST import grafiği (alt modül importları dahil), (2) metinsel iz, (3) giriş noktaları.

Kapsam: yalnız `.py`; `tests/**` altındaki 234 test dosyası LİSTELENMEZ (testler import edilmez, pytest dinamik toplar → ölü kod değildir).

## 1) Hiç iz bırakmayan dosyalar (0)

- Yok.

## 2) Metinde anılıyor ama import edilmiyor (14)

| Dosya | Nerede |
|---|---|
| `agent_core/mcp/__main__.py` | metinde anılıyor ama import edilmiyor: agent_core/scraper/run_scraper.py, agent_core/services/final_routing_policy.py, agent_core/services/maigret_db_refresh.py, agent_core/workers/agent_worker.py, live_llm_gate.py |
| `backend/api.py` | yalnız betik/CLI import ediyor: scripts/archive/flow_roentgen.py |
| `live_llm_gate.py` | metinde anılıyor ama import edilmiyor: .github/workflows/release-gates.yml, agent_core/services/llm_gateway.py, docs/inventory_notes.json, release/3.0.0-rc.2.json, release/release-gates.yml |
| `main.py` | metinde anılıyor ama import edilmiyor: Dockerfile, agent_core/scraper/run_scraper.py, agent_core/services/maigret_db_refresh.py, agent_core/task_executor.py, agent_core/workers/agent_worker.py |
| `run_lilith.py` | metinde anılıyor ama import edilmiyor: agent_core/agents/lilith_growth.py, config/agent_tiers.json, docs/inventory_notes.json, scripts/generate_inventory_page.py |
| `scraper.py` | metinde anılıyor ama import edilmiyor: Dockerfile, agent_core/__init__.py, agent_core/agents/osint_investigator.py, agent_core/aspasia/interface.py, agent_core/capabilities/adapters_sensors.py |
| `scripts/audit_regression.py` | metinde anılıyor ama import edilmiyor: .github/workflows/ci.yml, docs/inventory_notes.json, scripts/generate_inventory_page.py, tests/audit/test_responsibility_rules.py, tests/unit/test_audit_regression.py |
| `scripts/export_skills.py` | metinde anılıyor ama import edilmiyor: .github/workflows/ci.yml, docs/inventory_notes.json, scripts/generate_inventory_page.py, tests/unit/test_export_skills.py |
| `scripts/generate_inventory_page.py` | metinde anılıyor ama import edilmiyor: .github/workflows/ci.yml, docs/inventory_notes.json, tests/unit/test_inventory_page.py |
| `scripts/generate_routing_shadows.py` | metinde anılıyor ama import edilmiyor: .github/workflows/ci.yml, agent_core/services/llm_gateway.py, config/agent_tiers.json, scripts/generate_inventory_page.py, tests/unit/test_frontend_agent_model_contract.py |
| `scripts/preflight_9router.py` | metinde anılıyor ama import edilmiyor: .github/workflows/preflight.yml, scripts/generate_inventory_page.py |
| `scripts/run_task.py` | metinde anılıyor ama import edilmiyor: agent_core/agents/resonance_synthesizer.py, agent_core/services/platform_registry.py, agent_core/task_executor.py, backend/api.py, rust_core/src/agents/mirror_truth.rs |
| `scripts/smoke_test_browser.py` | metinde anılıyor ama import edilmiyor: .github/workflows/release-gates.yml, release/3.0.0-rc.2.json, release/release-gates.yml, scripts/generate_inventory_page.py, tests/unit/test_release_gates_workflow.py |
| `scripts/verify_openrouter_catalog.py` | metinde anılıyor ama import edilmiyor: .github/workflows/ci.yml, agent_core/services/final_routing_policy.py, agent_core/services/llm_gateway.py, scripts/generate_inventory_page.py |

## 3) Yalnız TESTLER import ediyor (2)

| Dosya | Import eden testler |
|---|---|
| `agent_core/scraper/run_scraper.py` | yalnız TESTLER import ediyor: tests/unit/test_p1_5_scraper_errors.py |
| `agent_core/workers/agent_worker.py` | yalnız TESTLER import ediyor: tests/unit/test_agent_worker.py, tests/unit/test_task_lifecycle.py |

## 4) Yalnız DOKÜMANDA anılanlar (0)

- Yok.

## 5) Arşiv (bilinçli üretim dışı) — 8 dosya

| `scripts/archive/analyze_target_instagram.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/benchmark_download.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/e2e_test.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/flow_roentgen.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/live_provider_probe.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/test_e2e_fixture.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/test_live_holistic.py` | scripts/archive/README.md: üretim dışı tanı betiği |
| `scripts/archive/ws_leak_probe.py` | scripts/archive/README.md: üretim dışı tanı betiği |

## 6) Dinamik import yapan dosyalar (1)

| `agent_core/services/dependency_health.py` | dosya kendisi dinamik import yapıyor |

## 7) Çalıştırılabilir giriş noktaları (ölü SAYILMAMALI)

- `python -m agent_core.workers.agent_worker --agent-id <ad>` → docker-compose beacon servisleri
- `uvicorn backend.api:app` → Dockerfile / railway.toml / CI smoke
- `python -m agent_core.mcp` → MCP stdio sunucusu
- `python main.py`, `python run_lilith.py`, `python live_llm_gate.py`, `python scripts/*.py`