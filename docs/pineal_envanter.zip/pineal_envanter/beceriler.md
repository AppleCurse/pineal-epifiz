# YETENEK DEFTERİ (Agent Skills) — SKILL.md + çalışan adaptör kodu

| # | SKILL.md | Yetenek kimliği | Tür | Kapılar | Adaptör dosyası |
|---|---|---|---|---|---|
| 1 | `analyzer_media_frames` | `analyzer.media.frames` | analyzer | ENABLE_MEDIA_FORENSICS, vault | agent_core/capabilities/adapters_media.py:134 |
| 2 | `analyzer_media_similarity` | `analyzer.media.similarity` | analyzer | ENABLE_MEDIA_FORENSICS, vault | agent_core/capabilities/adapters_media.py:280 |
| 3 | `extractor_identity_socid` | `extractor.identity.socid` | extractor | vault | agent_core/capabilities/adapters_osint.py:217 |
| 4 | `extractor_media_transcript` | `extractor.media.transcript` | extractor | ENABLE_MEDIA_FORENSICS, vault | agent_core/capabilities/adapters_media.py:222 |
| 5 | `extractor_text_language` | `extractor.text.language` | extractor | vault | agent_core/capabilities/adapters_language.py:42 |
| 6 | `extractor_text_translate_local` | `extractor.text.translate_local` | extractor | ENABLE_LOCAL_TRANSLATE, vault | agent_core/capabilities/adapters_language.py:102 |
| 7 | `extractor_web_crawl4ai` | `extractor.web.crawl4ai` | extractor | vault | agent_core/capabilities/adapters_web.py:52 |
| 8 | `extractor_web_scrapling` | `extractor.web.scrapling` | extractor | ENABLE_SCRAPLING, vault | agent_core/capabilities/adapters_web.py:53 |
| 9 | `extractor_web_trafilatura` | `extractor.web.trafilatura` | extractor | vault | agent_core/capabilities/adapters_web.py:51 |
| 10 | `renderer_report_diagram` | `renderer.report.diagram` | renderer | ENABLE_REPORT_FACTORY, vault | agent_core/capabilities/adapters_report_factory.py:187 |
| 11 | `renderer_report_pdf` | `renderer.report.pdf` | renderer | ENABLE_REPORT_FACTORY, vault | agent_core/capabilities/adapters_report_factory.py:179 |
| 12 | `renderer_report_video` | `renderer.report.video` | renderer | ENABLE_REPORT_FACTORY, vault | agent_core/capabilities/adapters_report_factory.py:195 |
| 13 | `sensor_company_harvester` | `sensor.company.harvester` | sensor | ENABLE_COMPANY_TARGETING, rate, vault | agent_core/capabilities/adapters_company.py:61 |
| 14 | `sensor_company_people` | `sensor.company.people` | sensor | ENABLE_COMPANY_TARGETING, vault | agent_core/capabilities/adapters_company.py:264 |
| 15 | `sensor_company_seo` | `sensor.company.seo` | sensor | ENABLE_COMPANY_TARGETING, vault | agent_core/capabilities/adapters_company.py:162 |
| 16 | `sensor_identity_holehe` | `sensor.identity.holehe` | sensor | ENABLE_HOLEHE, vault | agent_core/capabilities/adapters_osint.py:138 |
| 17 | `sensor_identity_maigret` | `sensor.identity.maigret` | sensor | ENABLE_MAIGRET, vault | agent_core/capabilities/__init__.py:12 |
| 18 | `sensor_ig_instagrapi` | `sensor.ig.instagrapi` | sensor | ENABLE_IG_SECONDARY, rate, vault | agent_core/capabilities/adapters_sensors.py:178 |
| 19 | `sensor_media_fetch` | `sensor.media.fetch` | sensor | ENABLE_MEDIA_FORENSICS, rate, vault | agent_core/capabilities/adapters_media.py:81 |
| 20 | `sensor_search_searxng` | `sensor.search.searxng` | sensor | ENABLE_SEARXNG, vault | agent_core/capabilities/adapters_sensors.py:389 |
| 21 | `sensor_web_agent_reach` | `sensor.web.agent_reach` | extractor | ENABLE_AGENT_REACH, vault | agent_core/capabilities/adapters_sensors.py:307 |
| 22 | `sensor_x_twscrape` | `sensor.x.twscrape` | sensor | ENABLE_X_SENSOR, rate, vault | agent_core/capabilities/adapters_sensors.py:63 |
| 23 | `verifier_jury_local` | `verifier.jury.local` | verifier | ENABLE_LOCAL_JURY, vault | agent_core/capabilities/adapters_jury.py:32 |
| 24 | `voice_report_script` | `voice.report.script` | renderer | vault | agent_core/capabilities/adapters_report.py:182 |
| 25 | `voice_stt_local` | `voice.stt.local` | extractor | ENABLE_LOCAL_STT, vault | agent_core/capabilities/adapters_voice.py:307 |
| 26 | `voice_tts_local` | `voice.tts.local` | renderer | ENABLE_LOCAL_TTS, vault | agent_core/capabilities/adapters_voice.py:115 |

## Adaptör modülleri

| Dosya | Satır | Ne yapar |
|---|---|---|
| `agent_core/capabilities/__init__.py` | 67 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: Capability Spin |
| `agent_core/capabilities/adapters_company.py` | 344 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ D · D6 — KU |
| `agent_core/capabilities/adapters_jury.py` | 139 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ D · D2 — YE |
| `agent_core/capabilities/adapters_language.py` | 167 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ D · D4 — Dİ |
| `agent_core/capabilities/adapters_media.py` | 337 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ D · D3 — ME |
| `agent_core/capabilities/adapters_osint.py` | 273 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: Faz 0 adaptörle |
| `agent_core/capabilities/adapters_report.py` | 237 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ C · C4 — SE |
| `agent_core/capabilities/adapters_report_factory.py` | 197 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ D · D5 — RA |
| `agent_core/capabilities/adapters_sensors.py` | 464 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ A · RETİNA  |
| `agent_core/capabilities/adapters_voice.py` | 467 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ C · C2 — YE |
| `agent_core/capabilities/adapters_web.py` | 399 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ A · RETİNA  |
| `agent_core/capabilities/base.py` | 205 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: Capability Spin |
| `agent_core/capabilities/egress.py` | 135 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: Capability Spin |
| `agent_core/capabilities/policy.py` | 107 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: PolicyKernel —  |
| `agent_core/capabilities/registry.py` | 234 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: CapabilityRegis |
| `agent_core/capabilities/runner.py` | 192 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: CapabilityRunne |
| `agent_core/capabilities/state.py` | 93 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: Politika durumu |
| `agent_core/capabilities/timeline_bridge.py` | 63 | Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır. Dosyanın kendi açıklaması: FAZ A (2) · KAN |

## Kapı modeli

- `policy.py` → PolicyState (enabled_flags, vault_locked, rate_ok)
- `runner.py` → CapabilityRunner (tek koşum yolu; reddi denied_by ile bildirir)
- `egress.py` → tek çıkış izi
- `skills/*/SKILL.md` → dış araçlara açılan tanım katmanı