#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EKSİKSİZ TARAYICI (SALT OKUMA) — her dosya için 12 zorunlu alanlı kayıt üretir.

Tahmin yok: her cümle dosyanın KENDİ içeriğinden (AST/docstring/regex) üretilir.
Çıktı: dosyalar/<klasör>.json · INDEX.json · _ham_kayitlar.json
"""
from __future__ import annotations

import ast
import json
import os
import re
import subprocess
from collections import defaultdict
from pathlib import Path

ROOT = Path("/home/user/pineal-epifiz")
OUT = Path("/tmp/pineal_envanter")
DOSYALAR = OUT / "dosyalar"

ENTRYPOINTS = {
    "main.py", "run_lilith.py", "scraper.py", "live_llm_gate.py", "worker.ts",
    "agent_core/workers/agent_worker.py", "agent_core/mcp/__main__.py", "backend/api.py",
}

IMG_MAGIC = {b"\x89PNG": "PNG", b"\xff\xd8\xff": "JPEG", b"\x00\x00\x01\x00": "ICO",
             b"icns": "ICNS", b"PK\x03\x04": "ZIP/JAR", b"GIF8": "GIF"}

NET_PAT = re.compile(r"\b(httpx|requests|aiohttp|urllib|socket|websockets|playwright|openai|AsyncOpenAI|open_client|egress)\b")
LLM_PAT = re.compile(r"\b(llm_gateway|LLMGateway|query_chain|query_json|chat_completion|start_chat_stream|OPENROUTER|NINEROUTER)\b")
FILE_PAT = re.compile(r"\b(open\(|read_text|write_text|Path\(|os\.makedirs|json\.dump|json\.load|shutil\.|tempfile\.)\b")
DB_PAT = re.compile(r"\b(redis|sqlite|checkpoint_store|canonical_memory|task_ledger|event_bus)\b")
VAULT_PAT = re.compile(r"\b(vault|kasa|VAULT_)\b", re.I)
MINOR_PAT = re.compile(r"\b(minor|çocuk|child_lock|reşit)\b", re.I)
AUTH_PAT = re.compile(r"\b(token|api_key|bearer|x-api-key|principal|auth_required)\b", re.I)
SSRF_PAT = re.compile(r"\b(loopback|localhost|127\.0\.0\.1|SSRF|pinlenmiş|pinned)\b", re.I)
PROC_PAT = re.compile(r"\b(subprocess|Popen|os\.system|shutil\.which)\b")

ELLE_OZETLER = {
    "agent_core/task_executor.py": (
        "Tüm analiz görevinin yürütücüsü: tek bir görevi adım adım koşturur ve her adımın çıktısını kanıt "
        "zincirine yazar. Sıra kabaca şöyledir: kimlik/ön kontrol → kanal keşfi → toplayıcılar → ajan koşumu "
        "(her ajanın kendi zaman aşımı var) → hakem/çapraz doğrulama → karar ve rapor. Kod, işi asla 'sessizce' "
        "bırakmaz: bellek bozulursa (CORRUPTED) veya 7-sütun kanıt temeli çökerse görev HALTED_CRITICAL ile "
        "duruşa geçer; yarıda kalan görev ancak ResumeBlockedError kuralları sağlanıyorsa devam eder. Kanıt "
        "mührü SHA-256 ile üretilir ve duvar-saati alanları dışarıda bırakılarak DETERMİNİSTİK kalır. Rezonans "
        "skoru 0.70'in altına düşerse görev halted_frequency ile durur. Ajan rafında 12 gerçek slot vardır; "
        "3 slot (shadow_executor, pineal_7pillar, vision_analyzer) bu yürütücüde boştur."
    ),
    "backend/api.py": (
        "Sunucunun tek FastAPI yüzeyi: HTTP uçları, canlı telemetri WebSocket'i ve OpenAI-uyumlu uçlar hep "
        "burdan dağıtılır. İstek gövdesi tavanı bir middleware ile kesilir; her istek önce kimlik ve duruş "
        "denetiminden geçer (_secure_path → posture.auth_required; kimlik yoksa 401, duruş hatasıysa 503). "
        "/v1/ yollarında x-api-key ya da Bearer jetonu aranır ve istek 'principal' (operatör kimliği) ile "
        "damgalanır. Uçlar hız kovalarına ayrılmıştır (ör. görev başlatma dakikada 5, model çağrısı 60, medya "
        "6); oda sayısı _MAX_ROOMS'u aşarsa 503 döner. Statik arayüz montajı BİLEREK rotalardan sonra yapılır. "
        "Dosya 5.916 satırla ratchet tavanındadır: yeni satır eklemek için önce başka bir modüle çıkarma yapılmalıdır."
    ),
    "agent_core/services/llm_gateway.py": (
        "Tüm dil modeli trafiğinin tek kapısı: hangi ajanın hangi modele gideceğine karar verir, isteği "
        "gönderir, yanıtı ve maliyeti kaydeder. Sağlayıcı önceliği NINEROUTER_* > PINEAL_LLM_* > OPENROUTER_* "
        "şeklindedir; 9Router varsayılanı yerel adrestir (http://127.0.0.1:20128/v1) ve yalnız loopback kabul "
        "edilir. DNS-rebinding saldırısına karşı adres çözümlemesi sabitlenmiş taşıma katmanı kullanılır. Para "
        "kapısı serttir: istek öncesi bütçe rezerve edilir (_reserve), sonuçta kesinleşir (_settle), hata olursa "
        "iade edilir (_release); OPENROUTER_MAX_SPEND_USD=0 ise bulut harcaması tamamen kapalıdır. Yanıt boş "
        "gelirse ProviderEmptyResponseError, istenmeyen model ikamesi olursa ModelSubstitutionDeniedError "
        "yükseltilir. Her çağrı call_id ile işaretlenir ve denetim için tier izi tutulur."
    ),
}


def sh(*args: str) -> str:
    return subprocess.run(["git", "-c", "core.quotepath=false", *args],
                          cwd=ROOT, capture_output=True, text=True).stdout


def list_files() -> list[str]:
    return [f for f in sh("ls-files", "-z").split("\0") if f]


def loc(rel: str) -> int:
    try:
        return len((ROOT / rel).read_bytes().split(b"\n")) - ((ROOT / rel).read_bytes().endswith(b"\n"))
    except OSError:
        return 0


def read_text(rel: str) -> str | None:
    try:
        ham = (ROOT / rel).read_bytes()
    except OSError:
        return None
    if b"\x00" in ham[:8192]:
        return None
    return ham.decode("utf-8", errors="replace")


# ------------------------------------------------------------------ modül grafiği

MODULE_INDEX: dict[str, str] = {}
IMPORTERS: dict[str, set[str]] = defaultdict(set)
IC_IMPORT: dict[str, set[str]] = defaultdict(set)


def internal_imports(tree: ast.AST, rel: str) -> list[str]:
    """from X import y  → X.y (alt modül!) dahil; göreli import'lar pakete göre çözülür."""
    mods: list[str] = []
    paket = os.path.dirname(rel).replace("/", ".")
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            mods += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            kok = node.module or ""
            if node.level:
                parcalar = paket.split(".") if paket else []
                taban = ".".join(parcalar[: len(parcalar) - (node.level - 1)]) if parcalar else ""
                kok = f"{taban}.{kok}".strip(".") if kok else taban
            if kok:
                mods.append(kok)
                mods += [f"{kok}.{a.name}" for a in node.names if a.name != "*"]
    return sorted({m for m in mods if m.startswith(("agent_core", "backend", "scripts", "tests", "frontend"))})


def resolve(mod: str) -> str | None:
    parts = mod.split(".")
    while parts:
        cand = ".".join(parts)
        if cand in MODULE_INDEX:
            return MODULE_INDEX[cand]
        parts.pop()
    return None


def build_graph(files: list[str]) -> None:
    for rel in files:
        if not rel.endswith(".py"):
            continue
        MODULE_INDEX[rel[:-len("/__init__.py")].replace("/", ".") if rel.endswith("/__init__.py")
                     else rel[:-3].replace("/", ".")] = rel
    for rel in files:
        if not rel.endswith(".py"):
            continue
        text = read_text(rel)
        if text is None:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for m in internal_imports(tree, rel):
            hedef = resolve(m)
            if hedef and hedef != rel:
                IMPORTERS[hedef].add(rel)
                IC_IMPORT[rel].add(hedef)


def textual_refs(rel: str, files: list[str]) -> list[str]:
    base = rel[:-3] if rel.endswith(".py") else rel
    stem = os.path.basename(base).replace(".py", "")
    needle = base.replace("/", ".")
    hits = []
    for other in files:
        if other == rel or not other.endswith((".py", ".md", ".ts", ".svelte", ".kt", ".json", ".yml", ".toml", ".sh")):
            continue
        t = read_text(other)
        if t and (needle in t or f'"{stem}"' in t or f"'{stem}'" in t):
            hits.append(other)
    return sorted(hits)[:12]


# ------------------------------------------------------------------ olgu çıkarımı

def py_facts(rel: str, text: str) -> dict:
    f = {"sozdizimi_hatasi": "", "modul_docstring": "", "siniflar": [], "fonksiyonlar": [],
         "testler": [], "sabitler": [], "ic_bagimliliklar": []}
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        f["sozdizimi_hatasi"] = f"{exc.__class__.__name__}: {exc}"
        return f
    f["modul_docstring"] = ast.get_docstring(tree) or ""
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            metotlar = [{"ad": m.name, "satir": m.lineno, "imza": imza_of(m), "dondurur": ret_of(m),
                         "docstring": (ast.get_docstring(m) or "").split("\n")[0]}
                        for m in node.body if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))]
            f["siniflar"].append({"ad": node.name, "satir": node.lineno,
                                  "docstring": (ast.get_docstring(node) or "").split("\n")[0],
                                  "metotlar": metotlar})
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            f["fonksiyonlar"].append({"ad": node.name, "satir": node.lineno, "imza": imza_of(node),
                                      "dondurur": ret_of(node),
                                      "docstring": (ast.get_docstring(node) or "").split("\n")[0]})
            if node.name.startswith("test_"):
                f["testler"].append(node.name)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id.isupper():
                    try:
                        f["sabitler"].append(f"{t.id} = {ast.unparse(node.value)[:60]}")
                    except Exception:
                        f["sabitler"].append(t.id)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_") \
                and node.name not in f["testler"]:
            f["testler"].append(node.name)
    f["ic_bagimliliklar"] = internal_imports(tree, rel)
    return f


def imza_of(node) -> str:
    try:
        args = [a.arg for a in node.args.args if a.arg != "self"] + [a.arg for a in node.args.kwonlyargs]
        if node.args.vararg:
            args.append("*" + node.args.vararg.arg)
        if node.args.kwarg:
            args.append("**" + node.args.kwarg.arg)
    except Exception:
        args = []
    on = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    return f"{on} {node.name}({', '.join(args)})"


def ret_of(node) -> str:
    r = getattr(node, "returns", None)
    try:
        return ast.unparse(r) if r is not None else ""
    except Exception:
        return ""


def md_facts(text: str) -> dict:
    basliklar, baslik = [], ""
    for l in text.splitlines():
        if l.startswith("# ") and not baslik:
            baslik = l[2:].strip()
        if l.startswith(("# ", "## ")):
            basliklar.append(l.lstrip("# ").strip())
    paras = []
    for blok in re.split(r"\n\s*\n", text):
        b = " ".join(blok.split())
        if not b or b.startswith(("#", "|", "-", "*", ">", "```", "<")):
            continue
        paras.append(b)
        if len(paras) >= 4:
            break
    maddeler = [re.sub(r"\s+", " ", l.strip())[:220] for l in text.splitlines() if re.match(r"^\s*[-*]\s+\S", l)]
    return {"baslik": baslik, "basliklar": basliklar[:25], "paragraflar": paras,
            "madde_isaretleri": maddeler[:14], "tablo_sayisi": text.count("|---"),
            "kod_blogu": text.count("```") // 2}


def json_facts(text: str) -> dict:
    try:
        data = json.loads(text)
    except ValueError as exc:
        return {"hata": f"JSON çözümlenemedi: {exc}"}
    info: dict = {"tip": type(data).__name__}
    if isinstance(data, dict):
        info["anahtarlar"] = list(data.keys())[:60]
        info["_meta"] = data.get("_meta") if isinstance(data.get("_meta"), dict) else None
        info["kayit_sayisi"] = len(data)
    elif isinstance(data, list):
        info["kayit_sayisi"] = len(data)
        if data and isinstance(data[0], dict):
            info["ilk_kayit_anahtarlari"] = list(data[0].keys())[:25]
    return info


def env_kayitlari(text: str, files: list[str]) -> list[dict]:
    kayitlar, grup = [], "(başlıksız)"
    satirlar = text.split("\n")
    for i, satir in enumerate(satirlar):
        g = re.match(r"^#\s*---\s*(.+?)\s*---\s*$", satir)
        if g:
            grup = g.group(1)
            continue
        m = re.match(r"^([A-Z][A-Z0-9_]*)=(.*)$", satir)
        if not m:
            continue
        ad, deger = m.group(1), m.group(2).strip()
        yorum = []
        j = i - 1
        while j >= 0 and satirlar[j].startswith("#") and not satirlar[j].startswith("# ---"):
            yorum.insert(0, satirlar[j].lstrip("# ").strip())
            j -= 1
        aciklama = " ".join(yorum).strip()
        if ad.endswith(("_API_KEY", "_TOKEN")):
            zorunlu = "opsiyonel (kanal açılırsa gerekir)"
        elif ad.startswith(("ENABLE_", "PINEAL_ALLOW_")):
            zorunlu = "varsayılan KAPALI kapı"
        elif ad.startswith("VITE_"):
            zorunlu = "arayüz/dev kolaylığı"
        elif deger:
            zorunlu = "varsayılanlı (zorunlu değil)"
        else:
            zorunlu = "belirsiz (boş bırakılmış)"
        okuyan = [f for f in files if f.endswith((".py", ".ts", ".svelte"))
                  and ad in (read_text(f) or "")]
        kayitlar.append({"ad": ad, "grup": grup, "satir": i + 1, "varsayilan": deger,
                         "ne_ise_yarar": aciklama or "(yorum yok)", "zorunlu": zorunlu,
                         "zorunluluk_kaynagi": "dosyadaki yorum + kod araması (çıkarım)",
                         "okuyan_dosyalar": okuyan[:8], "okuyan_sayisi": len(okuyan)})
    return kayitlar


def compose_facts(text: str) -> dict:
    servisler = re.findall(r"^  ([a-z0-9_-]+):\s*$", text, re.M)
    imajlar = re.findall(r"image:\s*(\S+)", text)
    return {"servisler": servisler, "imajlar": imajlar, "satir_sayisi_kaba": len(text.splitlines())}


def docker_facts(text: str) -> dict:
    froms = re.findall(r"^FROM\s+(.+)$", text, re.M)
    envs = re.findall(r"^ENV\s+([A-Za-z_0-9]+)", text, re.M)
    cmds = re.findall(r"^(RUN|CMD|ENTRYPOINT|EXPOSE|HEALTHCHECK|COPY|WORKDIR)\b(.*)$", text, re.M)
    return {"temel_imajlar": froms, "env_degiskenleri": envs,
            "adimlar": [f"{c} {' '.join(a.split())[:110]}" for c, a in cmds][:25]}


def kt_facts(text: str) -> dict:
    return {"siniflar": re.findall(r"(?:class|object|interface)\s+([A-Za-z_0-9]+)", text)[:25],
            "composable_fonksiyonlar": re.findall(r"@Composable\s*(?:private\s+)?fun\s+([A-Za-z_0-9]+)", text)[:25],
            "fonksiyonlar": re.findall(r"^\s*(?:private\s+|internal\s+|public\s+)?(?:suspend\s+)?fun\s+([A-Za-z_0-9]+)", text, re.M)[:30],
            "importlar": [".".join(i.split(".")[:3]) for i in re.findall(r"^import\s+([A-Za-z0-9_.]+)", text, re.M)][:10]}


def gradle_facts(text: str) -> dict:
    return {"plugin_alias": re.findall(r"alias\(libs\.plugins\.([A-Za-z0-9_.]+)\)", text)[:12],
            "bagimlilik_alias": re.findall(r"(?:implementation|api|testImplementation|ksp)\(libs\.([A-Za-z0-9_.]+)\)", text)[:15],
            "namespace": (re.search(r'namespace\s*=\s*"([^"]+)"', text) or [None, ""])[1],
            "application_id": (re.search(r'applicationId\s*=\s*"([^"]+)"', text) or [None, ""])[1],
            "sdk": {k: (re.search(rf"{k}\s*=\s*(\d+)", text) or [None, ""])[1]
                    for k in ("compileSdk", "minSdk", "targetSdk")}}


def rs_facts(text: str) -> dict:
    crateler = []
    for u in re.findall(r"^\s*use\s+([A-Za-z_0-9]+)", text, re.M):
        if u not in crateler:
            crateler.append(u)
    return {"modul_belgesi": [l[3:].strip() for l in text.splitlines() if l.startswith("//!")][:8],
            "pub_ogeler": re.findall(r"pub\s+(?:async\s+)?(?:fn|struct|enum|trait|mod|const|type)\s+([A-Za-z_0-9]+)", text)[:40],
            "fonksiyonlar": re.findall(r"^\s*(?:async\s+)?fn\s+([A-Za-z_0-9]+)", text, re.M)[:30],
            "modlar": re.findall(r"^\s*(?:pub\s+)?mod\s+([A-Za-z_0-9]+)", text, re.M)[:15],
            "crate_kullanimi": crateler[:12],
            "tauri_komut": len(re.findall(r"#\[tauri::command\]", text)),
            "test_sayisi": len(re.findall(r"#\[(?:tokio::)?test\]", text))}


def svelte_facts(text: str) -> dict:
    return {"props": re.findall(r"export\s+let\s+([A-Za-z_0-9]+)", text),
            "olaylar": sorted(set(re.findall(r'dispatch\(\s*["\']([^"\']+)', text))),
            "store_abonelikleri": sorted({s for s in re.findall(r"\$([a-zA-Z_][a-zA-Z_0-9]*)", text)
                                          if s not in {"state"}})[:20],
            "ic_aktarimlar": [i for i in re.findall(r"from\s+['\"]([^'\"]+)['\"]", text)
                              if i.startswith((".", "$lib"))][:20]}


def ts_facts(text: str) -> dict:
    return {"disa_aktarilanlar": re.findall(r"export\s+(?:async\s+)?(?:function|const|let|class|type|interface)\s+([A-Za-z_0-9]+)", text)[:30],
            "ice_aktarimlar": re.findall(r"from\s+['\"]([^'\"]+)['\"]", text)[:25],
            "fetch_cagrilari": re.findall(r"fetch\(\s*[`\"']([^`\"']{0,60})", text)[:10]}


def image_facts(rel: str) -> dict:
    p = ROOT / rel
    try:
        ham = p.read_bytes()
    except OSError as exc:
        return {"hata": str(exc)}
    tip = next((v for k, v in IMG_MAGIC.items() if ham.startswith(k)), "bilinmiyor")
    bilgi = {"tip": tip, "bayt": len(ham)}
    try:
        from PIL import Image  # noqa: PLC0415
        import io as _io
        with Image.open(_io.BytesIO(ham)) as im:
            bilgi["boyut"] = f"{im.width}x{im.height}"
            bilgi["mod"] = im.mode
    except Exception:
        bilgi["boyut"] = "ölçülemedi (Pillow yok)"
    return bilgi


def cfg_facts(rel: str, text: str) -> dict:
    ad = os.path.basename(rel)
    if ad.startswith("requirements") or ad.endswith(".txt"):
        pk = [l.strip() for l in text.splitlines()
              if l.strip() and not l.strip().startswith("#") and re.match(r"^[A-Za-z0-9_.\-]+", l.strip())]
        return {"paketler": pk[:30], "paket_sayisi": len(pk), "surum_sabitli": sum(1 for x in pk if "==" in x)}
    anahtarlar = [l.split("=")[0].strip() for l in text.splitlines()
                  if "=" in l and not l.strip().startswith(("#", ";", "["))]
    return {"anahtarlar": anahtarlar[:30], "anahtar_sayisi": len(anahtarlar)}


def html_facts(text: str) -> dict:
    return {"baslik": (re.search(r"<title>([^<]*)</title>", text) or [None, ""])[1],
            "class_sayisi": len(set(re.findall(r'class="([^"]+)"', text))),
            "script_sayisi": text.count("<script")}


def sh_facts(text: str) -> dict:
    return {"komutlar": sorted({m.group(0) for m in re.finditer(
        r"\b(echo|cd|python|pip|curl|start|timeout|set|if|goto|call|exit|chmod|bash|npm|node|docker|git)\b", text)})}


def dot_facts(text: str) -> dict:
    satir = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
    return {"kalip_sayisi": len(satir), "ornek_kaliplar": satir[:10]}


# ------------------------------------------------------------------ düz Türkçe özet

def plain_role(rel: str, kind: str) -> str:
    if rel.startswith("agent_core/agents/"):
        return "Bu dosya, sistemin bir ANALİZ AJANI. Veriyi alır, dil modeline sorar ve yapılandırılmış bulgu döner."
    if rel.startswith("agent_core/services/"):
        return "Bu dosya bir SERVİS (sistemin organı): başka dosyaların kullandığı ortak bir yetenek sunar."
    if rel.startswith("agent_core/engines/"):
        return "Bu dosya bir MOTOR: dil modeli kullanmadan, saf matematikle ölçüm üretir."
    if rel.startswith("agent_core/capabilities/"):
        return "Bu dosya YETENEK OMURGASI parçası: dış araçları tek kapıdan, izin ve kasa denetimiyle çalıştırır."
    if rel.startswith("agent_core/mcp/"):
        return "Bu dosya MCP köprüsü: yetenekleri dış araçlara (ör. Claude Desktop) araç olarak sunar."
    if rel.startswith("agent_core/domain/"):
        return "Bu dosya VERİ ŞEMASI: neyin kaydedileceğini tipli olarak tanımlar."
    if rel.startswith("agent_core/"):
        return "Bu dosya çekirdek (agent_core) katmanında çalışır."
    if rel.startswith("backend/"):
        return "Bu dosya sunucu (backend) katmanında: HTTP/WebSocket isteklerini karşılar veya güvenliğini sağlar."
    if rel.startswith("tests/"):
        return "Bu dosya bir TEST: koddaki davranışı otomatik doğrular, kusurun geri gelmesini engeller."
    if rel.startswith("scripts/"):
        return "Bu dosya bir BETİK: elle veya CI'da çalıştırılan denetim/kurulum/doğrulama işi yapar."
    if rel.startswith("frontend/"):
        return "Bu dosya ÖN YÜZ (kokpit) katmanında: kullanıcının gördüğü ekranı ve etkileşimi kurar."
    if rel.startswith("rust_core/"):
        return "Bu dosya Rust tarafında derlenir; CI'da test edilir ama Python ürününe bağlı değildir."
    if rel.startswith("android/"):
        return "Bu dosya Android istemcisine ait (Kotlin/Compose)."
    if rel.startswith("skills/"):
        return "Bu dosya bir YETENEK TANIMI: hangi araç, hangi kapı, hangi girdi/çıktı."
    if rel.startswith("config/"):
        return "Bu dosya YAPILANDIRMA: kod içine gömülmeyen ayarlar buradan okunur."
    if rel.startswith("docs/") or rel.endswith(".md"):
        return "Bu dosya DOKÜMAN: karar, sözleşme veya denetim kaydı."
    if rel.startswith("functions/"):
        return "Bu dosya Cloudflare üzerinde çalışan bir PROXY işlevi."
    if rel.startswith(".github/"):
        return "Bu dosya GitHub CI iş akışı (otomatik denetim hattı) tanımı."
    if rel.startswith("release/"):
        return "Bu dosya sürüm/yayın kapısı yapılandırması."
    yer = "depo kökünde" if "/" not in rel else "depo içinde"
    adlar = {"python": "çalıştırılabilir bir Python betiği (giriş noktası/araç)",
             "typescript": "bir TypeScript/JavaScript modülü", "shell": "çalıştırılan bir kabuk/başlatma betiği",
             "markdown": "bir belge", "json": "bir JSON yapılandırma/işaret dosyası",
             "yaml": "bir YAML yapılandırma dosyası", "config-text": "bir yapılandırma (ayar) dosyası",
             "version": "sürüm numarasını tutan işaret dosyası", "lock": "bağımlılık kilidi (lock) dosyası",
             "dockerfile": "konteyner imaj tarifi"}
    return f"Bu dosya {yer} {adlar.get(kind, 'yer alan bir yardımcı dosya')}."


def sade_ozet(rel: str, kind: str, text: str, facts: dict) -> str:
    role = plain_role(rel, kind)
    if kind == "python":
        doc = (facts.get("modul_docstring") or "").strip()
        ilk = next((l.strip() for l in doc.splitlines() if l.strip()), "")
        testler = facts.get("testler") or []
        if os.path.basename(rel).startswith("test_") or rel.startswith("tests/"):
            return (f"{role} İçindeki {len(testler)} test: "
                    + (", ".join(testler[:7]) if testler else "test fonksiyonu bulunamadı")
                    + (f". Dosya başındaki açıklama: {ilk[:200]}" if ilk else ""))
        siniflar = [c["ad"] for c in facts.get("siniflar", [])]
        fonksiyonlar = [f["ad"] for f in facts.get("fonksiyonlar", [])]
        if ilk:
            return f"{role} Dosyanın kendi açıklaması: {ilk[:260]}"
        parca = []
        if siniflar:
            parca.append(f"{len(siniflar)} sınıf ({', '.join(siniflar[:4])})")
        if fonksiyonlar:
            parca.append(f"{len(fonksiyonlar)} fonksiyon ({', '.join(fonksiyonlar[:5])})")
        return (f"{role} Dosyanın kendi açıklaması YOK; içerik okundu: "
                + ("; ".join(parca) if parca else "tanımlı sınıf/fonksiyon bulunamadı") + ".")
    if kind == "markdown":
        f = md_facts(text)
        return (f"{role} Başlık: “{f['baslik'] or (f['basliklar'][0] if f['basliklar'] else '')}”. "
                f"{len(f['basliklar'])} alt başlık, {len(f['madde_isaretleri'])} madde işareti, "
                f"{f['kod_blogu']} kod bloğu. İlk paragraf: {' '.join(f['paragraflar'])[:180] or '—'}")
    if kind == "json":
        f = json_facts(text)
        anahtar = f.get("anahtarlar") or f.get("ilk_kayit_anahtarlari") or []
        return (f"{role} JSON okundu: {f.get('kayit_sayisi', '?')} kayıt/anahtar. "
                + (f"Üst düzey alanlar: {', '.join(anahtar[:10])}." if anahtar else "Kayıt bir liste."))
    if kind == "env":
        n = len([l for l in text.splitlines() if re.match(r"^[A-Z][A-Z0-9_]*=", l)])
        return f"{role} İçinde {n} ortam değişkeni tanımlı; her biri yorumuyla çözümlendi."
    if kind == "svelte":
        f = svelte_facts(text)
        return (f"{role} props: {', '.join(f['props']) or 'yok'}; olaylar: {', '.join(f['olaylar']) or 'yok'}; "
                f"store'lar: {', '.join(f['store_abonelikleri'][:6]) or 'yok'}; "
                f"içe aktarımlar: {', '.join(f['ic_aktarimlar'][:4]) or 'yok'}.")
    if kind == "typescript":
        f = ts_facts(text)
        return (f"{role} Dışa aktardıkları: {', '.join(f['disa_aktarilanlar'][:8]) or 'yok'}; "
                f"içe aktarımlar: {', '.join(f['ice_aktarimlar'][:4]) or 'yok'}"
                + (f"; çağırdığı adresler: {', '.join(f['fetch_cagrilari'][:3])}" if f["fetch_cagrilari"] else "") + ".")
    if kind == "kotlin":
        f = kt_facts(text)
        return (f"{role} Türler: {', '.join(f['siniflar'][:6]) or 'yok'}; @Composable: "
                f"{', '.join(f['composable_fonksiyonlar'][:6]) or 'yok'}; {len(f['fonksiyonlar'])} fonksiyon. "
                f"Kullandığı paketler: {', '.join(f['importlar'][:5]) or '—'}.")
    if kind == "gradle-kts":
        f = gradle_facts(text)
        ek = [f"libs.plugins.{a}" for a in f["plugin_alias"]]
        bag = [f"libs.{a}" for a in f["bagimlilik_alias"]]
        sdk = ", ".join(f"{k}={v}" for k, v in f["sdk"].items() if v)
        return (f"{role} Plugin'ler: {', '.join(ek[:8]) or '—'}; bağımlılıklar: {', '.join(bag[:8]) or '—'}"
                + (f"; namespace: {f['namespace']}" if f["namespace"] else "")
                + (f"; applicationId: {f['application_id']}" if f["application_id"] else "")
                + (f"; SDK: {sdk}" if sdk else "") + ".")
    if kind == "rust":
        f = rs_facts(text)
        ogeler = f["pub_ogeler"] or f["fonksiyonlar"]
        return (f"{role} Başlıca öğeler: {', '.join(ogeler[:10]) or '—'}"
                + (f"; modüller: {', '.join(f['modlar'][:6])}" if f["modlar"] else "")
                + (f"; crate'ler: {', '.join(f['crate_kullanimi'][:6])}" if f["crate_kullanimi"] else "")
                + (f"; {f['tauri_komut']} tauri komutu" if f["tauri_komut"] else "")
                + f"; {f['test_sayisi']} test"
                + (f"; modül belgesi: {f['modul_belgesi'][0][:110]}" if f["modul_belgesi"] else "") + ".")
    if kind == "shell":
        return f"{role} Komutlar: {', '.join(sh_facts(text)['komutlar'][:10])}."
    if kind == "config-text":
        if rel.endswith(".xml"):
            adlar = re.findall(r'name="([^"]+)"', text)[:8]
            return (f"{role} XML kaynak dosyası: {len(re.findall(r'<[A-Za-z_]', text))} öğe"
                    + (f"; tanımlı adlar: {', '.join(adlar)}" if adlar else "") + ".")
        f = cfg_facts(rel, text)
        if "paketler" in f:
            return (f"{role} {f['paket_sayisi']} paket listeler ({f['surum_sabitli']} tanesi sürüm sabitli): "
                    f"{', '.join(p.split('==')[0].split('>')[0].split('[')[0] for p in f['paketler'][:12])}.")
        return (f"{role} Anahtarlar: {', '.join(f['anahtarlar'][:12]) or '—'}"
                + (f" (toplam {f['anahtar_sayisi']})" if f.get("anahtar_sayisi") else "") + ".")
    if kind == "web-static":
        if rel.endswith(".html"):
            f = html_facts(text)
            return (f"{role} HTML: başlık “{f['baslik']}”, {f['class_sayisi']} farklı CSS sınıfı, "
                    f"{f['script_sayisi']} script etiketi.")
        degisken = re.findall(r"--([A-Za-z0-9_-]+)\s*:", text)
        return (f"{role} CSS: {len(re.findall(r'[^{}]+{[^}]*}', text))} kural bloğu, {len(degisken)} CSS değişkeni"
                + (f" ({', '.join(degisken[:6])})" if degisken else "") + f", {len(re.findall(r'@media', text))} medya sorgusu.")
    if kind == "svg":
        vb = (re.search(r'viewBox="([^"]+)"', text) or [None, ""])[1]
        return (f"{role} SVG çizim verisi: viewBox={vb or '—'}, {len(re.findall(r'<path', text))} path öğesi; "
                "kod mantığı yok.")
    if kind == "image":
        f = image_facts(rel)
        return (f"{role} Görsel dosya (metin değil): {f.get('tip')}, {f.get('boyut')}, {f.get('bayt', 0)} bayt. "
                "Piksel içeriği YORUMLANMADI.")
    if kind == "lock":
        return "Kilit dosyası: bağımlılık sürümlerini sabitler (elle düzenlenmez)."
    if kind == "version":
        return f"Sürüm numarası dosyası: içeriği “{text.strip()}”."
    if kind == "dockerfile":
        f = docker_facts(text)
        return (f"{role} Temel imajlar: {', '.join(f['temel_imajlar'])}; {len(f['adimlar'])} kurulum adımı; "
                f"ENV: {', '.join(f['env_degiskenleri'][:8]) or '—'}.")
    if kind == "compose":
        f = compose_facts(text)
        return (f"{role} {len(f['servisler'])} servis: {', '.join(f['servisler'][:14])}; "
                f"imajlar: {', '.join(f['imajlar'][:5]) or '—'}.")
    f = dot_facts(text)
    if f["kalip_sayisi"] <= 3:
        return f"{role} İçeriği: {'; '.join(f['ornek_kaliplar'])}" if f["ornek_kaliplar"] else f"{role} Dosya boş."
    return (f"{role} İçerik: {f['kalip_sayisi']} satır kural"
            + (f" ({', '.join(f['ornek_kaliplar'][:6])})" if f["ornek_kaliplar"] else "") + ".")


def detect_kind(rel: str) -> str:
    ad = os.path.basename(rel)
    uz = os.path.splitext(ad)[1].lower()
    if ad == "Dockerfile":
        return "dockerfile"
    if ad == "VERSION":
        return "version"
    if ad.endswith(".env.example"):
        return "env"
    if ad == "docker-compose.yml":
        return "compose"
    if uz == ".md":
        return "markdown"
    if uz == ".py":
        return "python"
    if uz == ".json":
        return "json"
    if uz in (".yaml", ".yml"):
        return "yaml"
    if uz == ".svelte":
        return "svelte"
    if uz in (".ts", ".js"):
        return "typescript"
    if uz == ".kt":
        return "kotlin"
    if uz == ".kts":
        return "gradle-kts"
    if uz == ".rs":
        return "rust"
    if uz in (".sh", ".bat", ".ps1"):
        return "shell"
    if uz in (".png", ".jpg", ".jpeg", ".ico", ".icns", ".gif"):
        return "image"
    if uz == ".svg":
        return "svg"
    if uz == ".lock":
        return "lock"
    if uz in (".toml", ".ini", ".properties", ".txt", ".xml", ".cfg", ".example"):
        return "config-text"
    if uz in (".html", ".css"):
        return "web-static"
    return "diger"


def py_status(rel: str, facts: dict) -> tuple[str, list[str]]:
    belirsiz: list[str] = []
    if facts.get("sozdizimi_hatasi"):
        return "OKUNAMADI", ["Python söz dizimi çözümlenemedi: " + facts["sozdizimi_hatasi"]]
    low = (rel + " " + (facts.get("modul_docstring") or "")).lower()
    if any(k in low for k in ("devre dışı", "devre disi", "disabled", "deprecated", "kullanımdan kaldır")):
        return "devre_disi", belirsiz
    if any(k in low for k in ("deneysel", "experimental", "beta")):
        return "deneysel", ["'deneysel' etiketi dosya adı/docstring'inden ÇIKARILDI"]
    if rel.startswith("tests/") or os.path.basename(rel).startswith("test_"):
        return "calisiyor", ["test dosyası: koşulması CI'ya/pytest'e bağlı"]
    if rel in ENTRYPOINTS or rel.endswith("/__init__.py"):
        return "calisiyor", belirsiz
    if rel.startswith("scripts/archive/"):
        return "devre_disi", ["arşiv klasörü: üretim akışında çağrılmıyor (scripts/archive/README.md)"]
    if not IMPORTERS.get(rel) and not textual_refs(rel, [rel]) :
        belirsiz.append("hiçbir dosya bu modülü import etmiyor (dinamik import olabilir)")
        return "olu_kod", belirsiz
    if not IMPORTERS.get(rel):
        belirsiz.append("statik import edeni yok; yalnız metinde geçiyor (betik/CLI çağrısı olabilir)")
        return "olu_kod", belirsiz
    return "calisiyor", belirsiz


def record(rel: str, files: list[str]) -> dict:
    kind = detect_kind(rel)
    text = read_text(rel)
    rec = {"yol": rel, "satir_sayisi": loc(rel), "tip": kind, "ne_yapar_sade": "", "teknik_ozet": "",
           "ana_siniflar_fonksiyonlar": [], "girdi": "", "cikti": "",
           "bagimliliklar": {"ic": [], "dis": []}, "kim_cagirir": {"import_edenler": [], "metinsel_gecenler": []},
           "dis_etki": [], "guvenlik_notu": "", "durum": "", "belirsizlikler": [], "okunamadi": ""}
    if text is None:
        sebep = "ikili (binary) içerik: NUL baytı var"
        rec["okunamadi"] = f"OKUNAMADI: {sebep}"
        rec["ne_yapar_sade"] = f"{plain_role(rel, kind)} Metin olarak okunamadı: {sebep}."
        ek = json.dumps(image_facts(rel), ensure_ascii=False) if kind == "image" else "{}"
        rec["teknik_ozet"] = f"İkili/okunamayan dosya. Sebep: {sebep} Ölçüm: {ek}"
        rec["durum"] = "OKUNAMADI"
        rec["belirsizlikler"].append("İçerik metin değil; kaynak kodu değil, veri/ikili dosya.")
        return rec

    raw = text
    if kind == "python":
        facts = py_facts(rel, text)
        durum, belirsiz = py_status(rel, facts)
        rec["durum"] = durum
        rec["belirsizlikler"] += belirsiz
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, facts)
        ilk = (facts["modul_docstring"] or "").strip().split("\n")[0]
        rec["teknik_ozet"] = (ilk[:280] or "modül docstring'i yok") + \
            f" | {len(facts['siniflar'])} sınıf, {len(facts['fonksiyonlar'])} fonksiyon, " \
            f"{len(facts['sabitler'])} sabit, {len(facts['testler'])} test"
        rec["ana_siniflar_fonksiyonlar"] = (
            [f"{c['ad']}: {c['docstring'] or 'açıklama yok'} (satır {c['satir']})" for c in facts["siniflar"][:12]]
            + [f"{f['imza']} — {f['docstring'] or 'açıklama yok'} (satır {f['satir']})" for f in facts["fonksiyonlar"][:20]]
            + (["TESTLER (" + str(len(facts["testler"])) + "): " + ", ".join(facts["testler"][:10])] if facts["testler"] else []))
        args, outs = [], []
        for f in facts["fonksiyonlar"] + [m for c in facts["siniflar"] for m in c["metotlar"]]:
            if "(" in f.get("imza", ""):
                ic = f["imza"].split("(", 1)[1].rstrip(")")
                if ic:
                    args.append(ic)
            if f.get("dondurur"):
                outs.append(f["dondurur"])
        rec["girdi"] = ("Fonksiyon parametreleri: " + "; ".join(args[:12])) if args else "Dışa açık parametre yok."
        rec["cikti"] = ("Döndürdüğü tipler: " + ", ".join(sorted(set(outs))[:12])) if outs else "Dönüş anotasyonu yok."
        rec["bagimliliklar"]["ic"] = facts["ic_bagimliliklar"]
        rec["kim_cagirir"]["import_edenler"] = sorted(IMPORTERS.get(rel, set()))
    elif kind == "markdown":
        f = md_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = f"Başlık: {f['baslik']} | Alt başlıklar: " + " · ".join(f["basliklar"][:12])
        rec["ana_siniflar_fonksiyonlar"] = [f"Alt başlık: {h}" for h in f["basliklar"][:20]]
        rec["girdi"], rec["cikti"] = "İnsan okuyucu.", "Karar/sözleşme/rapor metni."
        rec["durum"] = "calisiyor"
        rec["_paragraflar"], rec["_bulgular"] = f["paragraflar"], f["madde_isaretleri"]
    elif kind == "json":
        f = json_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:1600]
        rec["ana_siniflar_fonksiyonlar"] = ([f"_meta.{k}: {str(v)[:200]}" for k, v in (f.get("_meta") or {}).items()]
                                            or [f"anahtar: {k}" for k in f.get("anahtarlar", [])[:30]])
        rec["durum"] = "calisiyor"
        rec["girdi"], rec["cikti"] = "Kodu çalıştıran servisler (JSON okunur).", "Yapılandırma değerleri."
        rec["dis_etki"] = ["dosya"]
        rec["guvenlik_notu"] = "Bu dosyada gizli anahtar aranmadı: yapılandırma değerleri."
    elif kind == "env":
        ayarlar = env_kayitlari(text, files)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = f"{len(ayarlar)} ortam değişkeni; ad, varsayılan, zorunluluk ve okuyan dosyalar çıkarıldı."
        rec["ana_siniflar_fonksiyonlar"] = [f"{a['ad']} = {a['varsayilan']!r} — {a['ne_ise_yarar'][:120]}" for a in ayarlar]
        rec["durum"] = "calisiyor"
        rec["girdi"], rec["cikti"] = "İşletim sistemi ortamı / .env", "Kodun okuduğu ayar değerleri"
        rec["guvenlik_notu"] = ("Bu dosya ÖRNEK şablondur; gerçek sır barındırmaz. Anahtar alanları boştur ve "
                                "üretimde fail-closed kapılar bu değerlere bağlıdır.")
        rec["belirsizlikler"].append("Zorunluluk bilgisi dosyadaki yorum + kod aramasından ÇIKARILDI.")
        rec["_ayarlar"] = ayarlar
    elif kind == "compose":
        f = compose_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:1500]
        rec["ana_siniflar_fonksiyonlar"] = [f"servis: {s}" for s in f["servisler"]] + [f"imaj: {i}" for i in f["imajlar"][:12]]
        rec["durum"] = "calisiyor"
        rec["dis_etki"] = ["dosya"]
    elif kind == "dockerfile":
        f = docker_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:1500]
        rec["ana_siniflar_fonksiyonlar"] = f["adimlar"]
        rec["durum"] = "calisiyor"
        rec["dis_etki"] = ["dosya", "süreç/komut"]
    elif kind == "svelte":
        f = svelte_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:1500]
        rec["ana_siniflar_fonksiyonlar"] = ([f"prop: {p}" for p in f["props"]] + [f"olay: {e}" for e in f["olaylar"]]
                                            + [f"store aboneliği: {s}" for s in f["store_abonelikleri"]])
        rec["girdi"] = "props: " + (", ".join(f["props"]) or "—") + " | store: " + (", ".join(f["store_abonelikleri"]) or "—")
        rec["cikti"] = "Ekrana basılan arayüz + dispatch edilen olaylar: " + (", ".join(f["olaylar"]) or "—")
        rec["dis_etki"] = (["ağ"] if ("fetch(" in text or "/api/" in text or "WebSocket" in text) else []) + ["dosya"]
        rec["durum"] = "calisiyor"
    elif kind in ("typescript", "web-static", "kotlin", "gradle-kts", "rust", "svg", "config-text", "shell"):
        facts = {"typescript": ts_facts, "kotlin": kt_facts, "gradle-kts": gradle_facts, "rust": rs_facts,
                 "config-text": lambda t: cfg_facts(rel, t), "shell": sh_facts,
                 "svg": lambda t: {"path": len(re.findall(r"<path", t))},
                 "web-static": html_facts}.get(kind, lambda t: {})
        try:
            f = facts(text) if kind != "config-text" else cfg_facts(rel, text)
        except Exception:
            f = {}
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:1200]
        rec["ana_siniflar_fonksiyonlar"] = (
            [f"dışa aktarılan: {n}" for n in f.get("disa_aktarilanlar", [])]
            or [f"class/object: {c}" for c in f.get("siniflar", [])] + [f"@Composable {c}()" for c in f.get("composable_fonksiyonlar", [])]
            or [f"pub {n}" for n in f.get("pub_ogeler", [])[:30]]
            or [f"plugin: {n}" for n in f.get("plugin_alias", [])] + [f"bağımlılık: {n}" for n in f.get("bagimlilik_alias", [])]
            or [f"anahtar: {k}" for k in f.get("anahtarlar", [])]
            or [f"paket: {p}" for p in f.get("paketler", [])[:25]])
        rec["durum"] = "calisiyor"
        rec["dis_etki"] = (["ağ"] if ("HttpURLConnection" in text or "okhttp" in text or "Retrofit" in text
                                      or f.get("fetch_cagrilari")) else []) + (["süreç/komut"] if kind == "shell" else ["dosya"])
    elif kind == "image":
        f = image_facts(rel)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)
        rec["durum"] = "calisiyor"
    elif kind == "lock":
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = f"{len(text.splitlines())} satır kilit kaydı."
        rec["durum"] = "calisiyor"
    elif kind == "version":
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = text.strip()
        rec["durum"] = "calisiyor"
    else:  # yaml / diger
        f = dot_facts(text)
        rec["ne_yapar_sade"] = sade_ozet(rel, kind, text, {})
        rec["teknik_ozet"] = json.dumps(f, ensure_ascii=False)[:800]
        rec["ana_siniflar_fonksiyonlar"] = [f"kural: {k}" for k in f["ornek_kaliplar"]]
        rec["durum"] = "calisiyor"

    # ortak alanlar
    rec["dis_etki"] = sorted(set(rec["dis_etki"] + (
        (["ağ"] if NET_PAT.search(raw) else []) + (["LLM çağrısı"] if LLM_PAT.search(raw) else [])
        + (["dosya"] if FILE_PAT.search(raw) else []) + (["DB/depo"] if DB_PAT.search(raw) else [])
        + (["süreç/komut"] if PROC_PAT.search(raw) else []))))
    guvenlik = []
    if VAULT_PAT.search(raw):
        guvenlik.append("kasa (vault) kapısı")
    if MINOR_PAT.search(raw):
        guvenlik.append("çocuk kilidi")
    if AUTH_PAT.search(raw):
        guvenlik.append("kimlik/token")
    if SSRF_PAT.search(raw):
        guvenlik.append("SSRF/egress sınırı")
    rec["guvenlik_notu"] = ("Bu dosyada geçen güvenlik kavramları: " + ", ".join(guvenlik) + ".") if guvenlik \
        else "Bu dosyada kasa/çocuk kilidi/token/SSRF deseni bulunmadı (tarama: regex)."
    rec["kim_cagirir"]["metinsel_gecenler"] = textual_refs(rel, files)
    if kind != "python":
        rec["durum"] = rec["durum"] or "calisiyor"
        rec["bagimliliklar"] = {"ic": [], "dis": []}
    imp = rec["kim_cagirir"]["import_edenler"]
    if imp and rel not in ELLE_OZETLER:
        kisa = ", ".join(imp[:4]) + (f" (+{len(imp) - 4})" if len(imp) > 4 else "")
        rec["ne_yapar_sade"] = rec["ne_yapar_sade"].rstrip() + f" Bu dosyayı kullanan dosyalar ({len(imp)}): {kisa}."
    if rel in ELLE_OZETLER:
        rec["ne_yapar_sade"] = ELLE_OZETLER[rel]
        rec["belirsizlikler"].append("ne_yapar_sade ELLE yazıldı: dosya 500 satırlık dilimlerle baştan sona okundu.")
    return rec


def main() -> int:
    files = list_files()
    DOSYALAR.mkdir(parents=True, exist_ok=True)
    MODULE_INDEX.clear(); IMPORTERS.clear(); IC_IMPORT.clear()
    build_graph(files)
    kayitlar, okunamadi = [], []
    for rel in files:
        rec = record(rel, files)
        if rec.get("okunamadi"):
            okunamadi.append({"yol": rel, "sebep": rec["okunamadi"]})
        kayitlar.append(rec)
    gruplar: dict[str, list] = defaultdict(list)
    for rec in kayitlar:
        d = os.path.dirname(rec["yol"])
        gruplar[d.replace("/", "__") if d else "kok"].append(rec)
    for key, items in gruplar.items():
        (DOSYALAR / f"{key}.json").write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
    INDEX = [{"yol": r["yol"], "satir": r["satir_sayisi"], "tip": r["tip"], "durum": r["durum"],
              "okunamadi": bool(r.get("okunamadi"))} for r in kayitlar]
    (OUT / "INDEX.json").write_text(json.dumps(INDEX, ensure_ascii=False, indent=1), encoding="utf-8")
    (OUT / "_ham_kayitlar.json").write_text(json.dumps(kayitlar, ensure_ascii=False), encoding="utf-8")
    # çapraz betikler için grafik
    (OUT / "_grafik.json").write_text(json.dumps(
        {"ic_import": {k: sorted(v) for k, v in IC_IMPORT.items()},
         "importer": {k: sorted(v) for k, v in IMPORTERS.items()}}, ensure_ascii=False), encoding="utf-8")
    from collections import Counter
    print(f"dosya: {len(files)} | belgelenen: {len(kayitlar)} | okunamayan(kayıt): {len(okunamadi)} | "
          f"klasör: {len(gruplar)} | durum: {dict(Counter(r['durum'] for r in kayitlar))}")
    print("boş açıklama:", sum(1 for r in kayitlar if not (r["ne_yapar_sade"] or "").strip()),
          "| ort. uzunluk:", round(sum(len(r["ne_yapar_sade"]) for r in kayitlar) / len(kayitlar)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
