# API — TAM UÇ LİSTESİ (koddan üretildi)

Toplam **70** uç; kaynak: `@app.*` dekoratörleri (backend/api.py, backend/routes/__init__.py, backend/routes/language.py, backend/routes/support.py, backend/routes/tasks.py, backend/routes/websocket.py).

Sütun anahtarı: **Hız sınırı** kod içindeki `rate_limit(...)` çağrısından; **GLOBAL** = kendi kovası yok, genel `api` kovası (300/60sn). **Kasa**: E = vault denetimi var, E/H = `_require_vault_open` yardımcı kapısı. **Çocuk kilidi**: E = `_require_minor_clearance`. **Görev sahipliği**: E = `guard_task`/`visible_tasks`/`principal`.

| # | Yöntem | Yol | Dosya:satır | Handler | Hız | Kasa | Çocuk | Sahiplik |
|---|---|---|---|---|---|---|---|---|
| 1 | GET | `/health` | backend/api.py:227 | `health` | GLOBAL | — | — | — |
| 2 | GET | `/v1/models` | backend/api.py:1405 | `openai_models` | GLOBAL | — | — | — |
| 3 | POST | `/v1/chat/completions` | backend/api.py:1508 | `openai_chat_completions` | GLOBAL | — | — | — |
| 4 | WEBSOCKET | `/ws/{client_id}` | backend/api.py:2225 | `websocket_endpoint` | GLOBAL | E | — | — |
| 5 | POST | `/api/initiate` | backend/api.py:2849 | `api_initiate` | GLOBAL | E/H | E | E |
| 6 | POST | `/api/vault` | backend/api.py:2924 | `api_vault` | GLOBAL | E | — | — |
| 7 | POST | `/api/override` | backend/api.py:3120 | `api_override` | GLOBAL | E | — | — |
| 8 | GET | `/api/telemetry` | backend/api.py:3138 | `api_telemetry` | GLOBAL | E | — | — |
| 9 | GET | `/api/agents/status` | backend/api.py:3189 | `api_agents_status` | GLOBAL | E | — | — |
| 10 | POST | `/api/agents/status/{agent_id}` | backend/api.py:3214 | `api_update_agent_status` | GLOBAL | E | — | — |
| 11 | GET | `/api/vault/status` | backend/api.py:3249 | `api_vault_status` | GLOBAL | E | — | — |
| 12 | POST | `/api/vault/status` | backend/api.py:3273 | `api_vault_status_toggle` | GLOBAL | E | — | — |
| 13 | POST | `/api/vault/lock` | backend/api.py:3283 | `api_vault_lock` | GLOBAL | E | — | — |
| 14 | POST | `/api/vault/unlock` | backend/api.py:3293 | `api_vault_unlock` | GLOBAL | E | — | — |
| 15 | POST | `/api/minor/case` | backend/api.py:3673 | `api_minor_case_register` | GLOBAL | — | — | — |
| 16 | POST | `/api/minor/clear` | backend/api.py:3737 | `api_minor_case_clear` | GLOBAL | — | — | — |
| 17 | GET | `/api/minor/state` | backend/api.py:3749 | `api_minor_case_state` | GLOBAL | — | — | — |
| 18 | GET | `/api/dialogue/sessions` | backend/api.py:3788 | `api_dialogue_sessions` | GLOBAL | — | — | — |
| 19 | POST | `/api/experimental/maigret/scan` | backend/api.py:3899 | `maigret_scan` | GLOBAL | E/H | E | — |
| 20 | POST | `/api/experimental/holehe/scan` | backend/api.py:3931 | `holehe_scan` | GLOBAL | E/H | E | — |
| 21 | POST | `/api/experimental/crawl/fetch` | backend/api.py:3962 | `crawl_fetch` | GLOBAL | E/H | E | — |
| 22 | GET | `/api/experimental/stealth` | backend/api.py:3983 | `stealth_resolve` | GLOBAL | E/H | E | — |
| 23 | POST | `/api/experimental/socid/extract` | backend/api.py:3995 | `socid_extract` | GLOBAL | E/H | E | — |
| 24 | POST | `/api/experimental/shadow/analyze` | backend/api.py:4015 | `shadow_analyze` | GLOBAL | — | E | — |
| 25 | POST | `/api/experimental/shadow/generate` | backend/api.py:4031 | `shadow_generate` | GLOBAL | — | E | — |
| 26 | POST | `/api/experimental/chat/respond` | backend/api.py:4053 | `chat_respond` | GLOBAL | — | E | E |
| 27 | POST | `/api/aspasia/command` | backend/api.py:4147 | `aspasia_command` | GLOBAL | — | — | — |
| 28 | GET | `/api/aspasia/state` | backend/api.py:4173 | `aspasia_state` | GLOBAL | — | — | — |
| 29 | POST | `/api/aspasia/chat` | backend/api.py:4200 | `aspasia_chat` | GLOBAL | — | — | — |
| 30 | POST | `/api/browser/open` | backend/api.py:4430 | `api_browser_open` | GLOBAL | E/H | E | — |
| 31 | GET | `/api/browser/shot` | backend/api.py:4447 | `api_browser_shot` | GLOBAL | E/H | E | — |
| 32 | GET | `/api/browser/state` | backend/api.py:4463 | `api_browser_state` | GLOBAL | E/H | E | — |
| 33 | POST | `/api/browser/click` | backend/api.py:4478 | `api_browser_click` | GLOBAL | E/H | E | — |
| 34 | POST | `/api/browser/type` | backend/api.py:4492 | `api_browser_type` | GLOBAL | E/H | E | — |
| 35 | POST | `/api/browser/press` | backend/api.py:4507 | `api_browser_press` | GLOBAL | E/H | E | — |
| 36 | POST | `/api/browser/back` | backend/api.py:4521 | `api_browser_back` | GLOBAL | E/H | E | — |
| 37 | POST | `/api/browser/save` | backend/api.py:4535 | `api_browser_save` | GLOBAL | E/H | E | — |
| 38 | POST | `/api/browser/close` | backend/api.py:4558 | `api_browser_close` | GLOBAL | E/H | E | — |
| 39 | POST | `/api/scraper/authorize-alternative` | backend/api.py:4568 | `authorize_scraper_alternative` | GLOBAL | E/H | E | — |
| 40 | POST | `/api/executor/intervene` | backend/api.py:4629 | `executor_intervene` | GLOBAL | E/H | E | — |
| 41 | POST | `/api/experimental/interpreter/execute` | backend/api.py:4665 | `interpreter_execute` | GLOBAL | E/H | E | E |
| 42 | GET | `/api/tasks/{task_id}/changes` | backend/api.py:4793 | `api_task_changes` | GLOBAL | — | — | — |
| 43 | GET | `/api/tasks/{task_id}/graph` | backend/api.py:4847 | `api_task_graph` | GLOBAL | — | — | — |
| 44 | GET | `/api/memory/{target}` | backend/api.py:4912 | `api_memory_crystal` | GLOBAL | — | — | — |
| 45 | GET | `/api/memory/{target}/recall` | backend/api.py:4924 | `api_memory_recall` | GLOBAL | — | — | — |
| 46 | GET | `/api/telemetry/taste` | backend/api.py:4947 | `api_telemetry_taste` | GLOBAL | — | — | — |
| 47 | GET | `/api/calibration` | backend/api.py:4960 | `api_calibration` | GLOBAL | — | — | — |
| 48 | POST | `/api/calibration/observations` | backend/api.py:4983 | `api_calibration_record` | GLOBAL | — | — | — |
| 49 | POST | `/api/calibration/adjudicate` | backend/api.py:5009 | `api_calibration_adjudicate` | GLOBAL | — | — | — |
| 50 | GET | `/api/tasks/{task_id}/memory` | backend/api.py:5027 | `api_task_memory` | GLOBAL | — | — | — |
| 51 | GET | `/api/speech/status` | backend/api.py:5120 | `api_speech_status` | GLOBAL | E | — | — |
| 52 | POST | `/api/speech/report` | backend/api.py:5136 | `api_speech_report` | GLOBAL | E | — | — |
| 53 | POST | `/api/speech/listen` | backend/api.py:5168 | `api_speech_listen` | GLOBAL | E | — | — |
| 54 | POST | `/api/speech/say` | backend/api.py:5240 | `api_speech_say` | GLOBAL | E | — | — |
| 55 | GET | `/api/speech/audio/{name}` | backend/api.py:5286 | `api_speech_audio` | GLOBAL | — | — | — |
| 56 | POST | `/api/speech/stop` | backend/api.py:5308 | `api_speech_stop` | GLOBAL | E | — | — |
| 57 | GET | `/api/jury/status` | backend/api.py:5340 | `api_jury_status` | GLOBAL | E | — | — |
| 58 | POST | `/api/jury/vote` | backend/api.py:5349 | `api_jury_vote` | GLOBAL | E | — | — |
| 59 | GET | `/api/media/status` | backend/api.py:5436 | `api_media_status` | GLOBAL | E | — | — |
| 60 | POST | `/api/media/analyze` | backend/api.py:5474 | `api_media_analyze` | GLOBAL | E | — | — |
| 61 | GET | `/api/report/status` | backend/api.py:5567 | `api_report_status` | GLOBAL | E | — | — |
| 62 | POST | `/api/report/build` | backend/api.py:5589 | `api_report_build` | GLOBAL | E | — | — |
| 63 | GET | `/api/company/status` | backend/api.py:5691 | `api_company_status` | GLOBAL | E | — | — |
| 64 | POST | `/api/company/scan` | backend/api.py:5721 | `api_company_scan` | GLOBAL | E | — | — |
| 65 | GET | `/api/mcp/status` | backend/api.py:5824 | `api_mcp_status` | GLOBAL | E | — | — |
| 66 | POST | `/api/tasks/{task_id}/cancel` | backend/api.py:5898 | `api_cancel_task` | GLOBAL | — | — | — |
| 67 | POST | `/api/tasks/{task_id}/halt` | backend/api.py:5903 | `api_halt_task` | GLOBAL | — | — | — |
| 68 | GET | `/api/language/status` | backend/routes/language.py:70 | `api_language_status` | GLOBAL | E | — | — |
| 69 | POST | `/api/language/detect` | backend/routes/language.py:83 | `api_language_detect` | GLOBAL | E | — | — |
| 70 | POST | `/api/language/translate` | backend/routes/language.py:132 | `api_language_translate` | GLOBAL | E | — | — |

> Not: WebSocket ucu (`/ws/{client_id}`) HTTP değildir; kimlik doğrulama middleware'inden geçer ve oda (room) sahipliğiyle sınırlanır.

## Hız sınırı kovaları (backend/api.py → RATE_LIMITS)

| Kova | Sınır (istek/sn) |
|---|---|
| `api` | 300/60 sn |
| `initiate` | 5/60 sn |
| `aspasia` | 20/60 sn |
| `experimental` | 10/60 sn |
| `openai` | 60/60 sn |
| `speech` | 30/60 sn |
| `media` | 6/60 sn |
| `report` | 10/60 sn |
| `company` | 8/60 sn |
| `jury` | 6/60 sn |
| `language` | 60/60 sn |
| `ws` | 30/60 sn |