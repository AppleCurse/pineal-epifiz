# DOKÜMAN ENVANTERİ — her belge için özet ve ana bulgular

Toplam **89** Markdown belgesi. Özetler belgenin KENDİ (çıkarılmış) paragraflarından, ana bulgular madde işaretlerinden alınmıştır.

## Hızlı özet tablosu

| Belge | 3 cümlelik özet |
|---|---|
| `.jules/bolt.md` | Başlık: / Alt başlıklar: 2024-05-24 - Async HTTP Connection Pooling · 2025-02-23 - Caching Configuration Parsing · 2025-02-24 - Async SQLite Concurrency · 2025-02-24 - Respecting Purity Contracts |
| `ARCHITECTURE.md` | `android/` — Kotlin/Jetpack Compose Android uygulaması. Python backend'e **hiç bağlanmaz.** CI `android` job'u: lint + unit test + assemble. Bu, backend pipeline entegrasyonu kanıtı değildir. |
| `CHANGELOG.md` | Kullanıcı denetim raporunun (2026-10-07) maddelerinin tamamı uygulandı. Her madde, kusuru YENİDEN getirmeyi engelleyen testlerle kilitlendi; her düzeltme "kusurlu hâle geri alınınca ilgili testler düşüyor" diye doğrulandı. Not: `cargo check`/`cargo test --locked` ve `gradle` işleri YEREL koşumda doğrulanamadı (JDK/Gradle/Rust araç zinciri yok ve dağıtım adreslerine çıkış kapalı: `static.rust-lang.org`, `crates.io`, ` |
| `GO_LIVE.md` | Bu depo **adli OSINT istasyonudur** (Instagram/LinkedIn/X kazıma + 7 matematik motoru + 12 ajan + LLM havuzu). **WhatsApp / ödeme / Meta ticaret iş mantığı bu depoda YOKTUR.** Ölçüm: Görünen tek eşleşmeler yanlış pozitiftir: `test_media_forensics.py` içinde `kind="stripes"` (desen adı, `stripe` alt dizesi) ve yorumlarda geçen İngilizce `checkout` kelimesi. **Yani bu depo bir WhatsApp ticaret botu değildir; webhook do |
| `README.md` | Merhaba! Pineal-Heretic, sosyal medya (özellikle Instagram ve X) üzerindeki herkese açık profilleri inceleyen, gördüklerini sizin yerinize "insani bir gözle" okuyup analiz eden akıllı bir asistandır. Bu program **kesinlikle bir hacker aracı değildir**, şifre kırmaz veya gizli hesaplara sızmaz. |
| `README_TECHNICAL.md` | Pineal, sağlanan sosyal profil örneğinden **kaynak alanlarını**, bu alanlardan kodla türetilen **betimleyici hesaplamaları** ve LLM'lerin ürettiği **yorumları** ayrı ayrı sunmayı amaçlayan bir analiz prototipidir. Erişim, veri kapsamı ve sonuçlar scraper'a, görevin girdilerine ve etkin sağlayıcılara bağlıdır; her görevde her adım çalışmaz. `PinealExecutor` kayıt defterinde **13 görev ajanı** vardır. |
| `RUNBOOK.md` | Disaster recovery / volume persistence (manuel; Docker daemon gerekir): ``` bash scripts/test_disaster_recovery.sh # DR_WAIT_TIMEOUT=600 ile yavaş makine toleransı ``` Konteyneri hard-kill edip siler (`down`, `-v` bilinçli YOK) ve sıfırdan yaratır; `pineal_memory` + `pineal_vault` verisinin hayatta kaldığını doğrular. İmaj production'da tokensuz açılmadığından script geçici `PINEAL_TOKEN` override'ı uygular (`.env`'e |
| `UX_Kullanılabilirlik_Raporu.md` | Ön yüz (frontend) dosyalarındaki metin ve mesajları incelediğimde, "normal" bir kullanıcının anlamakta zorlanacağı bazı teknik ifadeler tespit ettim. 1. **"TRACKER HATASI" ve "ERROR" Etiketleri** Ajan panelinde bir şeyler ters gittiğinde ekranda "TRACKER HATASI" yazıyor. |
| `branch_temizlik_raporu.md` | Github'da projene (Pineal) dışarıdan bakınca bir sürü yarım kalmış, eskimiş veya yapay zekanın (arenanın) açıp unuttuğu taslak dal (branch) birikmiş durumda. Bunların projenin düzgün çalışmasıyla hiçbir ilgisi yok, sadece çekmecedeki eski karalama kağıtları gibiler. |
| `docs/AUDIT_2026-09.md` | Bu denetim raporu, canlıya alınacak `AppleCurse/pineal-clean` deposunun üretim güvenliği, mimari bütünlüğü, fail-closed sözleşmeleri ve çoklu istemci izolasyonu ekseninde gerçekleştirilen acımasız adli inceleme sonucunda hazırlanmıştır. Yapılan incelemede tespit edilen **1 P0 (Kritik Veri Sızıntısı)**, **5 P1 (Yüksek Risk)** ve **10 P2 (Orta Risk)** madde doğrudan kod tabanında çözülmüş, 21 yeni entegrasyon testiyle  |
| `docs/DEPLOYMENT_CLOUDFLARE.md` | Depoya bağlı Cloudflare projeleri **Workers servisi**, Pages değil: PR/commit check'lerinin `details_url` alanı `dash.cloudflare.com/<hesap>/workers/services/view/pineal-clean/...` ve `.../view/pineal-gland/...` gösteriyor. Buna karşılık `wrangler.toml` yalnız Pages alanı (`pages_build_output_dir`) taşıyordu ve `main`/`[assets]` YOKTU; ölçülen sonuç: Yani **Workers Builds daha frontend derlenmeden yapılandırma adımın |
| `docs/KURUM_HEDEFI.md` | theHarvester PATH'te değilse tam komut verilebilir: Kokpitte **KURUM** pili kaç modun hazır olduğunu gösterir; kapı kapalıysa `KURUM: KAPALI` yazar (uydurma "hazır" göstergesi yoktur). Kapılar: `vault` (istisnasız) + `ENABLE_COMPANY_TARGETING` (varsayılan **KAPALI**); `harvester` ayrıca `rate` kapısına tabidir (ağır CLI). HTTP hız kovası: `company` (8 istek/60 sn). |
| `docs/MCP.md` | Ayrı bir "dış yol" yoktur; ayrı yol ayrı gerçek olurdu. Claude Desktop / uyumlu istemci yapılandırması: MCP'nin güncel sürümü **2026-07-28**'dir ve protokol artık **stateless**'tır: ``initialize`` el sıkışması kaldırılmış, sürüm her isteğin ``_meta``'sında taşınmaktadır. Eski istemciler el sıkışma konuşmaya devam eder. |
| `docs/MEDYA_ADLI.md` | Ses **ve** metin makineden çıkmaz. Motor sırası: 1. `PINEAL_TRANSCRIBE_URL` — yalnız `127.0.0.1`/`localhost`/`[::1]`; uzak adres **sert reddedilir** (`non_local_endpoint`) ve CLI'ye sessizce DÜŞÜLMEZ. |
| `docs/PINEAL_TUZUK.md` | Pineal kurulurken ilk ve tek işi şuydu: Sistem o günden bu yana büyüdü. Kanıt mührü, 7 dalga motoru, 3'lü jüri, kasa mandalı, adli rapor, çok kanallı OSINT ve şimdi yetenek omurgası (Capability Spine) eklendi. **Alet, verilen ilk işten daha büyük hâle geldi.** Bu yüzden tüzük yeniden yazıldı: 1. |
| `docs/RAPOR_FABRIKASI.md` | Paket yalnız **kanonik kanıt zaman çizelgesinden** beslenir (`services/evidence_timeline.py`): sıra, epistemik tür ve "not independently verified" gibi epistemik notlar oradan aynen taşınır. Her eserin `sha256`'sı hesaplanır; `<ad>.manifest.json` şunları taşır: Doğrulama: `manifest_sha256` alanını çıkar, kalan gövdeyi `json.dumps(..., sort_keys=True, separators=(",", ":"))` ile serileştir, sha256'sını hesapla — eşit  |
| `docs/YEREL_JURI.md` | Panel kararı eskiden tek zincire (ya da uzak modellere) bağlıydı. Uzak jüri iki şeyi bedava vermez: maliyet sıfır değildir ve hedef verisi makineden çıkar. Yerel jüri aynı çapraz denetimi **yerel modellerde** koşar. |
| `docs/ZERO_TRUST_VERIFICATION_2026-09-18.md` | Etiket sözlüğü: **DOĞRULANDI** = kendi ölçümüm + mutasyon testi kırmızı verdi. **KISMİ** = ölçüm yapıldı ama bir ön koşul eksik. **BULGU** = raporla çelişen gerçek. |
| `docs/reports/ADLI_DUZELTME_GUNLUGU.md` | Başlık: PİNEAL ADLİ DİRİLİŞ VE TEMİZLİK GÜNLÜĞÜ (CANLI TAKİP) / Alt başlıklar: PİNEAL ADLİ DİRİLİŞ VE TEMİZLİK GÜNLÜĞÜ (CANLI TAKİP) · 🎯 4 AŞAMALI HAREKÂT PLANI VE GERÇEK İLERLEME · 🔴 2026-09-03 — KIRMIZI HÜKÜMLERİN YENİDEN ÖLÇÜMÜ + G7 MEKANİZMA ONARIMI |
| `docs/reports/AHLAKI_DOKUM_2026-10-05.md` | 325 depo tek tek açıldı, içindeki **fikir** çıkarıldı, aynı fikri satanlar tek çatı altında toplandı. Sonuç: **99 ayrı fikir.** Yani 325 kayıt, 99 fikrin farklı dillerde, farklı takımlarca yeniden yazılmış hâli. Aşağıda bu 99 fikrin **ahlaki hükmü** var. |
| `docs/reports/AKIS_RONTGENI_2026-09-21.md` | Ölçülen referans koşu (stub LLM, gerçek HTTP + gerçek WS): `POST /api/initiate` → 200 · 69 WS çerçevesi · 0.15 s · 10 LLM çağrısı · 13 ajan koşusu · nihai durum `partially_completed` · mühür: `memory/op_…json`. Planlanan: `mirror_truth, autonomous_verifier, human_behavior, passion_mapper, friction_detector, cognitive_profiler, resonance_calc, pattern_interrupt, resonance_synthesizer` Koşan (13): `osint_investigator,  |
| `docs/reports/API_MONOLITH_SPLIT_PLAN.md` | `backend/api.py`, FastAPI uygulamasının TAMAMINI tek bir modülde taşıyor: yaşam döngüsü (lifespan), middleware'ler, kimlik doğrulama, hız sınırlama, kasa (vault) yönetimi, tarayıcı oturumları, görev yürütme, OSINT, konuşma sentetikleme, MCP köprüsü ve OpenAI uyumlu ağ geçidi. Somut maliyetleri: Bölme, **en iyi test edilmiş ve en az bağımlılığı olan** katmanla başlar: Aşağıdaki tablo, gerçek `@app.*` dekoratörlerinden |
| `docs/reports/ARASTIRMA_MODEL_ESLEME_2026-09-08.md` | Kaynaklar: [1](https://costgoat.com/pricing/openrouter), [2](https://www.usagepricing.com/blueprint/groq), [3](https://www.usagepricing.com/blueprint/cerebras), [4](https://ai.google.dev/gemini-api/docs/pricing), [5](https://ofox.ai/blog/openrouter-pricing-hidden-markup-breakdown-2026/), [6](https://pecollective.com/tools/anthropic-api-pricing/), [7](https://benchlm.ai/xai/api-pricing), [8](https://openrouter.ai/blog |
| `docs/reports/AUTHENTIC_VECTOR_FIX_REPORT.md` | Önceki akış, authentic-vector LLM çağrısı hata verdiğinde aşağıdaki kararı verilebilir sahte veriyi üretiyordu: `ResonanceCalculator` da kullanıcı vektörü hiç yoksa ikinci bir default kullanıyordu: Bu iki davranış, verinin bulunmadığı bir durumda rezonans/uyum kararı verilmesine neden olabiliyordu. Dosya: `agent_core/task_executor.py` |
| `docs/reports/C0_BASELINE_VERI_ENVANTERI_2026-09-26.md` | Mevcut depo ve incelenen üretim akışları, bir hedefin geçmiş görevler arasında korunmuş, kaynağı doğrulanabilir zaman serisini **göstermiyor**. Standart Instagram yolu bir görev sırasında mevcut profilden en fazla 12 postluk örnek alıyor; P7 zaman motorları bu göreve verilen örnek üzerinde hesap yapıyor. Raporlar ve kanıt öğeleri görev bazında saklanabiliyor, ancak hedef kimliğine göre birleştirilmiş kaynak-post arşi |
| `docs/reports/CAPABILITY_ROUTING_DECISION_2026-09-02.md` | Kaynak: üç bağımsız piyasa/lab taramasının çelişki-ayıklanmış sentezi (kullanıcı araştırma paketi, 2026-09-02). Bu belge yalnız **uygulanan** kararları ve gerekçeyi sabitler; halüsinasyon/skor iddiası içermez. |
| `docs/reports/CROSS_AUDIT_FIXES_2026-09-02.md` | Başarılı vektör: Status: Unavailable: Sayısal fallback yok (önceki AUTHENTIC_VECTOR_FIX korundu); ek olarak tüketiciler model-tahmini ile ölçümü ayırt edebilir. |
| `docs/reports/DEEP_RESEARCH_PROVENANCE_FIX_REPORT.md` | Şüpheli bir ajan sonucu için eski akış şunu yapıyordu: `_deep_research()` bir `VerifiedNote` döndürdüğü için bu atama, ajan çıktısının tipini ve içeriğini kaybediyordu. Sonraki adımlar `result` değerini normal ajan çıktısı kabul ederek input/evidence zincirine yazıyordu. Böylece: Dosya: `agent_core/task_executor.py` Deep research artık özgün çıktıyı ve uncertainty raporunu girdi olarak alır: |
| `docs/reports/DEFERRED_AGENT_EVIDENCE_GATE_FIX_REPORT.md` | `pattern_interrupt` ve `resonance_synthesizer`, bağımlılıkları tamamlandıktan sonra çalıştırılmak üzere deferred kuyruğa alınıyordu. Ancak eski deferred döngü: Bu nedenle sıralama amaçlı bir kuyruk, kanıt güvenliği bypass’ına dönüşüyordu. Dosya: `agent_core/task_executor.py` Deferred döngü artık ana ajan döngüsü ile aynı evidence sözleşmesini uygular: |
| `docs/reports/DURUM_RAPORU.md` | `TelemetryData` (`data/model/Models.kt:111-114`) `cacheHitRate` ve `cacheHits` parametrelerini **birer kez** tanımlıyor. Aynı isimli argümanın iki kez verilmesi Kotlin'de derleme hatasıdır → `gradle assembleDebug` ve dolayısıyla CI'daki `android` işi **kırmızı** olur. Venv: `/tmp/pvenv` (requirements.txt + pytest/pytest-asyncio/ruff). |
| `docs/reports/DURUM_RAPORU_2026-08-30.md` | Pineal, bir **360° insan-profili analiz ve sahici iletişim** sistemidir. Akış: Temel ilke kodun her yerinde aynıdır: **kanıt yoksa sistem durur, asla içerik üretmez.** Tüm HTTP/WebSocket yüzeyi tek dosyada, gruplar hâlinde: Güvenlik: `PINEAL_TOKEN` tanımlanırsa tüm API `X-API-Key` ister; CORS `PINEAL_ALLOWED_ORIGINS` ile sınırlandırılır; tüm dış URL indirmeleri SSRF guard'dan (`is_safe_url`) geçer. |
| `docs/reports/DURUM_TESPITI_2026-09-08.md` | CI komutu: `pip install -r requirements.txt ruff pytest pytest-asyncio pytest-cov` → `ruff check .` → `pytest -q -p no:cacheprovider --cov=agent_core --cov=backend --cov-report=term-missing:skip-covered --cov-fail-under=80` (+ frontend `npm ci && npm run check && npm run build`, smoke uvicorn, rust `cargo check --all-targets && cargo test --locked`, android gradle). Tümü aynen çalıştırıldı: `git log --oneline d81ca59 |
| `docs/reports/EKSIK_YETENEKLER_2026-09-26.md` | “Bulunamadı” ifadesi, ilgili özelliğin bu incelemede aranan dosya/çağrı akışlarında entegre bir uygulamasının görülmediği anlamına gelir; tek başına `grep` ile tüm olası davranışların yokluğu kanıtlanmış olmaz. Pozitif eşleşmelerin ilgili kaynak kodu ayrıca okundu. Aşağıdaki **kısmi** etiketleri, yakın bir mekanizmanın varlığını bildirir; önerilen yeteneğin tamamlandığı anlamına gelmez. |
| `docs/reports/FAZ2_MUHUR_RAPORU_2026-09-08.md` | FAZ-2 (ENFORCE free-only + canlı-ID katalog düzeltmeleri) tamamlandı. Aşağıdaki kanıtlar mühür kriterlerinle birebir eşleşir; **mühürsüz FAZ-3 YOK** (vision / Google direct ertelemesi dahil — bu fazda vision'a dokunulmadı). Aynalanan dosyalar: `config/provider_catalog.json`, `agent_core/services/final_routing_policy.py` (ROUTES + TASK_GROUPS), `scripts/verify_openrouter_catalog.py` (`REQUIRED_NOUS_FREE` → 3 ID). |
| `docs/reports/FAZ3_GIRDI_2026-09-08.md` | Güven gerekçeleri (2. ajan): 1. Sayılar kapanıyor: 1132 = 1099 (entegrasyon) + 31 (FAZ-1) + 2 (FAZ-2 net) — uydurularak tutturulamaz. |
| `docs/reports/FAZ_E_PLANI_2026-10-07.md` | Bu bölüm **CI kanıtı + bağımsız kaynak denetimi** ile yazıldı. Aşağıdaki plan metni tarihsel kayıt olarak korundu; ölçüm anı `main` @ `162d7ec` idi ve hâlâ öyle. Planın açılış sorusu — *"E1 Rust onarımı bu fazda mı, ayrı bir vault PR'ı olarak mı yürüsün?"* — **fiilen cevaplandı: ayrı bir PR olarak yürüdü** ve onarıldı. |
| `docs/reports/FIXES_APPLIED.md` | Bu fix pass sırasında uzak `main`'in (PR #31, `fix-static-findings-3`) ikinci denetim raporundaki bulguların bir bölümünü zaten merge ettiği görüldü (TIER_2 env, SERPAPI, USE_LOCAL_LLM, spend-cap 0.0, litellm/PyYAML/aiohttp, test hizalama, muse-spark, reflection.sql, router'da interpreter kapısı, android CI). Commit, yeni main üzerine rebase edildi; çakışmalarda **daha tam/daha dürüst taraf** seçildi: |
| `docs/reports/FORENSIC_AUDIT_2026-08-29.md` | Bu depo, **tek kullanıcılı yerel bir analiz istasyonu** olarak tasarlanmış hibrit bir sistemdir: Hesap: \(0.15\cdot9 + 0.15\cdot8 + 0.15\cdot7 + 0.15\cdot3 + 0.10\cdot3 + 0.10\cdot7 + 0.10\cdot5 + 0.05\cdot5 + 0.05\cdot4 = 6.20\) → **62/100**. 6. `POST /api/initiate` aynı client → **429** [PROVEN] Token set → `/api/*` 401 without key; 200 with `X-API-Key`; WS token’sız disconnect [PROVEN] |
| `docs/reports/GENEL_DURUM_HARITASI_2026-09-02.md` | Kısa özümleme: Proje **22 Ağu → 2 Eyl** arasında 52 PR'lık bir yol kat etti ve bugün **`v3.0.0-rc.1`** sürüm etiketi üzerinde **"router yayılma dalgası"** ile sonlandı. Capability policy patch'i kaybolmadı — **#52 + #53 olarak main'de**. LOKAL (bu oturum): arena/01a06052 ── 0 ahead / 1 behind main (b14a8e16 eksik) ``` Kapatılıp merge edilmeyen 14 PR'ın sınıflandırması: 1. |
| `docs/reports/GO_NO_GO_AUDIT_2026-09-11.md` | CI workflow (push @ `e3ea76b`): run `34252493534` + `34252492283` → **success**. Job matrisi (her iki run'da da): `frontend ✅ · rust-core ✅ · android ✅ · backend ✅ · smoke ✅`. Ancak aynı HEAD'in **commit status**'u: Sonuç: "CI yeşil → canlı hazır" denklemi bu HEAD'de kurulamaz. |
| `docs/reports/IMPLEMENTATION_PLAN_TAURI_NATIVE.md` | 2. `frontend/vite.config.ts` güncelle: - server.port 1420, strictPort true, host 0.0.0.0, allowedHosts true - server.hmr.port 1421 (Tauri icin) - clearScreen false - envPrefix ["VITE_", "TAURI_"] - proxy /api ve /ws hala 127.0.0.1:8000 3. `rust_core/src-tauri/Cargo.toml` ve `src-tauri/src/lib.rs`: - lib.rs'te window olusturma, setup closure'da telemetry bridge zaten var - capabilities/default.json'a "core:window:allo |
| `docs/reports/INDEPENDENT_FORENSIC_AUDIT.md` | Sistem, README'nin çoğu iddiasının **gerçekten çalıştığı ender bir proje**: sahte/placeholder yanıt üretmeyen, kanıt yoksa **dürüstçe duran** (halted_evidence) bir ajan pipeline'ı kodda değil, **çalışma zamanında doğrulandı**. Sunucu ayağa kalktı, Svelte arayüzü servis edildi, WebSocket üzerinden FIFO telemetri + sonuç üretildi, kimlik doğrulama ve hız limiti çalıştı, bellek kalıcılığı ve kalıcı silme çalıştı. Ancak  |
| `docs/reports/INTEGRATION_PLAN.md` | Maigret 0.6.5'te ağ hatası durumlarında `SiteResult.status = None` dönebiliyor (checker future'ı istisna ile ölüyor; ilk ham testte `<Unknown (Connecting failure)>` görünürken ikinci koşuda None). İlk sınıflandırmamız None'ı "hata değil" sayıyordu → **hiç kontrol yapılmadan 'iz yok' iddia edilebilirdi.** Düzeltme: `status in (UNKNOWN, None)` → error_count. Canlı doğrulama: 21 site / 21 hata → `available:false, reason |
| `docs/reports/JULES_DENETIM_2026-10-06.md` | Bu rapor, PINEAL-HERETIC deposunun üç ayrı perspektiften (Yazılımcı, Operatör, Üçüncü Göz) acımasızca incelenmesi sonucu oluşturulmuştur. Amaç kusur bulmak ve çözüm üretmektir. Yeni özellik eklenmemiş, sadece mevcut mimari ve kodun iddialarla uyuşmayan, çürük, "tiyatro" veya güvensiz yanları tespit edilmiştir. |
| `docs/reports/P0_CI_FIX_RAPORU_2026-09-08.md` | Yani test hem "gerçek üretim `std::fs` kullanımı KIRMIZI" hem de "test-only kullanım + yorumlar YEŞİL" koşulunu kanıtlıyor. Yerel (CI backend job'ının birebir komutu: `pytest -q -p no:cacheprovider --cov=agent_core --cov=backend --cov-report=term-missing:skip-covered --cov-fail-under=80`): Sapma yok: fix yalnız iki test/kapı dosyasındaki kullanılmayan import ve tarama sözleşmesini düzeltti; üretim kodu ve test davran |
| `docs/reports/P0_PERSONAL_BASELINE_INFRASTRUCTURE_SCOPE_2026-09-26.md` | 1. **Hedefe bağlı kimlik** — Görevler arasında aynı hedefi güvenilir ve doğru yetki sınırında tanıyacak bir kimlik sözleşmesi. 2. |
| `docs/reports/PRODUCTION_AUDIT_2026-09-04.md` | İlk 6 öncelik + çapraz denetimde çıkan bir ek boşluk kapatıldı. Aşağıdaki rakamların tamamı bu turda **yeniden ölçüldü**; raporun geri kalanı bulguların ilk hâlini belgelemeye devam ediyor. İlk onarım budamayı **yalnızca yazım sayısına** bağlamıştı (her 256 yazım). |
| `docs/reports/PRODUCTION_REPAIR_PLAN.md` | 1. `main` doğrudan değiştirilmez; bütün düzeltmeler hardening dalında ilerler. 2. |
| `docs/reports/RELEASE_EVIDENCE.md` | Bu belge, deployment kararı için gereken kanıtları mühürler. Satır satır referans alınabilir; yorum veya iddia içermez. rm -rf memory && mkdir memory # felaket simülasyonu bash scripts/backup_restore.sh restore backups/pineal_20260901_114807.tar.gz # → 63 görev geri yüklendi ls memory/ / wc -l # → 63 ``` |
| `docs/reports/REPORT_CROSS_VALIDATION.md` | 1. **Canlı OpenRouter katalog doğrulaması:** 6/6 model slug + 4/6 fiyat birebir; **`z-ai/glm-5.2` (0.10/0.10) ve `deepseek-v4-pro` (0.50/1.00) fiyat kayıtları katalog minimumlarının altında → spend cap gerçek maliyetin altında sayar** (B'de yok). 2. |
| `docs/reports/RONTGEN_DENETIM_2026-09-23.md` | `/home/user/probe/probe_verifier.py` + `probe_gate.py` ile **gerçek kod yolu** koşturuldu: 1. **Kanıt kapısı yoktu (entailment).** Jürinin bildirdiği `evidence_url` ve alıntı, arama motorunun GERÇEKTEN döndürdüğü kaynak kümesiyle karşılaştırılmıyordu: model URL uydurabiliyor, "kanıt" diye kendi hayalini gösterebiliyordu. → `_audit_vote`: URL kaynak kümesinde değilse `kanit_url_kaynaksiz`, alıntı kaynak metninde geçmi |
| `docs/reports/ROUTING_HARDENING_2026-09-04.md` | Kapsam: routing-doğrulama turunda bulunan O-1..O-4 gap'lerinin KAPATILMASI. Yeni özellik/soyutlama YOK; mevcut tek routing beyni (final_routing_policy ROUTES + llm_gateway zincir motoru) korundu. OpenRouter hub değil. |
| `docs/reports/SON_HUKUM_DENETIM.md` | 1. **JSON repair `except Exception` aşırı genişti** → parse/schema'ya daraltıldı. 2. |
| `docs/reports/STEPB_ENTEGRASYON_RAPORU_2026-09-08.md` | `stepB_port.patch` dosyası bu sandbox'ta fiziksel olarak yoktu (yalnız içerik mesajda verildi), bu yüzden `git apply --check` yerine içerik **birebir** elle uygulandı: `llm_gateway.py`'ye `effective_routing_snapshot()` + 2 yardımcı (ekleme noktası `capable_chain` sonu / `__init__` öncesi — patch bağlamıyla **birebir aynıydı, çakışma yok**), `config/agent_tiers.json`, `scripts/generate_routing_shadows.py`, `tests/unit |
| `docs/reports/SYSTEM_HEALTH_AND_INTEGRATION_MAP.md` | 1. ~~X alternatif retrieval sözleşmesi~~ → `a002b20`: source attribution + subject matching + evidence formatı uygulandı (sahte profil üretilmiyor; frontend tüketimi ayrı iş). 2. |
| `docs/reports/TEKLIF_TAM_GUC_2026-10-05.md` | Bugün Pineal **tek gözlü ve dilsiz**: sensörü Instagram (Playwright), X deliği açık (`XScraperUnsupportedError → awaiting_authorization`), web kazıma tek yerde dar kullanımda, hafızası görev bitince sıfırlanan bir JSON, arayüzdeki holografik ağ **rastgele düğüm üretiyor** (`HolographicResonanceMesh.svelte` → `generateNodes()`), Aspasia'nın sesi yok. Senin üç katmanın + benim üstüne eklediğim 12 parça tam güçle bağlan |
| `docs/reports/YILDIZ_DEPO_KARAR_AGACI_2026-10-05.md` | Gerçek anlamda **kod içeri alınacak** depo sayısı: **17 entegrasyon + 51 adaptör = 68**. Geri kalan 257 kayıt, Pineal'i **desen, standart, veri kümesi ve disiplin** olarak besler. Bu oran bilinçlidir: benzersizlik depo sayısından değil, 68 yeteneğin **tek sözleşmeye bağlanmasından** doğar. |
| `docs/reports/ZF_ADLI_DENETIM_2026-09-08.md` | Kod seviyesinde **doğrulanmış CRITICAL çalışma-hatası bulunamadı** (fail-closed varsayılanlar, dürüst-eksik davranış, güçlü regresyon koruması). Aşağıdakiler HIGH/MEDIUM adayları; her biri kanıtlıdır: Sınıflandırma merdiveni (kod): **DECLARED** (katalog/ROUTES) → **REGISTERED** (registry) → **AVAILABLE** (ROUTES `verified`+tier) → **ROUTABLE** (transport + policy) → **REACHABLE** (anahtar + kısıt) → **CALLED** (runti |
| `docs/reports/pineal_resorgulama_report.md` | Bağlantı sorunu değil. Asıl açıklar: **sıralama** (ajan kanıtı olmadan pillar), **DecisionEngine’in pillar’ı yok sayması**, pillar’ın LLM’siz/deterministik kalması. 1. |
| `frontend/README.md` | This template should help get you started developing with Svelte and TypeScript in Vite. [VS Code](https://code.visualstudio.com/) + [Svelte](https://marketplace.visualstudio.com/items?itemName=svelte.svelte-vscode). Check out [SvelteKit](https://github.com/sveltejs/kit#readme), which is also powered by Vite. |
| `reports/B0_DESTEK_GUVENLI_DEVAM_KABUL_2026-10-14.md` | B0'ın altı maddesi de dosya/kanıt + çalıştırılmış test ile kapatılmıştır: U2E akışı, 6 negatif senaryo, kalıcılık/tekrar-güvenliği, E-GÖZ3-2 davranışsal testi, state_bridge denetim izi/timeout, UI kablolaması. Tam paketler yeşildir (§4). `POST /api/tasks/{task_id}/resume` → `backend/routes/support.py:274 api_resume_task` (kayıt `backend/api.py:4682 register_support_routes(...)` — route düzeni korunmuş, `api.py:611` t |
| `reports/KABUL_DENETIMI_DESTEK_AKISI_2026-10-14.md` | Önceki A-path değişkileri (25 dosya, egress/vault_gate/responsibility/testler) korunmuştur; `backend/api.py` = **5997/6000** (ratchet: `tests/unit/test_api_monolith_ratchet.py`, 6 passed). 1. **Sözleşme/mühür:** `_responsibility_trail` (`task_executor.py:730`) → `agent_core.domain.responsibility.build_trail` → `seal_trail` kuralları; ihlalde **“SORUMLULUK İHLALİ”** ERROR + `integrity.violation`. |
| `scripts/archive/README.md` | Bu dizindeki scriptler **üretim akışında, CI'da ve test paketinde kullanılmaz** (`pytest.ini: testpaths = tests`). Tarihsel kanıt/deneme amaçlı saklanır: Aktif operasyonel scriptler bir üst dizinde kalır: `run_task.py`, `generate_routing_shadows.py`, `verify_openrouter_catalog.py`, `preflight_9router.py`, `smoke_test_browser.py`, `backup_restore.sh`, `test_disaster_recovery.sh/.ps1`. |
| `skills/analyzer_media_frames/SKILL.md` | Video/fotoğrafı kare kare ÖLÇER (fps, çözünürlük, parlaklık, sahne kesmesi); içerik yorumu yapmaz. |
| `skills/analyzer_media_similarity/SKILL.md` | Görselin algısal parmak izini (pHash) çıkarır ve yerel indekste en yakın görselleri bulur. |
| `skills/extractor_identity_socid/SKILL.md` | Profil URL'sinden sosyal kimlik alanlarını çıkarır (kanıtlı). |
| `skills/extractor_media_transcript/SKILL.md` | Medyanın sesini metne çevirir (yerel whisper CLI/uç). Ses ve metin makineden çıkmaz. |
| `skills/extractor_text_language/SKILL.md` | Metnin dilini deterministik ölçer (tr/en/de/es/fr/ru/az); model ve ağ yok, sinyal yoksa etiket uydurmaz. |
| `skills/extractor_text_translate_local/SKILL.md` | Metni yerel motorda çevirir (uzak uç reddedilir, uydurma çeviri yok). |
| `skills/extractor_web_crawl4ai/SKILL.md` | JS'li/ağır sayfalar için tarayıcılı kazıma (ikinci kademe). |
| `skills/extractor_web_scrapling/SKILL.md` | Adaptif kazıma: site değişse de kırılmaz (üçüncü kademe). |
| `skills/extractor_web_trafilatura/SKILL.md` | Sayfadan çöp etiketleri ayıklayıp temiz metin çıkarır (birincil). |
| `skills/renderer_report_diagram/SKILL.md` | Kanıt çizelgesini deterministik PNG diyagrama çevirir (tür = renk). |
| `skills/renderer_report_pdf/SKILL.md` | Kanıt çizelgesinden PDF rapor üretir (hash'li, kanıt bağlantılı). |
| `skills/renderer_report_video/SKILL.md` | Kanıt çizelgesinden kısa video özet üretir (kareler Pillow, kodlama ffmpeg). |
| `skills/sensor_company_harvester/SKILL.md` | Kurum/alan adı hedefi: arama motorlarından e-posta, alt alan adı, IP ve URL toplar (theHarvester). Araç yoksa dürüstçe kapalıdır. |
| `skills/sensor_company_people/SKILL.md` | Kurumun kendi sayfalarında YAYINLADIĞI kişi künyesi (schema.org/Person: ad + rol) ve herkese açık iletişim adresleri. Kişi avı değildir. |
| `skills/sensor_company_seo/SKILL.md` | Kurumun açık izlenebilirlik verisi: robots.txt, sitemap.xml, ana sayfa meta/dil/canonical, security.txt ve güvenlik başlıkları. Puan uydurulmaz. |
| `skills/sensor_identity_holehe/SKILL.md` | E-postanın hangi platformlarda kayıtlı olduğunu tarar. |
| `skills/sensor_identity_maigret/SKILL.md` | Kullanıcı adının binlerce sitedeki varlığını tarar (kanıtlı); liste PINEAL_MAIGRET_DB ile tazelenir ve kaynak raporlanır (A8). |
| `skills/sensor_ig_instagrapi/SKILL.md` | Instagram ikinci kaynak: Playwright engellenirse sensör düşmez. |
| `skills/sensor_media_fetch/SKILL.md` | Video/foto indirir (platform linkleri yt-dlp, doğrudan bağlantılar httpx) ve sha256 ile mühürler. |
| `skills/sensor_search_searxng/SKILL.md` | Anahtarsız metasearch; arama maliyetini ve sağlayıcı bağımlılığını kırar. |
| `skills/sensor_web_agent_reach/SKILL.md` | Twitter/Reddit/YouTube/GitHub okuma — sıfır API ücreti (harici CLI). |
| `skills/sensor_x_twscrape/SKILL.md` | X/Twitter gönderi akışı (gerçek zaman serisi; Frequency motorunu besler). |
| `skills/verifier_jury_local/SKILL.md` | Aynı iddia ve kanıtı birden çok YEREL modelde bağımsız oylar; oybirliği ya da yeter sayılı çoğunluk karar olur. Uzak uç reddedilir; motor yoksa karar UYDURULMAZ. |
| `skills/voice_report_script/SKILL.md` | Görev sonucunu sesli okunabilir Türkçe rapora çevirir. |
| `skills/voice_stt_local/SKILL.md` | Yerel konuşma tanıma (whisper CLI veya localhost STT ucu). |
| `skills/voice_tts_local/SKILL.md` | Yerel TTS (piper CLI veya localhost TTS ucu) — ses makineden çıkmaz. |

## Kök belgeler — 8 belge

### `ARCHITECTURE.md` — 79 satır
**Başlık:** MİMARİ (koddan doğrulanmış çalışma zamanı grafiği) 

**Özet:** `android/` — Kotlin/Jetpack Compose Android uygulaması. Python backend'e **hiç bağlanmaz.** CI `android` job'u: lint + unit test + assemble. Bu, backend pipeline entegrasyonu kanıtı değildir.

### `CHANGELOG.md` — 1514 satır
**Başlık:** Changelog 

**Özet:** Kullanıcı denetim raporunun (2026-10-07) maddelerinin tamamı uygulandı. Her madde, kusuru YENİDEN getirmeyi engelleyen testlerle kilitlendi; her düzeltme "kusurlu hâle geri alınınca ilgili testler düşüyor" diye doğrulandı. Not: `cargo check`/`cargo test --locked` ve `gradle` işleri YEREL koşumda doğrulanamadı (JDK/Gradle/Rust araç zinciri yok ve dağıtım adreslerine çıkış kapalı: `static.rust-lang.org`, `crates.io`, `services.gradle.org`, `repo1.maven.org`, `dl.google.com` → bağlantı yok).

**Ana bulgular / maddeler:**
- - 12 ajan + 10 servis + 8 diğer modüle (aspasia, domain, scraper CLI, shadow, nlp,
- - Kural: docstring'ler dosyanın GERÇEK davranışını ve dürüstlük sözleşmesini yazar
- - Test: `tests/unit/test_inventory_page.py::test_every_category_a_file_has_a_module_docstring`.
- - Kök girişler (`main.py`), `agent_core` kökü (`task_executor.py`, `config_loader.py`,
- - En kritik ikisi: `agent_core/task_executor.py` (orkestra şefi) ve `backend/api.py`.
- - Ölçüm: `backend/api.py` **tam 6.000 satırda** (ratchet tavanı) duruyordu; yukarıdaki

### `GO_LIVE.md` — 249 satır
**Başlık:** GO_LIVE.md — PINEAL EPİFİZ canlıya alma kapısı 

**Özet:** Bu depo **adli OSINT istasyonudur** (Instagram/LinkedIn/X kazıma + 7 matematik motoru + 12 ajan + LLM havuzu). **WhatsApp / ödeme / Meta ticaret iş mantığı bu depoda YOKTUR.** Ölçüm: Görünen tek eşleşmeler yanlış pozitiftir: `test_media_forensics.py` içinde `kind="stripes"` (desen adı, `stripe` alt dizesi) ve yorumlarda geçen İngilizce `checkout` kelimesi. **Yani bu depo bir WhatsApp ticaret botu değildir; webhook doğrulama / sepet / ödeme denetimi burada boş kategoridir.** WhatsApp botu ayrı bir servis ise o servis ayrı denetlenmelidir.

**Ana bulgular / maddeler:**
- * `principal is None` (kimlik doğrulama kapalı / development) → mühür yok,
- * Kayıt **yok** (bu sürümden önce üretilmiş kanıt) → **İLK ERİŞEN SAHİPLENİR.**
- * Kayıt başka operatörde → ret.
- * `PINEAL_TASK_OWNERS_DB` yazılamıyorsa **fail-OPEN** ve dar: görev erişilebilir

### `README.md` — 231 satır
**Başlık:** PINEAL-HERETIC (İçgörü Asistanı) 

**Özet:** Merhaba! Pineal-Heretic, sosyal medya (özellikle Instagram ve X) üzerindeki herkese açık profilleri inceleyen, gördüklerini sizin yerinize "insani bir gözle" okuyup analiz eden akıllı bir asistandır. Bu program **kesinlikle bir hacker aracı değildir**, şifre kırmaz veya gizli hesaplara sızmaz.

**Ana bulgular / maddeler:**
- - **Orijinal %12.2 Pirinç Yuvalı Yaşayan Organik Göz:**
- - Pirinç yuva içinde yaşayan organik epifiz gözü (`living_pineal_disk.png`).
- - Operatörün fare hareketini nazikçe takip eder, arka planda organik drift (`Math.sin`/`Math.cos`) ve operasyon anında hafif bilişsel titreşim (`processingFlutter`) sergiler.
- - **Holografik Rezonans Ağı (`HolographicResonanceMesh.svelte`):**
- - Pirinç yuva arkasında dönen üç boyutlu matematiksel tel kafes. Sistem yüküne ve rezonans şiddetine göre form değiştirir.
- - **Aspasia Canlı CRT Konsolu (`/api/aspasia/chat`):**

### `README_TECHNICAL.md` — 245 satır
**Başlık:** PINEAL EPİFİZ v5.1 · PINEAL-HERETIC 

**Özet:** Pineal, sağlanan sosyal profil örneğinden **kaynak alanlarını**, bu alanlardan kodla türetilen **betimleyici hesaplamaları** ve LLM'lerin ürettiği **yorumları** ayrı ayrı sunmayı amaçlayan bir analiz prototipidir. Erişim, veri kapsamı ve sonuçlar scraper'a, görevin girdilerine ve etkin sağlayıcılara bağlıdır; her görevde her adım çalışmaz. `PinealExecutor` kayıt defterinde **13 görev ajanı** vardır.

**Ana bulgular / maddeler:**
- - Bir profil bağlantısından erişilebilen alanları toplar. Varsayılan ürün akışı Instagram içindir; Instagram scraper'ı en fazla 12 postu profil örneğine alır. Erişilemeyen veya yetersiz verili alanlar her zaman doldurulm
- - Gönderi metni ve zaman damgalarından bazı tekrar üretilebilir betimleyici hesaplamalar yapar. Bunlar yalnızca sağlanan örneklemi tarif eder; kişinin psikolojisini veya yaşamındaki nedenleri ölçmez.
- - Girdi ve rota elverdiğinde ajanlara profil metni, görsel özet, zaman/etkileşim sayıları ya da kullanıcının kendi verdiği bağlam üzerinde görev verir.
- - Bazı biyografi iddialarını arama sağlayıcısı yapılandırılmışsa kaynaklarla kontrol etmeye çalışır. Bu kontrol bütün profilin doğru olduğunu kanıtlamaz.
- - Görev durumunu, ajan çıktılarını ve uygun olduğunda **gönderilmeyen** ilk iletişim taslaklarını arayüzde gösterir.
- - **[KAYNAK / GÖZLEM]** Scraper'ın veya belirli bir sağlayıcının gerçekten döndürdüğü alan. Kaynağın varlığı, içeriğin bağımsız doğrulandığı anlamına gelmez.

### `RUNBOOK.md` — 293 satır
**Başlık:** RUNBOOK — Kurulum, Çalıştırma, Sorun Giderme 

**Özet:** Disaster recovery / volume persistence (manuel; Docker daemon gerekir): ``` bash scripts/test_disaster_recovery.sh # DR_WAIT_TIMEOUT=600 ile yavaş makine toleransı ``` Konteyneri hard-kill edip siler (`down`, `-v` bilinçli YOK) ve sıfırdan yaratır; `pineal_memory` + `pineal_vault` verisinin hayatta kaldığını doğrular. İmaj production'da tokensuz açılmadığından script geçici `PINEAL_TOKEN` override'ı uygular (`.env`'e dokunmaz). Kapsam: compose named-volume persistence — gerçek yedek/geri yükleme ve Railway volume davranışı bu testin dışındadır.

**Ana bulgular / maddeler:**
- - `OPENROUTER_API_KEY` + `LIVE_LLM_E2E=1` → canlı bulut LLM.
- - Yerel: `USE_LOCAL_LLM=true`, `LOCAL_LLM_URL=http://localhost:11434/v1`, `LOCAL_LLM_MODEL=...` (anahtar gerekmez).
- - `TAVILY_API_KEY`, `SERPAPI_API_KEY`, `EXA_API_KEY` → AutonomousVerifier web doğrulaması (yoksa DuckDuckGo + SearXNG yedeği).
- - Faz A · Retina kapıları (hepsi **default KAPALI**, hepsi omurgada):
- - Vision: `OPENROUTER_VISION_MODEL` — varsayılan `google/gemini-3.7-flash`; VisionAnalyzer (profil fotoğrafları) ve görselli Aspasia isteklerinde kullanılır.
- - Model varsayılanları (2026-09-02 karar matrisi):

### `UX_Kullanılabilirlik_Raporu.md` — 21 satır
**Başlık:** Kullanılabilirlik (UX) İyileştirme Raporu 

**Özet:** Ön yüz (frontend) dosyalarındaki metin ve mesajları incelediğimde, "normal" bir kullanıcının anlamakta zorlanacağı bazı teknik ifadeler tespit ettim. 1. **"TRACKER HATASI" ve "ERROR" Etiketleri** Ajan panelinde bir şeyler ters gittiğinde ekranda "TRACKER HATASI" yazıyor.

### `branch_temizlik_raporu.md` — 21 satır
**Başlık:** Github Dalları (Branches) Nasıl Temizlenir? 

**Özet:** Github'da projene (Pineal) dışarıdan bakınca bir sürü yarım kalmış, eskimiş veya yapay zekanın (arenanın) açıp unuttuğu taslak dal (branch) birikmiş durumda. Bunların projenin düzgün çalışmasıyla hiçbir ilgisi yok, sadece çekmecedeki eski karalama kağıtları gibiler.


## Sözleşmeler (docs/*.md) — 9 belge

### `docs/AUDIT_2026-09.md` — 346 satır
**Başlık:** PINEAL-HERETIC v3.1 — Bağımsız Mimar & QA Adli Denetim Raporu (Eylül 2026) 

**Özet:** Bu denetim raporu, canlıya alınacak `AppleCurse/pineal-clean` deposunun üretim güvenliği, mimari bütünlüğü, fail-closed sözleşmeleri ve çoklu istemci izolasyonu ekseninde gerçekleştirilen acımasız adli inceleme sonucunda hazırlanmıştır. Yapılan incelemede tespit edilen **1 P0 (Kritik Veri Sızıntısı)**, **5 P1 (Yüksek Risk)** ve **10 P2 (Orta Risk)** madde doğrudan kod tabanında çözülmüş, 21 yeni entegrasyon testiyle kilitlenmiş ve ana dalda (`main`) kalıcılaştırılmıştır. 1.

**Ana bulgular / maddeler:**
- * **Dosya & Konum:** `backend/api.py` (`_send_ws`)
- * **Sorun:** Odanın FIFO göndericisi `_send_ws`, `all_ws.update(r["websockets"])` döngüsüyle o an sistemdeki tüm odaların soketlerini toplayıp yayını herkese gönderiyordu. İstemci A'nın hedef profil analizi, LLM telemetr
- * **Çözüm:** Yayın katı şekilde `room.get("websockets", set())` kümesine sınırlandı. `_WS_SEND_TIMEOUT_S = 5.0` zaman aşımı ve asılı/yanıt vermeyen soketleri anında temizleyen evict mekanizması eklendi.
- * **Kanıt Testi:** `tests/integration/test_live_fixes_2026_09.py::test_ws_room_isolation_no_leak` (`leak_probe.py` ile sızıntı 0'a indirildi).
- * **Dosya & Konum:** `backend/api.py` (`_send_ws`)
- * **Sorun:** `await ws.send_text(payload)` çağrısında zaman aşımı yoktu. Bir istemcinin ağı yavaşladığında veya bağlantı koptuğunda FIFO gönderici süresiz asılı kalarak ilgili odanın tüm telemetrisini donduruyordu.

### `docs/DEPLOYMENT_CLOUDFLARE.md` — 185 satır
**Başlık:** Cloudflare Dağıtımı — PINEAL Frontend (Workers static assets + Pages yolu) 

**Özet:** Depoya bağlı Cloudflare projeleri **Workers servisi**, Pages değil: PR/commit check'lerinin `details_url` alanı `dash.cloudflare.com/<hesap>/workers/services/view/pineal-clean/...` ve `.../view/pineal-gland/...` gösteriyor. Buna karşılık `wrangler.toml` yalnız Pages alanı (`pages_build_output_dir`) taşıyordu ve `main`/`[assets]` YOKTU; ölçülen sonuç: Yani **Workers Builds daha frontend derlenmeden yapılandırma adımında ölüyordu** (`Workers Builds: pineal-clean` / `pineal-gland` kırmızılarının kök nedeni). İki tip aynı `wrangler.toml`'da **bir arada olamıyor** (ikisi de ölçüldü): Bu yüzden kök 

**Ana bulgular / maddeler:**
- - `/api/*` istekleri **proxy'lenmiyordu** → statik edge 404 dönüyordu.
- - `/ws/{client_id}` WebSocket ucu edge'de yoktu → telemetri asla bağlanamıyordu.
- - Backend kökeni hiçbir yerde tanımlı değildi.
- - **HTTP proxy** (`functions/api/[[path]].ts`): metod, body, header'lar
- - **WS proxy** (`functions/ws/[[path]].ts`): upgrade el sıkışması yapılır,
- - **Dürüstlük sözleşmesi**: `BACKEND_ORIGIN` secret'ı ayarlı değilse her iki

### `docs/KURUM_HEDEFI.md` — 72 satır
**Başlık:** KURUM HEDEFİ — şirket/kuruluş/alan adı taraması 

**Özet:** theHarvester PATH'te değilse tam komut verilebilir: Kokpitte **KURUM** pili kaç modun hazır olduğunu gösterir; kapı kapalıysa `KURUM: KAPALI` yazar (uydurma "hazır" göstergesi yoktur). Kapılar: `vault` (istisnasız) + `ENABLE_COMPANY_TARGETING` (varsayılan **KAPALI**); `harvester` ayrıca `rate` kapısına tabidir (ağır CLI). HTTP hız kovası: `company` (8 istek/60 sn).

**Ana bulgular / maddeler:**
- - **SEO puanı uydurulmaz.** Yalnız ölçülen yazılır (dosya var mı, kaç kayıt,
- - **"Yok" iddiası yalnız kesin 404'te** (`epistemic_type="absence"`). Ağ
- - **Araç yoksa ses çıkmaz**: `dependency_missing:theHarvester` (PATH'te yok)
- - **Boş tarama = yokluk kanıtı** yalnız tarama sıfır hatayla bittiğinde.
- - **Kova tavanı**: kova başına 25 kanıt; aşan `truncated` ile işaretlenir
- - **SSRF hijyeni**: hedef özel/yerel ağa çözülürse (`127.0.0.1`, `10.x`,

### `docs/MCP.md` — 192 satır
**Başlık:** PINEAL MCP — yetenekler standart kapıdan dışarıda 

**Özet:** Ayrı bir "dış yol" yoktur; ayrı yol ayrı gerçek olurdu. Claude Desktop / uyumlu istemci yapılandırması: MCP'nin güncel sürümü **2026-07-28**'dir ve protokol artık **stateless**'tır: ``initialize`` el sıkışması kaldırılmış, sürüm her isteğin ``_meta``'sında taşınmaktadır. Eski istemciler el sıkışma konuşmaya devam eder.

**Ana bulgular / maddeler:**
- - Kaynak/istem (``resources``/``prompts``) ilan EDİLMEZ. İlan edilmeyen ilkel
- - Şu an yalnız **stdio** taşıması vardır; ağ üzerinden HTTP taşıması yoktur.
- - Yaş sinyali UYDURULMAZ: bir hedefin 18 altı olduğu bilgisi MCP çağrısının
- - Liste her istekte defterden türetilir: **bayat liste yoktur**. Deftere yetenek
- - Sıra deterministiktir (istemci önbelleği + prompt önbelleği için).
- - Ad dönüşümü birebir değildir; çakışma olursa sunucu gürültülü hata verir

### `docs/MEDYA_ADLI.md` — 71 satır
**Başlık:** MEDYA ADLİ HATTI — indir · kare kare ölç · yazıya dök · eşleştir 

**Özet:** Ses **ve** metin makineden çıkmaz. Motor sırası: 1. `PINEAL_TRANSCRIBE_URL` — yalnız `127.0.0.1`/`localhost`/`[::1]`; uzak adres **sert reddedilir** (`non_local_endpoint`) ve CLI'ye sessizce DÜŞÜLMEZ.

**Ana bulgular / maddeler:**
- - Platform linki + yt-dlp yok → `dependency_missing:yt-dlp` (indirme uydurulmaz).
- - İndirme **özel/yerel adreslere yapılmaz** (`private_address_rejected`);
- - Boyut tavanı `MAX_DOWNLOAD_BYTES` (80 MB) — aşarsa dosya silinir, `too_large`.
- - Motor boş çıktı verirse transkript İDDİA EDİLMEZ (`empty_transcript`);
- - pHash DC terimini dışarıda bırakır: düz renkli iki fotoğraf "aynı" sayılmaz.
- - Kanıt satırı her zaman dosya yoluna/kaynağa bağlanır (`provenance_refs`).

### `docs/PINEAL_TUZUK.md` — 181 satır
**Başlık:** ATLAS PINEAL — TÜZÜK (v2) 

**Özet:** Pineal kurulurken ilk ve tek işi şuydu: Sistem o günden bu yana büyüdü. Kanıt mührü, 7 dalga motoru, 3'lü jüri, kasa mandalı, adli rapor, çok kanallı OSINT ve şimdi yetenek omurgası (Capability Spine) eklendi. **Alet, verilen ilk işten daha büyük hâle geldi.** Bu yüzden tüzük yeniden yazıldı: 1.

**Ana bulgular / maddeler:**
- - **Uyum / ilk temas / rezonans, bu sistemin TANIMI değildir artık; SAHALARINDAN BİRİDİR.**
- - Sistemin tanımı: **Atlas Pineal, kamuya açık kaynaklar üzerinde çalışan bir adli gözlem ve doğrulama istasyonudur.**
- - Bir yeteneğin ürüne girip giremeyeceği, "uyum analizine yardım ediyor mu?" sorusuyla değil, **bu tüzüğün maddeleriyle** ölçülür.

### `docs/RAPOR_FABRIKASI.md` — 79 satır
**Başlık:** RAPOR FABRİKASI — kanıt bağlantılı, mühürlü rapor paketi 

**Özet:** Paket yalnız **kanonik kanıt zaman çizelgesinden** beslenir (`services/evidence_timeline.py`): sıra, epistemik tür ve "not independently verified" gibi epistemik notlar oradan aynen taşınır. Her eserin `sha256`'sı hesaplanır; `<ad>.manifest.json` şunları taşır: Doğrulama: `manifest_sha256` alanını çıkar, kalan gövdeyi `json.dumps(..., sort_keys=True, separators=(",", ":"))` ile serileştir, sha256'sını hesapla — eşit çıkmalı. (Aynı kontrol testlerde kilitlidir.) curl -s -X POST http://127.0.0.1:8000/api/report/build \ -H 'Content-Type: application/json' \ -d '{"client_id":"op","title":"Örnek Ra

**Ana bulgular / maddeler:**
- - `strategy` türü çizelgeye girmez (çağrı dışı sayılır, manifest'te sayılır).
- - Bozuk/eksik satırlar **reddedilir** ve `rejected_item_count` olarak rapora
- - Rapor "özet/çıkarım" satırı üretmez; yalnız kanıtı düzenler.
- - `evidence_ids`: pakete giren kanıt kimlikleri (kanıt bağlantısı),
- - `artifacts`: eser adı + dosya adı + `sha256` + bayt,
- - epistemik sayımlar, reddedilen/çizelge dışı sayıları,

### `docs/YEREL_JURI.md` — 90 satır
**Başlık:** YEREL JÜRİ — karar tek modele bırakılmaz, veri makineden çıkmaz 

**Özet:** Panel kararı eskiden tek zincire (ya da uzak modellere) bağlıydı. Uzak jüri iki şeyi bedava vermez: maliyet sıfır değildir ve hedef verisi makineden çıkar. Yerel jüri aynı çapraz denetimi **yerel modellerde** koşar.

**Ana bulgular / maddeler:**
- - **Koltuk = ayrı model.** Aynı model adı iki kez yazılırsa ikinci koltuk
- - Tavan ``PINEAL_JURY_SEATS`` (varsayılan 3, en çok 5).
- - Tek model tanımlıysa jüri koşar ama kural ``tek_koltuk`` olur ve

### `docs/ZERO_TRUST_VERIFICATION_2026-09-18.md` — 159 satır
**Başlık:** PINEAL-HERETIC — Sıfır-Güven Doğrulama Turu (2026-09-18) 

**Özet:** Etiket sözlüğü: **DOĞRULANDI** = kendi ölçümüm + mutasyon testi kırmızı verdi. **KISMİ** = ölçüm yapıldı ama bir ön koşul eksik. **BULGU** = raporla çelişen gerçek.

**Ana bulgular / maddeler:**
- - Sonuç: **2885 mesajdan sonra donmuş soket setten atıldı** (t=40s); sonrasında sağlıklı
- - Mutant-2 (timeout kaldırıldı) → `test_send_ws_evicts_stuck_socket_on_timeout` **failed**.
- - **Nüans (tasarım gerçeği, regresyon değil):** Linux tcp_wmem 4 MB'a kadar büyüdüğü için donmuş
- - İlk deneme bilgisi: varsayılan RATE_LIMITS["api"]=(300,60) canlı doldurmayı engelledi (429),
- - WS koptu, oda evict edildi: `room_removed=true, session_close_called=true, child alive=false` ✔
- - Mutant-3 (`room.pop("browser")` + `_detach_browser_close` silindi) → `test_close_room_closes_browser_session` **failed** ✔


## Denetim raporları (docs/reports/*.md) — 41 belge

### `docs/reports/ADLI_DUZELTME_GUNLUGU.md` — 39 satır
**Başlık:** PİNEAL ADLİ DİRİLİŞ VE TEMİZLİK GÜNLÜĞÜ (CANLI TAKİP) 

**Özet:** Başlık: PİNEAL ADLİ DİRİLİŞ VE TEMİZLİK GÜNLÜĞÜ (CANLI TAKİP) | Alt başlıklar: PİNEAL ADLİ DİRİLİŞ VE TEMİZLİK GÜNLÜĞÜ (CANLI TAKİP) · 🎯 4 AŞAMALI HAREKÂT PLANI VE GERÇEK İLERLEME · 🔴 2026-09-03 — KIRMIZI HÜKÜMLERİN YENİDEN ÖLÇÜMÜ + G7 MEKANİZMA ONARIMI

### `docs/reports/AHLAKI_DOKUM_2026-10-05.md` — 308 satır
**Başlık:** 325 DEPO — AHLAKİ DÖKÜM 

**Özet:** 325 depo tek tek açıldı, içindeki **fikir** çıkarıldı, aynı fikri satanlar tek çatı altında toplandı. Sonuç: **99 ayrı fikir.** Yani 325 kayıt, 99 fikrin farklı dillerde, farklı takımlarca yeniden yazılmış hâli. Aşağıda bu 99 fikrin **ahlaki hükmü** var.

### `docs/reports/AKIS_RONTGENI_2026-09-21.md` — 553 satır
**Başlık:** PINEAL — UÇTAN UCA AKIŞ RÖNTGENİ (1. AŞAMA TEŞHİS RAPORU) 

**Özet:** Ölçülen referans koşu (stub LLM, gerçek HTTP + gerçek WS): `POST /api/initiate` → 200 · 69 WS çerçevesi · 0.15 s · 10 LLM çağrısı · 13 ajan koşusu · nihai durum `partially_completed` · mühür: `memory/op_…json`. Planlanan: `mirror_truth, autonomous_verifier, human_behavior, passion_mapper, friction_detector, cognitive_profiler, resonance_calc, pattern_interrupt, resonance_synthesizer` Koşan (13): `osint_investigator, pineal_7pillar, mirror_truth, autonomous_verifier, human_behavior, passion_mapper, friction_detector, cognitive_profiler, resonance_calc, pattern_interrupt, resonance_synthesizer, 

**Ana bulgular / maddeler:**
- - `_send_snapshot` payload'ında bu 8 alan **yok** (`api.py:1624-1630`),
- - `broadcast_result` payload'ında **yok** (`api.py:1937-1942`),
- - `CanonicalMemory._serialize` yalnız `evidence_chain` yazdığı için mühürde de **yok**.
- - `_new_task_id()` (`op_YYYYMMDDHHMMSS_<hex8>`) ↔ `CanonicalMemory._validate_task_id` uyumlu;
- - `_hash_evidence_result` kanonik SHA-256 (`sort_keys`, `ensure_ascii=False`, `default=str`).
- - `InsufficientEvidenceError` exception olarak yükseliyor → `halted_evidence` terminal durumu.

### `docs/reports/API_MONOLITH_SPLIT_PLAN.md` — 133 satır
**Başlık:** `backend/api.py` Tek-Modül Şişkinliği — Ölçüm ve Bölme Planı 

**Özet:** `backend/api.py`, FastAPI uygulamasının TAMAMINI tek bir modülde taşıyor: yaşam döngüsü (lifespan), middleware'ler, kimlik doğrulama, hız sınırlama, kasa (vault) yönetimi, tarayıcı oturumları, görev yürütme, OSINT, konuşma sentetikleme, MCP köprüsü ve OpenAI uyumlu ağ geçidi. Somut maliyetleri: Bölme, **en iyi test edilmiş ve en az bağımlılığı olan** katmanla başlar: Aşağıdaki tablo, gerçek `@app.*` dekoratörlerinden sayılmıştır. Bölme sırası, **bağımlılığı en az olandan çoğa** doğru önerilir.

**Ana bulgular / maddeler:**
- * `backend/api.py`: **6.034 → 5.937 satır** (−97)
- * Geriye dönük uyumluluk korunur: `backend/api.py` isimleri yeniden ihraç
- * Kilit: `tests/unit/test_api_monolith_ratchet.py`
- * Tetikleyici: dosyaya modül docstring'i (envanter açıklaması) yazılacaktı; ölçüm
- * `backend/api.py`: **6.000 → 5.916 satır** (docstring dâhil).
- * Tavan (`MAX_LINES`) 6.000 → **5.916** olarak DÜŞÜRÜLDÜ (ratchet: geri çıkış yok).

### `docs/reports/ARASTIRMA_MODEL_ESLEME_2026-09-08.md` — 85 satır
**Başlık:** PINEAL — AJAN→MODEL→SAĞLAYICI ARAŞTIRMASI (2026-09-08) 

**Özet:** Kaynaklar: [1](https://costgoat.com/pricing/openrouter), [2](https://www.usagepricing.com/blueprint/groq), [3](https://www.usagepricing.com/blueprint/cerebras), [4](https://ai.google.dev/gemini-api/docs/pricing), [5](https://ofox.ai/blog/openrouter-pricing-hidden-markup-breakdown-2026/), [6](https://pecollective.com/tools/anthropic-api-pricing/), [7](https://benchlm.ai/xai/api-pricing), [8](https://openrouter.ai/blog/insights/the-open-weight-models-that-matter-june-2026/), [9](https://tokenmix.ai/blog/gemini-api-pricing) Sınıflar (kullanıcının kendi 4 kategorisi): **A**ğır mantık/psikodinamik 

### `docs/reports/AUTHENTIC_VECTOR_FIX_REPORT.md` — 96 satır
**Başlık:** Düzeltme Raporu — Sahte Authentic Vector Engeli 

**Özet:** Önceki akış, authentic-vector LLM çağrısı hata verdiğinde aşağıdaki kararı verilebilir sahte veriyi üretiyordu: `ResonanceCalculator` da kullanıcı vektörü hiç yoksa ikinci bir default kullanıyordu: Bu iki davranış, verinin bulunmadığı bir durumda rezonans/uyum kararı verilmesine neden olabiliyordu. Dosya: `agent_core/task_executor.py`

### `docs/reports/C0_BASELINE_VERI_ENVANTERI_2026-09-26.md` — 105 satır
**Başlık:** C0 — Baseline veri envanteri (salt-okunur) 

**Özet:** Mevcut depo ve incelenen üretim akışları, bir hedefin geçmiş görevler arasında korunmuş, kaynağı doğrulanabilir zaman serisini **göstermiyor**. Standart Instagram yolu bir görev sırasında mevcut profilden en fazla 12 postluk örnek alıyor; P7 zaman motorları bu göreve verilen örnek üzerinde hesap yapıyor. Raporlar ve kanıt öğeleri görev bazında saklanabiliyor, ancak hedef kimliğine göre birleştirilmiş kaynak-post arşivi veya tekrar kullanılabilir kişisel referans dönemi yok.

**Ana bulgular / maddeler:**
- - `InstagramPost` modelinde kaynak shortcode, opsiyonel `taken_at`, caption ve opsiyonel like/comment sayıları bulunur. `InstagramProfile.posts` doğrulayıcısı post listesini **12 ile sınırlar**.
- - Scraper, tarihli postları artan zamana sıralar; tarihsizler sona alınır. Bir gönderinin tarihi yoksa uydurulmaz.
- - Instagram profili eşlemesi `posts`, `post_times` ve `posts_meta` listelerini aynı sırada taşır. Gerçek `post_times`, post modelindeki `taken_at` alanından gelir; bilinmeyen tarih boş string olarak kalır.
- - Parser’daki post ayrıntısı yolu, bazı eksik tarihleri sayfa JSON-LD/meta alanlarındaki `uploadDate` / `datePublished` / `dateCreated` veya `article:published_time` değerlerinden de doldurabilir. Bunlar tek `taken_at` a
- - Eşleme `shortcode`, profil `post_count`, `scraped_at`, `evidence_source` ve `platform` alanlarını `target_profile`’a aktarmıyor. Dolayısıyla kaynağın verebildiği toplam post sayısı örneklem denominator’ı olarak kullanı
- - Üretim yönlendiricisi platformu Instagram olarak biliyor; ancak eşlenmiş profilde `platform` bulunmadığı için `_profile_scope` platformu `unknown`, Frequency raporu ise varsayılan `primary` olarak görebiliyor. Bu, kayn

### `docs/reports/CAPABILITY_ROUTING_DECISION_2026-09-02.md` — 56 satır
**Başlık:** Capability routing — karar matrisi (2026-09-02) 

**Özet:** Kaynak: üç bağımsız piyasa/lab taramasının çelişki-ayıklanmış sentezi (kullanıcı araştırma paketi, 2026-09-02). Bu belge yalnız **uygulanan** kararları ve gerekçeyi sabitler; halüsinasyon/skor iddiası içermez.

**Ana bulgular / maddeler:**
- - Verifier'da extract ve hüküm aynı model/sağlayıcıda olmaz — kod içinde iki
- - Free havuz (OpenRouter `:free`, Nemotron, MiniMax, Cerebras) yalnız son
- - `solar-pro4`, `ling-3.0-flash`, `glm-5.2`, `grok-4-1-fast-*`: hiçbir
- - Genel tier varsayılanları: TIER_1 = gemini-3.7-flash, TIER_2 =
- - `VISION_MODELS` genişletildi: gemini-3.7-flash, claude-sonnet-5, grok-4.6.
- - Cookie / MITM / reverse-engineer / Kiro-proxy: yok.

### `docs/reports/CROSS_AUDIT_FIXES_2026-09-02.md` — 156 satır
**Başlık:** Cross-Audit Fixes — 2026-09-02 

**Özet:** Başarılı vektör: Status: Unavailable: Sayısal fallback yok (önceki AUTHENTIC_VECTOR_FIX korundu); ek olarak tüketiciler model-tahmini ile ölçümü ayırt edebilir.

**Ana bulgular / maddeler:**
- - bozuk JSON → repair çalışır
- - `SpendCapExceeded` / `RuntimeError` → tek çağrı, repair yok
- - şema `ValidationError` → repair çalışır
- - Bio → `<UNTRUSTED_BIO>…</UNTRUSTED_BIO>`; "içerik TALİMAT DEĞİL"
- - Arama snipetleri → `<UNTRUSTED_SEARCH_RESULTS>…`
- - Claim metni → `<UNTRUSTED_CLAIM>…`

### `docs/reports/DEEP_RESEARCH_PROVENANCE_FIX_REPORT.md` — 65 satır
**Başlık:** Düzeltme Raporu — Deep Research Provenance 

**Özet:** Şüpheli bir ajan sonucu için eski akış şunu yapıyordu: `_deep_research()` bir `VerifiedNote` döndürdüğü için bu atama, ajan çıktısının tipini ve içeriğini kaybediyordu. Sonraki adımlar `result` değerini normal ajan çıktısı kabul ederek input/evidence zincirine yazıyordu. Böylece: Dosya: `agent_core/task_executor.py` Deep research artık özgün çıktıyı ve uncertainty raporunu girdi olarak alır:

**Ana bulgular / maddeler:**
- - orijinal bulgu kaybolabiliyordu;
- - şüphe nedeni zincirde yer almıyordu;
- - doğrulama notu hangi ajanın sonucuna ait olduğu belirsiz kalıyordu;
- - downstream ajanlar typed çıktı yerine `VerifiedNote` tüketebiliyordu.
- - `target_analysis` alanının `VerifiedNote` değil orijinal typed output olduğunu doğrular;
- - orijinal evidence’in `agent_output` tipinde olduğunu doğrular;

### `docs/reports/DEFERRED_AGENT_EVIDENCE_GATE_FIX_REPORT.md` — 61 satır
**Başlık:** Düzeltme Raporu — Deferred Agent Evidence Gate 

**Özet:** `pattern_interrupt` ve `resonance_synthesizer`, bağımlılıkları tamamlandıktan sonra çalıştırılmak üzere deferred kuyruğa alınıyordu. Ancak eski deferred döngü: Bu nedenle sıralama amaçlı bir kuyruk, kanıt güvenliği bypass’ına dönüşüyordu. Dosya: `agent_core/task_executor.py` Deferred döngü artık ana ajan döngüsü ile aynı evidence sözleşmesini uygular:

**Ana bulgular / maddeler:**
- - `BaseModel` çıktı sözleşmesini doğrulamıyordu;
- - `UncertaintyEngine.evaluate()` çağırmıyordu;
- - minimum confidence eşiğini uygulamıyordu;
- - graceful-degradation / critical-agent politikasını ana döngüden farklı uyguluyordu;
- - tamamlanan adım eventini yayımlamıyordu.
- - tanınmayan agent adı açık hata verir;

### `docs/reports/DURUM_RAPORU.md` — 217 satır
**Başlık:** DURUM RAPORU — "Ürün hazır" demeden önce kapanması gerekenler 

**Özet:** `TelemetryData` (`data/model/Models.kt:111-114`) `cacheHitRate` ve `cacheHits` parametrelerini **birer kez** tanımlıyor. Aynı isimli argümanın iki kez verilmesi Kotlin'de derleme hatasıdır → `gradle assembleDebug` ve dolayısıyla CI'daki `android` işi **kırmızı** olur. Venv: `/tmp/pvenv` (requirements.txt + pytest/pytest-asyncio/ruff).

**Ana bulgular / maddeler:**
- - `android/app/src/main/java/com/example/pineal/engine/gemini/GeminiClient.kt`
- - Android tarafında **hiçbir** backend referansı yok: `grep` ile `localhost`,
- - `PinealAnalyzerEngine.kt` tek atımlık (single-shot) Gemini "deep inference" ile
- - `GeminiClient.kt` model adları (`gemini-1.5-flash` — kullanımdan kaldırılmış,
- - `android/gradle/wrapper/` ve `android/gradlew` **repo'da yok**; CI `android`
- - `debug.keystore` dosyası `rootDir` altında yok ama `signingConfigs.debug` bunu

### `docs/reports/DURUM_RAPORU_2026-08-30.md` — 186 satır
**Başlık:** PINEAL-CLEAN — MEVCUT DURUM RAPORU 

**Özet:** Pineal, bir **360° insan-profili analiz ve sahici iletişim** sistemidir. Akış: Temel ilke kodun her yerinde aynıdır: **kanıt yoksa sistem durur, asla içerik üretmez.** Tüm HTTP/WebSocket yüzeyi tek dosyada, gruplar hâlinde: Güvenlik: `PINEAL_TOKEN` tanımlanırsa tüm API `X-API-Key` ister; CORS `PINEAL_ALLOWED_ORIGINS` ile sınırlandırılır; tüm dış URL indirmeleri SSRF guard'dan (`is_safe_url`) geçer.

**Ana bulgular / maddeler:**
- - **Ajan kaydı:** 13 ajan kurulu; 14'üncü (InterpreterAgent) yalnız `ENABLE_INTERPRETER=true` ile yüklenir.
- - **Kanıt zinciri:** her ajan adımı `evidence_chain`'e imzalı kayıt düşer; `CanonicalMemory` görev başına JSON'da saklar.
- - **Dürüst duruşlar:** yeterli kanıt yoksa görev `halted_*` ile durur; rezonans eşiği altındaysa `halted_frequency`; LLM yoksa ilk LLM'li ajan durur (sahte çıktı yok).
- - `memory_models.py`: `PassionProfile`, `FrictionProfile`, `CognitiveStyle`, `AuthenticBridge`, `HolisticProfile` (360° mühür), `TaskSnapshot`, `AspasiaSession`, `AgentRun`
- - `pillar_models.py` / `pillar_wave2_models.py`: alt analiz motorlarının çıktı şemaları
- - `pipeline_status.py`: durum makinesi sabitleri

### `docs/reports/DURUM_TESPITI_2026-09-08.md` — 240 satır
**Başlık:** PINEAL — TEPEDEN TIRNAĞA DURUM TESPİTİ 

**Özet:** CI komutu: `pip install -r requirements.txt ruff pytest pytest-asyncio pytest-cov` → `ruff check .` → `pytest -q -p no:cacheprovider --cov=agent_core --cov=backend --cov-report=term-missing:skip-covered --cov-fail-under=80` (+ frontend `npm ci && npm run check && npm run build`, smoke uvicorn, rust `cargo check --all-targets && cargo test --locked`, android gradle). Tümü aynen çalıştırıldı: `git log --oneline d81ca594..HEAD` → 6 commit (hepsi main'de, Salim Gümüş): Kanıt zinciri (her commit'te `ruff` çalıştırıldı): - `d81ca594` (merge, HEAD'in babası): **ruff PASS** ("All checks passed!") - `0

**Ana bulgular / maddeler:**
- - `1f1ea892ce0e1480731a226decef2a972232ab1b` — **2026-09-06 00:55:31 UTC**, mesaj `S1: production spend-cap fail-closed (PRODUCTION_SPEND_CAP_REQUIRED) + N7 rate-limit identity docs`.
- - **HEAD, `1f1ea89`'un 27 commit alt torunudur** (merge-base == `1f1ea89`; `git rev-list --count 1f1ea89..HEAD` = 27). Alakasız dal değil, üzerine bina edilmiş.
- - `1f1ea89`'da CI **gerçekten yeşildi**: GitHub Actions run **#503 / id `34002549846`** → `frontend: success, backend: success, rust-core: success, android: success, smoke: success`. Yani kapanış iddiası o an için doğruy
- - HEAD'de CI **kırmızı** (run **#55 / id `34182589597`**, 51 dk önce tamamlanmış):
- - `d81ca594` (merge, HEAD'in babası): **ruff PASS** ("All checks passed!")
- - `024c82b0` (2026-09-08 05:08:17 +0300): **ruff FAIL** (dosya bu commit'te 2 kullanılmayan import ile eklendi)

### `docs/reports/EKSIK_YETENEKLER_2026-09-26.md` — 82 satır
**Başlık:** Yedi Önerilen Eksiklik — Kod Tabanı İncelemesi 

**Özet:** “Bulunamadı” ifadesi, ilgili özelliğin bu incelemede aranan dosya/çağrı akışlarında entegre bir uygulamasının görülmediği anlamına gelir; tek başına `grep` ile tüm olası davranışların yokluğu kanıtlanmış olmaz. Pozitif eşleşmelerin ilgili kaynak kodu ayrıca okundu. Aşağıdaki **kısmi** etiketleri, yakın bir mekanizmanın varlığını bildirir; önerilen yeteneğin tamamlandığı anlamına gelmez.

**Ana bulgular / maddeler:**
- - `VisionAnalyzer.analyze_images()` en çok dört görsel URL'sini indirip multimodal modele görünür nesne, ortam, eylem ve estetik özeti çıkarttırır; tersine görsel araması çağrısı değildir (`agent_core/services/vision_ana
- - `AuthenticityAuditor` biyografi/gönderi metinlerini bu görsel özetle karşılaştırır. Çıktısı LLM yorumudur; fotoğraf kökeni, yüz kimliği veya profil sahibinin gerçek kimliği için doğrulama sağlamaz (`agent_core/agents/a
- - `audit_followers()` takipçi ve beğeni/yorum **adetlerinden** etkileşim oranı hesaplar; düşük oran için “şüpheli/şişirme şüphesi” heuristiği üretir. Bu, tek başına bot veya catfish tespiti değildir (`agent_core/services
- - `agent_core/`, `backend/` ve `frontend/` içinde yaş doğrulaması, reşit olmayan hedef tespiti veya rıza onayı ile analiz/mesaj rotasını durduran bir kapı bulunmadı.
- - `PatternInterrupt` istemi saygı, sınır ve rızaya uygun mesaj ister (`agent_core/agents/pattern_interrupt.py:111-136`); metin talimatı, doğrulanmış yaşı veya rızayı makine tarafından kontrol eden kapı değildir.
- - Gizli profilde erişilebilir gönderi yoksa scraper yetersiz kanıtla durabilir (`agent_core/scraper/instagram_ghost.py:498-500`); bu da yaş/rıza kontrolü değildir.

### `docs/reports/FAZ2_MUHUR_RAPORU_2026-09-08.md` — 138 satır
**Başlık:** PINEAL — FAZ-2 MÜHÜR RAPORU (2026-09-08) 

**Özet:** FAZ-2 (ENFORCE free-only + canlı-ID katalog düzeltmeleri) tamamlandı. Aşağıdaki kanıtlar mühür kriterlerinle birebir eşleşir; **mühürsüz FAZ-3 YOK** (vision / Google direct ertelemesi dahil — bu fazda vision'a dokunulmadı). Aynalanan dosyalar: `config/provider_catalog.json`, `agent_core/services/final_routing_policy.py` (ROUTES + TASK_GROUPS), `scripts/verify_openrouter_catalog.py` (`REQUIRED_NOUS_FREE` → 3 ID).

**Ana bulgular / maddeler:**
- - **SHA:** `2006f6968fdb5e8691f2918be812c34aac239289` (`2006f696`)
- - **Branch:** `arena/01a07f2a-pineal-clean` (parent `f2b2c74f` = FAZ-1 mühürlü commit)
- - **Mesaj:** `feat(routing): FAZ-2 ENFORCE free-only + canlı-ID katalog düzeltmeleri (Q1/Q2)`
- - **Kapsam:** 12 dosya (+234/−119)
- - **CI:** run `34199584703` → **success, 5/5 job** (android, rust-core, frontend, backend, smoke)
- - **Unit suite:** `942 passed, 3 skipped` (FAZ-1'de 940/3; net +2 — FAZ-2 kilit testleri)

### `docs/reports/FAZ3_GIRDI_2026-09-08.md` — 71 satır
**Başlık:** PINEAL — FAZ-3 GİRDİ KAYDI (2026-09-08) 

**Özet:** Güven gerekçeleri (2. ajan): 1. Sayılar kapanıyor: 1132 = 1099 (entegrasyon) + 31 (FAZ-1) + 2 (FAZ-2 net) — uydurularak tutturulamaz.

**Ana bulgular / maddeler:**
- - **Durum:** Girdi envanteri. Kod değişikliği YOK. FAZ-3 onaysız kod YOK.
- - **Mühür:** `2006f696` + CI run `34199584703` (5/5) — AYAKTA (2. ajan).
- - **Bu dosya:** FAZ-3 kapsam kararlarına girecek girdilerin tek sicili (untracked).
- - `ZF_ADLI_DENETIM_2026-09-08.md` — kabul edilen denetim raporu (untracked).
- - `FAZ2_MUHUR_RAPORU_2026-09-08.md` — mühür kanıtları + "Bilinçli ertelemeler / notlar (FAZ-3'e)".
- - Bu kayıt (untracked): FAZ-3 girdi sicili.

### `docs/reports/FAZ_E_PLANI_2026-10-07.md` — 303 satır
**Başlık:** PINEAL EPİFİZ — FAZ E PLANI (ÖNERİ) 

**Özet:** Bu bölüm **CI kanıtı + bağımsız kaynak denetimi** ile yazıldı. Aşağıdaki plan metni tarihsel kayıt olarak korundu; ölçüm anı `main` @ `162d7ec` idi ve hâlâ öyle. Planın açılış sorusu — *"E1 Rust onarımı bu fazda mı, ayrı bir vault PR'ı olarak mı yürüsün?"* — **fiilen cevaplandı: ayrı bir PR olarak yürüdü** ve onarıldı.

**Ana bulgular / maddeler:**
- - **Künye:** PR **#113** · dal `arena/51add43a-pineal-epifiz` · head `1518017d` (4 commit) · 16 dosya · durum **AÇIK**, `main`'e göre `BEHIND`, **7/7 kontrol yeşil**.
- - **rust-core adım kanıtı** (run `37562185866` · job `112601776418`): adım 5 "Cargo check (core, no tauri feature)" → **success** · adım 6 "Cargo test" → **success** — yani yalnız derlenmiyor, `#[ignore]`'lı test **gerçe
- - **Bağımsız kaynak denetimi** (`rust_core/src/vault.rs` @ `1518017d`): `#[ignore]` özniteliği **yok** (yalnız yorumlarda, satır 10 ve 586); `cfg!(test)` / erken `return` / `should_panic` gibi kaçış yolu **yok**; `writer
- - **Süreç kanıtı (dürüstlük notu):** ilk CI denemesi kırmızı yandı — `E0277`: `StealthVault` `Debug` türetmiyor, çünkü `unwrap_err()` `T: Debug` ister ve `age::x25519::Identity` `Debug` türetmez. Onarım: elle yazılmış, s
- - 15 dış-çıkış ucu `_require_vault_open` → **423 `VAULT_LOCKED`** ile sert reddediliyor; 5 muafiyet (örn. `/api/browser/close` — açık kanalı *kapatır*, zombi Chromium bırakmasın) gerekçesiyle adıyla yazılı.
- - `SearchEngine` kilitliyken **hiç `httpx` istemcisi kurmuyor** (`status="VAULT_LOCKED"`, `available=False`) — DuckDuckGo dâhil. Öncesinde yalnız SearXNG omurga yolu kapılıydı, ücretsiz yollar açıktı.

### `docs/reports/FIXES_APPLIED.md` — 118 satır
**Başlık:** UYGULANAN DÜZELTMELER — Denetim Sonrası Fix Pass 

**Özet:** Bu fix pass sırasında uzak `main`'in (PR #31, `fix-static-findings-3`) ikinci denetim raporundaki bulguların bir bölümünü zaten merge ettiği görüldü (TIER_2 env, SERPAPI, USE_LOCAL_LLM, spend-cap 0.0, litellm/PyYAML/aiohttp, test hizalama, muse-spark, reflection.sql, router'da interpreter kapısı, android CI). Commit, yeni main üzerine rebase edildi; çakışmalarda **daha tam/daha dürüst taraf** seçildi:

**Ana bulgular / maddeler:**
- - name: Setup Gradle
- - uses: gradle/gradle-build-action@v2
- - name: Make gradlew executable
- - run: chmod +x ./gradlew
- - name: Check & Build Android App
- - ./gradlew lintDebug || true

### `docs/reports/FORENSIC_AUDIT_2026-08-29.md` — 782 satır
**Başlık:** PINEAL-CLEAN — ADLİ YAZILIM İNCELEME RAPORU 

**Özet:** Bu depo, **tek kullanıcılı yerel bir analiz istasyonu** olarak tasarlanmış hibrit bir sistemdir: Hesap: \(0.15\cdot9 + 0.15\cdot8 + 0.15\cdot7 + 0.15\cdot3 + 0.10\cdot3 + 0.10\cdot7 + 0.10\cdot5 + 0.05\cdot5 + 0.05\cdot4 = 6.20\) → **62/100**. 6. `POST /api/initiate` aynı client → **429** [PROVEN] Token set → `/api/*` 401 without key; 200 with `X-API-Key`; WS token’sız disconnect [PROVEN]

**Ana bulgular / maddeler:**
- - `OPENROUTER_API_KEY` yok → canlı LLM / OpenRouter [NOT_EXECUTED]
- - Docker yok → imaj build [NOT_EXECUTED]
- - `cargo`/`rustc` yok → rust_core derleme [NOT_EXECUTED]
- - Android `gradlew` yok → Android assemble [NOT_EXECUTED]
- - Playwright Chromium binary yok → Instagram scrape runtime [NOT_EXECUTED]
- - `curl /` → HTTP 200, `index.html` + `assets/index-*.js`

### `docs/reports/GENEL_DURUM_HARITASI_2026-09-02.md` — 176 satır
**Başlık:** Pineal-clean — Genel Durum Haritası ve Eksik Analizi 

**Özet:** Kısa özümleme: Proje **22 Ağu → 2 Eyl** arasında 52 PR'lık bir yol kat etti ve bugün **`v3.0.0-rc.1`** sürüm etiketi üzerinde **"router yayılma dalgası"** ile sonlandı. Capability policy patch'i kaybolmadı — **#52 + #53 olarak main'de**. LOKAL (bu oturum): arena/01a06052 ── 0 ahead / 1 behind main (b14a8e16 eksik) ``` Kapatılıp merge edilmeyen 14 PR'ın sınıflandırması: 1.

**Ana bulgular / maddeler:**
- - **Main CI** (`b14a8e16`): run `33590408702` → ✅ success (backend, frontend, rust-core, android, smoke, Vercel).
- - **Ana dal HEAD'inde lokal test**: 634 passed, 2 skipped → **%83.31 coverage** (eşik %80) ✅; `ruff check .` ✅ (aynı içerik #53 head'i `d8162c9` üzerinde koşuldu).
- - **Squash etkisi notu**: merge edilmiş dallar `git merge-base` ile `main`'in atası **görünmüyor** (squash); "main'de mi?" kararı PR `mergedAt` alanından doğrulandı.
- - **Klon notu**: lokal klon tek dal (`main` shallow); diğer dallar `git fetch` ile ayrı ayrı çekildi (analiz için yeterli, arşiv için ideal değil).

### `docs/reports/GO_NO_GO_AUDIT_2026-09-11.md` — 185 satır
**Başlık:** GO / NO-GO DENETİMİ — 2026-09-11 (Sıfır-Güven Turu) 

**Özet:** CI workflow (push @ `e3ea76b`): run `34252493534` + `34252492283` → **success**. Job matrisi (her iki run'da da): `frontend ✅ · rust-core ✅ · android ✅ · backend ✅ · smoke ✅`. Ancak aynı HEAD'in **commit status**'u: Sonuç: "CI yeşil → canlı hazır" denklemi bu HEAD'de kurulamaz.

**Ana bulgular / maddeler:**
- - Yerel HEAD `e3ea76b…` = `origin/main` = denetim talebindeki hedef hash. Tekil prod commit olarak doğrulandı.
- - `git status --porcelain --ignored=matching`: dirty dosya yok, `.env`/secret sızıntısı yok.
- - ⚠️ Şerh: checkout **shallow (depth 1)**. Commit geçmişi yerelden denetlenemiyor; tarihçe iddiaları bu turda kapsam dışı bırakıldı (zaten sıfır-güven prensibi gereği tarihçe kanıt sayılmıyor).
- - Python tarafında **hiçbir lock file yok** (yalnız `rust_core/Cargo.lock` ve `frontend/package-lock.json` var).
- - `requirements.txt` tamamen `>=` aralıkları (`fastapi>=0.115.0`, `httpx>=0.27.0`, …).
- - Bugünkü imaj ile bir hafta sonraki imaj aynı ağacı kurmayı garanti etmiyor; BadHost

### `docs/reports/IMPLEMENTATION_PLAN_TAURI_NATIVE.md` — 218 satır
**Başlık:** PINEAL-HERETIC v5.0 - TAURI NATIVE + AGENT RACK + ORGANIK IRIS + VAULT PLANI 

**Özet:** 2. `frontend/vite.config.ts` güncelle: - server.port 1420, strictPort true, host 0.0.0.0, allowedHosts true - server.hmr.port 1421 (Tauri icin) - clearScreen false - envPrefix ["VITE_", "TAURI_"] - proxy /api ve /ws hala 127.0.0.1:8000 3. `rust_core/src-tauri/Cargo.toml` ve `src-tauri/src/lib.rs`: - lib.rs'te window olusturma, setup closure'da telemetry bridge zaten var - capabilities/default.json'a "core:window:allow-start-dragging", "core:window:allow-set-size" vb ekle veya shell:allow-open 4.

**Ana bulgular / maddeler:**
- - **rust_core/src-tauri/tauri.conf.json**: minimal 800x600, identifier com.tauri.dev, devUrl localhost:5173, beforeDevCommand npm run dev (hatali path), csp null
- - **rust_core/src-tauri/src/lib.rs**: 6 komut (create_vault, open_vault, set/get_credentials, query_aspasia, start_analysis), CoreState tek, telemetry bridge var
- - **rust_core/src/tauri_bridge.rs**: sadece CoreState + telemetry bridge, vault yolu default_vault_path tek kaynak
- - **frontend**: Svelte 5 + Vite 6, App.svelte WS ile backend'e bagli, AtlasPinealCockpit.svelte 16:9 sasi + yasayan goz (lazer değil, translate/scale), store.ts API_BASE + WS_BASE tek kaynak, localStorage token
- - **backend/api.py**: FastAPI + WS /ws/{client_id}, task executor, rate limit, body limit, vault interlock yok, redis yok
- - **docker-compose.yml**: tek servis pineal (8000), 3 volume, replica 1

### `docs/reports/INDEPENDENT_FORENSIC_AUDIT.md` — 277 satır
**Başlık:** INDEPENDENT FORENSIC AUDIT — pineal-clean 

**Özet:** Sistem, README'nin çoğu iddiasının **gerçekten çalıştığı ender bir proje**: sahte/placeholder yanıt üretmeyen, kanıt yoksa **dürüstçe duran** (halted_evidence) bir ajan pipeline'ı kodda değil, **çalışma zamanında doğrulandı**. Sunucu ayağa kalktı, Svelte arayüzü servis edildi, WebSocket üzerinden FIFO telemetri + sonuç üretildi, kimlik doğrulama ve hız limiti çalıştı, bellek kalıcılığı ve kalıcı silme çalıştı. Ancak denetim şunları da tespit etti: Zincir şablonu: **AGENT → PROMPT → MODEL → PROVIDER → TOOL → OUTPUT → CONSUMER** Model adı gerçekten kullanılıyor mu?

**Ana bulgular / maddeler:**
- - **2 test kod–kontrat uyuşmazlığı nedeniyle FAIL** (345/347 geçti); bu haliyle CI'ın backend job'ı da kırmızı olur.
- - **README/RUNBOOK'taki model zinciri belgeleri kodla çelişiyor** (kodda hiç olmayan `laguna-s-2.1`, `minimax-m2.7`, `qwen3-235b-a22b-2507` zincirleri belgelenmiş).
- - **README + ARCHITECTURE: "rust_core CI'da derlenmiyor" — ÇELİŞKİ:** `ci.yml` içinde Rust derleyip test eden `rust-core` job'u var.
- - **`USE_LOCAL_LLM` env değişkeni API sunucusu yoksayılıyor** (vault değeriyle eziliyor) — çalışma zamanında kanıtlandı.
- - **`OPENROUTER_TIER_2_MODEL` env'i belgelenmiş ama kodda hiç okunmuyor** (ölü config).
- - **Android uygulaması Python backend'ine hiç bağlanmıyor**; doğrudan Google Gemini API'sine konuşan bağımsız bir istemci.

### `docs/reports/INTEGRATION_PLAN.md` — 398 satır
**Başlık:** INTEGRATION PLAN — OSINT/Stealth/AI Araç Listesi Uzlaşması 

**Özet:** Maigret 0.6.5'te ağ hatası durumlarında `SiteResult.status = None` dönebiliyor (checker future'ı istisna ile ölüyor; ilk ham testte `<Unknown (Connecting failure)>` görünürken ikinci koşuda None). İlk sınıflandırmamız None'ı "hata değil" sayıyordu → **hiç kontrol yapılmadan 'iz yok' iddia edilebilirdi.** Düzeltme: `status in (UNKNOWN, None)` → error_count. Canlı doğrulama: 21 site / 21 hata → `available:false, reason:provider_errors` (uydurma yok).

**Ana bulgular / maddeler:**
- - `agent_core/services/socid_enricher.py` — URL/HTML → yapılandırılmış kimlik kaydı; SSRF guard'lı; ImportError/ağ/parse hatalarında dürüst `available:false`
- - `POST /api/experimental/socid/extract` — kullanıcı bir profil URL'si yapıştırır, yapılandırılmış kayıt alır
- - `_run_public_web_research` zenginleştirmesi — eşleşen arama sonuçlarına (ilk 3) `socid` alanı eklenir (yalnız kayıt bulunduğunda)
- - Testler: `tests/unit/test_socid_enricher.py`
- - `agent_core/services/maigret_scanner.py`: kullanıcı-adı varlık taraması.
- - `POST /api/experimental/maigret/scan` — deneysel uç (kullanıcı adı

### `docs/reports/JULES_DENETIM_2026-10-06.md` — 368 satır
**Başlık:** PINEAL · TAM DENETİM GÖREVİ RAPORU — 2026-10-06 

**Özet:** Bu rapor, PINEAL-HERETIC deposunun üç ayrı perspektiften (Yazılımcı, Operatör, Üçüncü Göz) acımasızca incelenmesi sonucu oluşturulmuştur. Amaç kusur bulmak ve çözüm üretmektir. Yeni özellik eklenmemiş, sadece mevcut mimari ve kodun iddialarla uyuşmayan, çürük, "tiyatro" veya güvensiz yanları tespit edilmiştir.

**Ana bulgular / maddeler:**
- - Rust CI'daki ignored test aktifleştirilmeli ve Vault truncating bug'ı onarılmalı.
- - `backend/api.py` içindeki tüm scraper/browser uç noktaları `get_vault_status` (kasa kilit) middleware kontrolüne bağlanmalı.
- - API seviyesine global bir `MinorGateMiddleware` eklenerek hedef sorguları engellenmeli.
- - Tüm experimental uç noktalar, ilgili motor yoksa 200 OK yerine 400 (Dependency Missing) dönmeli (Uydurma veri yasağı).
- - `agent_worker.py` içindeki Redis ve REST fallback catch'leri kaldırılmalı, loglanmalı ve "Wait/Degraded" durumları arayüze basılmalı.
- - `asyncio.gather` kullanımlarına `return_exceptions=True` argümanı eklenerek tekil hataların tüm akışı çökertmesi engellenmeli.

### `docs/reports/P0_CI_FIX_RAPORU_2026-09-08.md` — 63 satır
**Başlık:** P0 — CI REGRESYON FİX RAPORU (2026-09-08) 

**Özet:** Yani test hem "gerçek üretim `std::fs` kullanımı KIRMIZI" hem de "test-only kullanım + yorumlar YEŞİL" koşulunu kanıtlıyor. Yerel (CI backend job'ının birebir komutu: `pytest -q -p no:cacheprovider --cov=agent_core --cov=backend --cov-report=term-missing:skip-covered --cov-fail-under=80`): Sapma yok: fix yalnız iki test/kapı dosyasındaki kullanılmayan import ve tarama sözleşmesini düzeltti; üretim kodu ve test davranışı değişmedi (1089 sayısının birebir korunması bunun kanıtıdır).

**Ana bulgular / maddeler:**
- - **SHA:** `1ce27343724d70f8815c7fd2a5f74fd56c56c3c7` (`1ce27343`)
- - **Branch:** `arena/01a07f2a-pineal-clean` (HEAD; parent `85839da`)
- - **Mesaj:** `fix(ci): repair ruff lint and rust purity_scan gates broken since 024c82b0`
- - **Kapsam:** 2 dosya, +37/−4. Mimari/merge, UI etiket senkronu, config kalıntılarına **dokunulmadı**.
- - `_RTK_POLICY_PATH` importu kaldırıldı — dosyada yalnız **string** olarak `monkeypatch.setattr("agent_core.services.llm_gateway._RTK_POLICY_PATH", ...)` (satır 23/37/122) geçiyor; import nesnesi hiç kullanılmıyor.
- - `from pathlib import Path` kaldırıldı — dosyada hiç kullanılmıyor.

### `docs/reports/P0_PERSONAL_BASELINE_INFRASTRUCTURE_SCOPE_2026-09-26.md` — 59 satır
**Başlık:** P0 — Personal Baseline Infrastructure 

**Özet:** 1. **Hedefe bağlı kimlik** — Görevler arasında aynı hedefi güvenilir ve doğru yetki sınırında tanıyacak bir kimlik sözleşmesi. 2.

**Ana bulgular / maddeler:**
- - Görev kimliği, hedef kimliği yerine kullanılmaz. Görevler arası bağ ancak hedef eşlemesi açıkça çözüldüğünde ve izin sınırı içinde kurulur.
- - Kaynak post kimliği, kaynakta gerçekten varsa taşınır. Kaynak-native kimlik yoksa yalnız metin veya timestamp’ten kesin post kimliği türetilmez; eşleşemeyen kayıt belirsizliğiyle tutulur ve baseline girdisi sayılması a
- - **Kaynakta yayınlanma zamanı** ile **sistemin yakalama zamanı** ayrı alanlar/semantikler olarak korunur. Hangi timestamp’in hangi kaynak alanından ya da fallback yönteminden geldiği manifestte kaydedilir; bilinmeyen de
- - Her yakalama için istenen/alınan örnek kapsamı ve sınırlamalar kaydedilir: platform/kaynak, yakalama zamanı, scraper/şema sürümü, örnekleme veya sayfa sınırı, alınan ve tarihli kayıt sayıları, zaman penceresi, eksik al
- - Aynı post yeniden görüldüğünde post kimliği tekilleştirilir; farklı yakalama zamanlarında değişebilen metrikler geçmiş gözlem olarak korunur veya ayrı bir tarihçe kuralına bağlanır. Sonraki değer, önceki ölçümü sessizc
- - Farklı kullanıcı/tenant kapsamındaki hedef verileri birbirine karışmaz. Okuma, yazma ve silme işlemleri denetlenebilir olur.

### `docs/reports/PRODUCTION_AUDIT_2026-09-04.md` — 1478 satır
**Başlık:** PINEAL-HERETIC v3.0.0-rc.1 — Üretim Öncesi Kod Denetimi (Forensic QA) 

**Özet:** İlk 6 öncelik + çapraz denetimde çıkan bir ek boşluk kapatıldı. Aşağıdaki rakamların tamamı bu turda **yeniden ölçüldü**; raporun geri kalanı bulguların ilk hâlini belgelemeye devam ediyor. İlk onarım budamayı **yalnızca yazım sayısına** bağlamıştı (her 256 yazım).

**Ana bulgular / maddeler:**
- - TTL 7 gün ile yaz → aynı dosyayı TTL 1 sn ile aç → **7 günlük kayıt 1.2 sn'de yok** (erken silme)
- - TTL 1 sn ile yaz → TTL süresiz ile aç → **süresi dolmuş kayıt sonsuza dek yaşıyor**, `prune()` 0 satır siliyor
- - `backend/api.py:917` — `broadcast_log` → `redact_text(msg)`
- - `backend/api.py:939` — `broadcast_event` → `redact_structure(event.model_dump(...))`
- - `backend/api.py:985/988` — snapshot gövdesi; `:1233/1248/1251` — result gövdesi
- - **Eşzamanlı 50 görev**: `asyncio.gather` ile 50 `execute_task` → `call_log` 500 sınırının

### `docs/reports/PRODUCTION_REPAIR_PLAN.md` — 257 satır
**Başlık:** PINEAL-CLEAN — GERÇEK DÜZELTME PLANI 

**Özet:** 1. `main` doğrudan değiştirilmez; bütün düzeltmeler hardening dalında ilerler. 2.

**Ana bulgular / maddeler:**
- - [ ] `hardening/production-proof` temiz baseline olarak kaydedilecek.
- - [ ] Python: lint + test + coverage kapısı.
- - [ ] Frontend: type/check + build kapısı.
- - [ ] Rust: `cargo check` + `cargo test`.
- - [ ] Android: canonical JDK/Gradle/AGP/Kotlin/KSP kombinasyonu belirlenecek; `gradlew` yoksa CI buna göre düzenlenecek.
- - [ ] Android: lint + unit test + assemble.

### `docs/reports/RELEASE_EVIDENCE.md` — 290 satır
**Başlık:** PINEAL-HERETIC v3.0 — Release Evidence Record 

**Özet:** Bu belge, deployment kararı için gereken kanıtları mühürler. Satır satır referans alınabilir; yorum veya iddia içermez. rm -rf memory && mkdir memory # felaket simülasyonu bash scripts/backup_restore.sh restore backups/pineal_20260901_114807.tar.gz # → 63 görev geri yüklendi ls memory/ | wc -l # → 63 ```

**Ana bulgular / maddeler:**
- - `UNIFIED_ROUTER_CONFIG_MISSING`: `PINEAL_LLM_BACKEND=unified` ama config yok
- - `SPEND_CAP_UNLIMITED`: Production'da `OPENROUTER_MAX_SPEND_USD=0`
- - Pipeline durumu: `completed` veya `partially_completed`
- - `evidence_chain` dolu (mock değil)
- - Kritik ajanlarda (`mirror_truth`, `passion_mapper`, `cognitive_profiler`, `resonance_synthesizer` vb.) sıfır `UNAVAILABLE` fallback
- - `HolisticProfile.passions / frictions / cognitive / bridge` dolu ve schema-valid

### `docs/reports/REPORT_CROSS_VALIDATION.md` — 101 satır
**Başlık:** RAPOR KARŞILAŞTIRMA VE ÇAPRAZ DOĞRULAMA 

**Özet:** 1. **Canlı OpenRouter katalog doğrulaması:** 6/6 model slug + 4/6 fiyat birebir; **`z-ai/glm-5.2` (0.10/0.10) ve `deepseek-v4-pro` (0.50/1.00) fiyat kayıtları katalog minimumlarının altında → spend cap gerçek maliyetin altında sayar** (B'de yok). 2.

**Ana bulgular / maddeler:**
- - Rapor B'nin **62/100** skoru öznel ama metodolojisi açık; A skor vermedi. İki raporun nitel hükümleri **aynıdır**: *"Orkestrasyon iskeleti (API + UI + executor + bellek + güvenlik kapıları) çalışır durumda; vaat edilen
- - A'nın katkısı bu hükmün **canlı-sağlayıcı zinciriyle** sınanmış olması (yerel provider üzerinden tam koşu) ve harici katalog doğrulamasıdır; B'nin katkısı **bağımlılık beyanı boşlukları, gradlew/CI kırığı ve SERPAPI en
- - Birleşik düzeltilmiş tabloyla her iki raporun da "critical blocker" listesi §6 P0 ile değiştirilmelidir.

### `docs/reports/RONTGEN_DENETIM_2026-09-23.md` — 1001 satır
**Başlık:** RÖNTGEN DENETİMİ — 2026-09-23 

**Özet:** `/home/user/probe/probe_verifier.py` + `probe_gate.py` ile **gerçek kod yolu** koşturuldu: 1. **Kanıt kapısı yoktu (entailment).** Jürinin bildirdiği `evidence_url` ve alıntı, arama motorunun GERÇEKTEN döndürdüğü kaynak kümesiyle karşılaştırılmıyordu: model URL uydurabiliyor, "kanıt" diye kendi hayalini gösterebiliyordu. → `_audit_vote`: URL kaynak kümesinde değilse `kanit_url_kaynaksiz`, alıntı kaynak metninde geçmiyorsa `kanit_alinti_kaynaksiz` (karşılaştırma `agent_core/services/quote_guard.quote_matches` ile: Türkçe/ASCII katlama, ≥8 karakter).

**Ana bulgular / maddeler:**
- * `tests/unit/test_verifier_entailment_gate.py` — 15 test (uydurma URL, kaynak dışı
- * `tests/unit/test_verifier_jury_panel.py` — 10 test (fake'ler gerçek kaynak kümesi +
- * `tests/unit/test_uncertainty_data_confidence_gate.py` — 5 test.
- * `agent_core/services/security.py`: SSRF/private-IP/link-local engelleri, DNS çözümleme
- * Görüntü indirme hattı (`human_behavior.py`) localhost/private IP'leri reddediyor
- * Açılış bağımlılık kapısı **fail-closed**: sandbox'ta `holehe` kurulu değilken

### `docs/reports/ROUTING_HARDENING_2026-09-04.md` — 30 satır
**Başlık:** PINEAL — Routing Hardening Raporu (2026-09-04) 

**Özet:** Kapsam: routing-doğrulama turunda bulunan O-1..O-4 gap'lerinin KAPATILMASI. Yeni özellik/soyutlama YOK; mevcut tek routing beyni (final_routing_policy ROUTES + llm_gateway zincir motoru) korundu. OpenRouter hub değil.

**Ana bulgular / maddeler:**
- - Hedefli: 170/170 (routing+aspasia suite'leri + 7 yeni hardening testi)
- - FULL: **809 passed / 0 failed / 0 skipped** · ruff: temiz
- - E2E EN ÖNEMLİ TEST (4/4) ve red-kanıtı: **fake transport dikişi** — gerçek
- - CI (GitHub Actions): bu session push'a kapalı → **NOT VERIFIED**; push yeni

### `docs/reports/SON_HUKUM_DENETIM.md` — 114 satır
**Başlık:** Son Hüküm — Birleşik Denetim Kararı 

**Özet:** 1. **JSON repair `except Exception` aşırı genişti** → parse/schema'ya daraltıldı. 2.

### `docs/reports/STEPB_ENTEGRASYON_RAPORU_2026-09-08.md` — 42 satır
**Başlık:** PINEAL — stepB_port.patch ENTEGRASYON RAPORU (2026-09-08) 

**Özet:** `stepB_port.patch` dosyası bu sandbox'ta fiziksel olarak yoktu (yalnız içerik mesajda verildi), bu yüzden `git apply --check` yerine içerik **birebir** elle uygulandı: `llm_gateway.py`'ye `effective_routing_snapshot()` + 2 yardımcı (ekleme noktası `capable_chain` sonu / `__init__` öncesi — patch bağlamıyla **birebir aynıydı, çakışma yok**), `config/agent_tiers.json`, `scripts/generate_routing_shadows.py`, `tests/unit/test_routing_shadows.py` yeni dosya olarak. Söz dizimi/ruff doğrulandı; davranış farkı yok. 1.

**Ana bulgular / maddeler:**
- - **SHA:** `456849826d81e948e3fca5fafb6de785057cd12a` (`45684982`)
- - **Branch:** `arena/01a07f2a-pineal-clean` (HEAD; parent `61830c99`)
- - **Mesaj:** `feat(routing): single-source routing snapshot + generated UI/RUNBOOK shadows`
- - **Kapsam:** 7 dosya (+494/−18). Merge kararı / `decision_config.yaml` / `interpreter_agent.py:37` sabit modeline **dokunulmadı**.

### `docs/reports/SYSTEM_HEALTH_AND_INTEGRATION_MAP.md` — 177 satır
**Başlık:** Pineal — Sistem Sağlığı ve Entegrasyon Haritası 

**Özet:** 1. ~~X alternatif retrieval sözleşmesi~~ → `a002b20`: source attribution + subject matching + evidence formatı uygulandı (sahte profil üretilmiyor; frontend tüketimi ayrı iş). 2.

**Ana bulgular / maddeler:**
- - Sahte resonance vector fallback engeli
- - Empty profile routing engeli
- - OSINT’in çift çalışması engeli
- - Intervention safety bypass engeli
- - 7-pillar exception masking engeli
- - ALF bounded retry

### `docs/reports/TEKLIF_TAM_GUC_2026-10-05.md` — 314 satır
**Başlık:** TEKLİF — BUNLAR EKLENİRSE PINEAL ŞU HALE GELİR 

**Özet:** Bugün Pineal **tek gözlü ve dilsiz**: sensörü Instagram (Playwright), X deliği açık (`XScraperUnsupportedError → awaiting_authorization`), web kazıma tek yerde dar kullanımda, hafızası görev bitince sıfırlanan bir JSON, arayüzdeki holografik ağ **rastgele düğüm üretiyor** (`HolographicResonanceMesh.svelte` → `generateNodes()`), Aspasia'nın sesi yok. Senin üç katmanın + benim üstüne eklediğim 12 parça tam güçle bağlanırsa Pineal şuna dönüşür: Aşağıda bunun parça parça karşılığı var. Senin listen doğru ama **tam güç** için eksik kalan 12 parça:

**Ana bulgular / maddeler:**
- - X URL'si artık `awaiting_authorization`'a düşmez; **gerçek zaman serisi** çıkar.
- - Bu seri doğrudan `FREQUENCY` motorunu ve `timing_forensics.analyze_timing`'i besler (`LilithGrowthAgent` da dahil).
- - Instagram engellendiğinde Playwright tek nokta olmaktan çıkar: instagrapi yedeğe düşer ve sensör **düşmez**.
- - Temiz metin omurgası üretimde: `extract_web_text` = trafilatura → crawl4ai →
- - maigret/holehe artık doğrudan servis değil, **omurga** üzerinden koşuyor ve
- - X deliği kapandı: `platform_registry.scrape_x` → `sensor.x.twscrape`.

### `docs/reports/YILDIZ_DEPO_KARAR_AGACI_2026-10-05.md` — 1075 satır
**Başlık:** PINEAL EPİFİZ — YILDIZ DEPO KARAR AĞACI 

**Özet:** Gerçek anlamda **kod içeri alınacak** depo sayısı: **17 entegrasyon + 51 adaptör = 68**. Geri kalan 257 kayıt, Pineal'i **desen, standart, veri kümesi ve disiplin** olarak besler. Bu oran bilinçlidir: benzersizlik depo sayısından değil, 68 yeteneğin **tek sözleşmeye bağlanmasından** doğar.

**Ana bulgular / maddeler:**
- - Pineal tarafı: `ARCHITECTURE.md`, `README.md`, `docs/reports/EKSIK_YETENEKLER_2026-09-26.md`, `docs/reports/SYSTEM_HEALTH_AND_INTEGRATION_MAP.md`, `agent_core/**`, `backend/api.py`, `config/*`, `requirements*.txt` üzer
- - Depo tarafı: kullanıcının sağladığı 325 kayıt + kısa liste için GitHub API'den **lisans / yıldız / son push** doğrulaması (2026-10-05). Kısa listeye girmeyen depolarda karar, depo adı ve verilen açıklamaya dayanır; **l
- - Hiçbir karar "popüler olduğu için" verilmedi. Her satır 8 kapıdan geçti.
- - Faz 1'e **asgari rıza defteri** (`safety.consent` v0: hedef, amaç, kapsam,
- - Faz 5, tam emniyet çekirdeği (denetim izi, retention, silme kanıtı, ısrar
- - `A†` sınıfı yetenekler (MailAccess, MailFinder, user-scanner, Gokboru) yalnız

### `docs/reports/ZF_ADLI_DENETIM_2026-09-08.md` — 289 satır
**Başlık:** PINEAL — BAĞIMSIZ FORENSIC DENETİM RAPORU (ZERO-KNOWLEDGE / CODE-FIRST) 

**Özet:** Kod seviyesinde **doğrulanmış CRITICAL çalışma-hatası bulunamadı** (fail-closed varsayılanlar, dürüst-eksik davranış, güçlü regresyon koruması). Aşağıdakiler HIGH/MEDIUM adayları; her biri kanıtlıdır: Sınıflandırma merdiveni (kod): **DECLARED** (katalog/ROUTES) → **REGISTERED** (registry) → **AVAILABLE** (ROUTES `verified`+tier) → **ROUTABLE** (transport + policy) → **REACHABLE** (anahtar + kısıt) → **CALLED** (runtime'da fiilen). Önemli kod gerçeği: - Ajan yolu modeli = zincir (ilk model → başarısızsa sıradaki); her model için `agent_route_variants` provider merdiveni (direct free → direct uc

**Ana bulgular / maddeler:**
- - **Denetim tarihi:** 2026-09-08
- - **Denetlenen sürüm:** repo HEAD `2006f696` (branch `arena/01a07f2a-pineal-clean`)
- - **Yöntem:** PASS 1–9; README/raporlar **kanıt değil**; yalnızca kod + config + CI + çalıştırma + test.
- - **Kapsam dışı / UNKNOWN listesi:** rapor sonunda (madde 11). Dolar tahmini üretilmedi; yalnızca kanıtlanabilir oranlar/koşullar verildi.
- - 5 dil/runtime bloğu: Python (FastAPI `backend/api.py`, `agent_core/`), Svelte/TS (`frontend/`), Rust (`rust_core/`), Android/Kotlin (`android/`), Bash/CI.
- - Entrypoint adayları: `backend/api.py` (Dockerfile `CMD uvicorn backend.api:app`), `main.py`, `live_llm_gate.py`, `run_lilith.py`, `scraper.py`, `scripts/*`.

### `docs/reports/pineal_resorgulama_report.md` — 91 satır
**Başlık:** 22 madde × mevcut HEAD yeniden sorgulama 

**Özet:** Bağlantı sorunu değil. Asıl açıklar: **sıralama** (ajan kanıtı olmadan pillar), **DecisionEngine’in pillar’ı yok sayması**, pillar’ın LLM’siz/deterministik kalması. 1.

**Ana bulgular / maddeler:**
- - ALF: `return await self.stealth_fetch(url, profile_id + 1)` — taban durum yok.
- - ReflectionLoop: Q-tablosu okunur, `log_action` Q yazmaz.
- - DP2P: `noise` import opsiyonel.
- - PIL: spaCy yüklenemezse şablon cümle.


## Diğer — 31 belge

### `.jules/bolt.md` — 15 satır
**Başlık:**  

**Özet:** Başlık: | Alt başlıklar: 2024-05-24 - Async HTTP Connection Pooling · 2025-02-23 - Caching Configuration Parsing · 2025-02-24 - Async SQLite Concurrency · 2025-02-24 - Respecting Purity Contracts

### `frontend/README.md` — 47 satır
**Başlık:** Svelte + TS + Vite 

**Özet:** This template should help get you started developing with Svelte and TypeScript in Vite. [VS Code](https://code.visualstudio.com/) + [Svelte](https://marketplace.visualstudio.com/items?itemName=svelte.svelte-vscode). Check out [SvelteKit](https://github.com/sveltejs/kit#readme), which is also powered by Vite.

**Ana bulgular / maddeler:**
- - It brings its own routing solution which might not be preferable for some users.
- - It is first and foremost a framework that just happens to use Vite under the hood, not a Vite app.

### `reports/B0_DESTEK_GUVENLI_DEVAM_KABUL_2026-10-14.md` — 149 satır
**Başlık:** B0 KABUL RAPORU — Kokpit Destek Sağlama ve Güvenli Devam Döngüsü 

**Özet:** B0'ın altı maddesi de dosya/kanıt + çalıştırılmış test ile kapatılmıştır: U2E akışı, 6 negatif senaryo, kalıcılık/tekrar-güvenliği, E-GÖZ3-2 davranışsal testi, state_bridge denetim izi/timeout, UI kablolaması. Tam paketler yeşildir (§4). `POST /api/tasks/{task_id}/resume` → `backend/routes/support.py:274 api_resume_task` (kayıt `backend/api.py:4682 register_support_routes(...)` — route düzeni korunmuş, `api.py:611` tek-satır import; **monolit 6000/6000 ratchet'i korunur, yeni mantık dosyada**).

**Ana bulgular / maddeler:**
- - Başka operatörün görevi → **403** (`test_support_cockpit.py:297`, prod duruşu + iki token)
- - Aynı talebe çift yanıt → **409 ALREADY_RESOLVED** (`:347`)
- - Eşzamanlı iki resume → **409 RESUME_ALREADY_RUNNING** (`:373`)
- - Eksik destekle resume → **409 RESUME_SUPPORT_MISSING** + `missing` (`:413`)
- - Kasa yeniden kilitlendi → destek **423 + talep AÇIK KALIR**, resume **423** (`:433`)
- - Süreç yeniden başlatıldıktan sonra destek sağlama → **çalışır ve biter** (`:478`)

### `reports/KABUL_DENETIMI_DESTEK_AKISI_2026-10-14.md` — 201 satır
**Başlık:** KABUL DENETİMİ — “Kanıtsız başarı yasak; görev sahipsiz bırakılmaz” 

**Özet:** Önceki A-path değişkileri (25 dosya, egress/vault_gate/responsibility/testler) korunmuştur; `backend/api.py` = **5997/6000** (ratchet: `tests/unit/test_api_monolith_ratchet.py`, 6 passed). 1. **Sözleşme/mühür:** `_responsibility_trail` (`task_executor.py:730`) → `agent_core.domain.responsibility.build_trail` → `seal_trail` kuralları; ihlalde **“SORUMLULUK İHLALİ”** ERROR + `integrity.violation`.

**Ana bulgular / maddeler:**
- - **Sahip:** `support_requests[*].owner = agent_name`; koşu sahibi `AgentRun.agent_name`.
- - **Sonraki adım:** `support_requests[*].next_action` (örn. `task_halted_critical`, `rerun_deep_research_or_operator_review`) + mühürde `integrity.next_action`.
- - **Yeniden başlatma koşulu:** operatör düzeltmeyi uygular (yetki/bütçe/süre/güven) ve **önceki TaskStatus JSON'unu** `resume` anahtarıyla geri verir; görev tamamlananlardan devam eder.
- - **Yeni durum eklenmedi.** Mevcut `PipelineStatus` yeterli: `halted_evidence`, `halted_critical`, `timed_out`, `awaiting_authorization` (önceden var). Eklenenler yalnızca **alan**: `support_requests`, `ingested_outputs`
- - **API/UI etkisi:** `backend/api.py`'e hiç dokunulmadı (ratchet 5997/6000); WS `AwaitingHumanEvent` şemada zaten vardı (`telemetry.py:47`) ve emit→WS bağlantısı mevcut. **Doğrulanmalı:** UI tarafının bu olayı görsel ola
- - 1-1, 1-6, 3-2, 2-3 asıl olarak **statik/kayıt sözleşmesi testleriyle** kilitli; 3-2'nin davranışsal ikizi `test_task_lifecycle` bu negatifte **kırılmadı** → **açık kapsam notu:** üretim-ret davranış testi geri-getirile

### `scripts/archive/README.md` — 20 satır
**Başlık:** scripts/archive — tek seferlik prob/deneme scriptleri 

**Özet:** Bu dizindeki scriptler **üretim akışında, CI'da ve test paketinde kullanılmaz** (`pytest.ini: testpaths = tests`). Tarihsel kanıt/deneme amaçlı saklanır: Aktif operasyonel scriptler bir üst dizinde kalır: `run_task.py`, `generate_routing_shadows.py`, `verify_openrouter_catalog.py`, `preflight_9router.py`, `smoke_test_browser.py`, `backup_restore.sh`, `test_disaster_recovery.sh/.ps1`.

### `skills/analyzer_media_frames/SKILL.md` — 56 satır
**Başlık:** analyzer_media_frames 

**Özet:** Video/fotoğrafı kare kare ÖLÇER (fps, çözünürlük, parlaklık, sahne kesmesi); içerik yorumu yapmaz.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `analyzer.media.frames`
- - **Tür:** `analyzer`
- - **Lisans:** OpenCV (Apache-2.0) — harici bağımlılık
- - **Kapılar:** ENABLE_MEDIA_FORENSICS, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/analyzer_media_similarity/SKILL.md` — 56 satır
**Başlık:** analyzer_media_similarity 

**Özet:** Görselin algısal parmak izini (pHash) çıkarır ve yerel indekste en yakın görselleri bulur.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `analyzer.media.similarity`
- - **Tür:** `analyzer`
- - **Lisans:** OpenCV + kendi pHash uygulaması (dahili)
- - **Kapılar:** ENABLE_MEDIA_FORENSICS, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_identity_socid/SKILL.md` — 56 satır
**Başlık:** extractor_identity_socid 

**Özet:** Profil URL'sinden sosyal kimlik alanlarını çıkarır (kanıtlı).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.identity.socid`
- - **Tür:** `extractor`
- - **Lisans:** MIT
- - **Kapılar:** vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_media_transcript/SKILL.md` — 56 satır
**Başlık:** extractor_media_transcript 

**Özet:** Medyanın sesini metne çevirir (yerel whisper CLI/uç). Ses ve metin makineden çıkmaz.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.media.transcript`
- - **Tür:** `extractor`
- - **Lisans:** yerel motor (whisper CLI ya da yerel uç) — kod gömülmez
- - **Kapılar:** ENABLE_MEDIA_FORENSICS, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_text_language/SKILL.md` — 56 satır
**Başlık:** extractor_text_language 

**Özet:** Metnin dilini deterministik ölçer (tr/en/de/es/fr/ru/az); model ve ağ yok, sinyal yoksa etiket uydurmaz.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.text.language`
- - **Tür:** `extractor`
- - **Lisans:** yerel/deterministik (kod içi, harici bağımlılık yok)
- - **Kapılar:** vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_text_translate_local/SKILL.md` — 56 satır
**Başlık:** extractor_text_translate_local 

**Özet:** Metni yerel motorda çevirir (uzak uç reddedilir, uydurma çeviri yok).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.text.translate_local`
- - **Tür:** `extractor`
- - **Lisans:** harici süreç/yerel uç (kod gömülmez)
- - **Kapılar:** ENABLE_LOCAL_TRANSLATE, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_web_crawl4ai/SKILL.md` — 56 satır
**Başlık:** extractor_web_crawl4ai 

**Özet:** JS'li/ağır sayfalar için tarayıcılı kazıma (ikinci kademe).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.web.crawl4ai`
- - **Tür:** `extractor`
- - **Lisans:** Apache-2.0
- - **Kapılar:** vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_web_scrapling/SKILL.md` — 56 satır
**Başlık:** extractor_web_scrapling 

**Özet:** Adaptif kazıma: site değişse de kırılmaz (üçüncü kademe).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.web.scrapling`
- - **Tür:** `extractor`
- - **Lisans:** BSD-3-Clause
- - **Kapılar:** ENABLE_SCRAPLING, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/extractor_web_trafilatura/SKILL.md` — 56 satır
**Başlık:** extractor_web_trafilatura 

**Özet:** Sayfadan çöp etiketleri ayıklayıp temiz metin çıkarır (birincil).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `extractor.web.trafilatura`
- - **Tür:** `extractor`
- - **Lisans:** Apache-2.0
- - **Kapılar:** vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/renderer_report_diagram/SKILL.md` — 56 satır
**Başlık:** renderer_report_diagram 

**Özet:** Kanıt çizelgesini deterministik PNG diyagrama çevirir (tür = renk).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `renderer.report.diagram`
- - **Tür:** `renderer`
- - **Lisans:** dahili (reportlab/Pillow/ffmpeg harici araçlar)
- - **Kapılar:** ENABLE_REPORT_FACTORY, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/renderer_report_pdf/SKILL.md` — 56 satır
**Başlık:** renderer_report_pdf 

**Özet:** Kanıt çizelgesinden PDF rapor üretir (hash'li, kanıt bağlantılı).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `renderer.report.pdf`
- - **Tür:** `renderer`
- - **Lisans:** dahili (reportlab/Pillow/ffmpeg harici araçlar)
- - **Kapılar:** ENABLE_REPORT_FACTORY, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/renderer_report_video/SKILL.md` — 56 satır
**Başlık:** renderer_report_video 

**Özet:** Kanıt çizelgesinden kısa video özet üretir (kareler Pillow, kodlama ffmpeg).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `renderer.report.video`
- - **Tür:** `renderer`
- - **Lisans:** dahili (reportlab/Pillow/ffmpeg harici araçlar)
- - **Kapılar:** ENABLE_REPORT_FACTORY, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_company_harvester/SKILL.md` — 56 satır
**Başlık:** sensor_company_harvester 

**Özet:** Kurum/alan adı hedefi: arama motorlarından e-posta, alt alan adı, IP ve URL toplar (theHarvester). Araç yoksa dürüstçe kapalıdır.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.company.harvester`
- - **Tür:** `sensor`
- - **Lisans:** GPL-2.0 (harici CLI — kod gömülmez)
- - **Kapılar:** ENABLE_COMPANY_TARGETING, rate, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_company_people/SKILL.md` — 56 satır
**Başlık:** sensor_company_people 

**Özet:** Kurumun kendi sayfalarında YAYINLADIĞI kişi künyesi (schema.org/Person: ad + rol) ve herkese açık iletişim adresleri. Kişi avı değildir.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.company.people`
- - **Tür:** `sensor`
- - **Lisans:** dahili (yalnız HTTP GET + stdlib ayrıştırma)
- - **Kapılar:** ENABLE_COMPANY_TARGETING, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_company_seo/SKILL.md` — 56 satır
**Başlık:** sensor_company_seo 

**Özet:** Kurumun açık izlenebilirlik verisi: robots.txt, sitemap.xml, ana sayfa meta/dil/canonical, security.txt ve güvenlik başlıkları. Puan uydurulmaz.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.company.seo`
- - **Tür:** `sensor`
- - **Lisans:** dahili (yalnız HTTP GET + stdlib ayrıştırma)
- - **Kapılar:** ENABLE_COMPANY_TARGETING, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_identity_holehe/SKILL.md` — 56 satır
**Başlık:** sensor_identity_holehe 

**Özet:** E-postanın hangi platformlarda kayıtlı olduğunu tarar.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.identity.holehe`
- - **Tür:** `sensor`
- - **Lisans:** GPL-3.0 (harici süreç/bağımlılık — kod gömülmez)
- - **Kapılar:** ENABLE_HOLEHE, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_identity_maigret/SKILL.md` — 56 satır
**Başlık:** sensor_identity_maigret 

**Özet:** Kullanıcı adının binlerce sitedeki varlığını tarar (kanıtlı); liste PINEAL_MAIGRET_DB ile tazelenir ve kaynak raporlanır (A8).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.identity.maigret`
- - **Tür:** `sensor`
- - **Lisans:** MIT
- - **Kapılar:** ENABLE_MAIGRET, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_ig_instagrapi/SKILL.md` — 56 satır
**Başlık:** sensor_ig_instagrapi 

**Özet:** Instagram ikinci kaynak: Playwright engellenirse sensör düşmez.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.ig.instagrapi`
- - **Tür:** `sensor`
- - **Lisans:** NOASSERTION (yalnız ikinci kaynak; hukuki inceleme notu)
- - **Kapılar:** ENABLE_IG_SECONDARY, rate, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_media_fetch/SKILL.md` — 56 satır
**Başlık:** sensor_media_fetch 

**Özet:** Video/foto indirir (platform linkleri yt-dlp, doğrudan bağlantılar httpx) ve sha256 ile mühürler.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.media.fetch`
- - **Tür:** `sensor`
- - **Lisans:** yt-dlp (Unlicense) · httpx (BSD) — harici araç, kod gömülmez
- - **Kapılar:** ENABLE_MEDIA_FORENSICS, rate, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_search_searxng/SKILL.md` — 56 satır
**Başlık:** sensor_search_searxng 

**Özet:** Anahtarsız metasearch; arama maliyetini ve sağlayıcı bağımlılığını kırar.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.search.searxng`
- - **Tür:** `sensor`
- - **Lisans:** AGPL-3.0 (ayrı servis — kod gömülmez, HTTP ile çağrılır)
- - **Kapılar:** ENABLE_SEARXNG, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_web_agent_reach/SKILL.md` — 56 satır
**Başlık:** sensor_web_agent_reach 

**Özet:** Twitter/Reddit/YouTube/GitHub okuma — sıfır API ücreti (harici CLI).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.web.agent_reach`
- - **Tür:** `extractor`
- - **Lisans:** MIT (harici CLI süreci)
- - **Kapılar:** ENABLE_AGENT_REACH, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/sensor_x_twscrape/SKILL.md` — 56 satır
**Başlık:** sensor_x_twscrape 

**Özet:** X/Twitter gönderi akışı (gerçek zaman serisi; Frequency motorunu besler).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `sensor.x.twscrape`
- - **Tür:** `sensor`
- - **Lisans:** MIT
- - **Kapılar:** ENABLE_X_SENSOR, rate, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/verifier_jury_local/SKILL.md` — 56 satır
**Başlık:** verifier_jury_local 

**Özet:** Aynı iddia ve kanıtı birden çok YEREL modelde bağımsız oylar; oybirliği ya da yeter sayılı çoğunluk karar olur. Uzak uç reddedilir; motor yoksa karar UYDURULMAZ.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `verifier.jury.local`
- - **Tür:** `verifier`
- - **Lisans:** yerel uç (ollama/llama.cpp/vLLM); kod gömülmez
- - **Kapılar:** ENABLE_LOCAL_JURY, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/voice_report_script/SKILL.md` — 56 satır
**Başlık:** voice_report_script 

**Özet:** Görev sonucunu sesli okunabilir Türkçe rapora çevirir.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `voice.report.script`
- - **Tür:** `renderer`
- - **Lisans:** dahili (deterministik metin kurucu)
- - **Kapılar:** vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/voice_stt_local/SKILL.md` — 56 satır
**Başlık:** voice_stt_local 

**Özet:** Yerel konuşma tanıma (whisper CLI veya localhost STT ucu).

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `voice.stt.local`
- - **Tür:** `extractor`
- - **Lisans:** harici süreç/yerel uç (kod gömülmez)
- - **Kapılar:** ENABLE_LOCAL_STT, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.

### `skills/voice_tts_local/SKILL.md` — 56 satır
**Başlık:** voice_tts_local 

**Özet:** Yerel TTS (piper CLI veya localhost TTS ucu) — ses makineden çıkmaz.

**Ana bulgular / maddeler:**
- - **Yetenek kimliği:** `voice.tts.local`
- - **Tür:** `renderer`
- - **Lisans:** harici süreç/yerel uç (kod gömülmez)
- - **Kapılar:** ENABLE_LOCAL_TTS, vault
- - Kapılar kapalıysa (kasa kilitli, `ENABLE_*` kapalı, hız sınırı dolu) yetenek **koşmaz**; çağrı `isError: true` ve makine-okunur sebeple döner.
- - Kanıt üretilmediyse sonuç başarı sayılmaz: `structuredContent.ok` yalnız kanıt varsa `true` olur.
