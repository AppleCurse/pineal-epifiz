# EŞİKLER VE SİHİRLİ SAYILAR (dosya:satır ile)

Toplam **2328** bulgu, **319** dosyada. Tarama kuralı: karşılaştırma operatörlü sayılar, parametre varsayılanları ve BÜYÜK_HARF sabitleri. 0/1/2 gibi anlamsız sabitler ayıklandı; `status_code != 200`, `hour <= 23` gibi satırlar eşik değil bağlam sabitidir, yine de ölçüldüğü gibi listelenir.

## En yoğun dosyalar

| Dosya | Bulgu |
|---|---|
| `backend/api.py` | 127 |
| `tests/unit/test_gorev2_depth_engine.py` | 57 |
| `tests/unit/test_pillar_evidence_adapter.py` | 39 |
| `agent_core/services/unified_router.py` | 36 |
| `agent_core/services/llm_gateway.py` | 33 |
| `tests/integration/test_support_cockpit.py` | 31 |
| `tests/unit/test_uncertainty_evidence_quality.py` | 31 |
| `tests/unit/test_lilith_growth.py` | 30 |
| `tests/unit/test_maigret_db_refresh.py` | 30 |
| `tests/unit/test_unified_router.py` | 28 |
| `tests/unit/test_uncertainty_b2_regressions.py` | 26 |
| `agent_core/agents/lilith_growth.py` | 24 |
| `backend/routes/support.py` | 24 |
| `tests/unit/test_depth_verification_trace.py` | 24 |
| `tests/unit/test_gorev2_artiklar.py` | 24 |
| `tests/unit/test_holehe_scanner.py` | 24 |
| `agent_core/agents/human_behavior.py` | 23 |
| `tests/audit/test_production_audit_findings.py` | 23 |
| `agent_core/services/media_forensics.py` | 21 |
| `tests/integration/test_task_executor_flow.py` | 21 |

## Kritik eşikler (karar eşikleri — config/decision_config.yaml ve kod sabitleri)

| Eşik | Değer | Kaynak |
|---|---|---|
| `min_data_score` | `0.60` | config/decision_config.yaml |
| `min_llm_confidence` | `0.65` | config/decision_config.yaml |
| `agent_timeout_seconds` | `120` | config/decision_config.yaml |
| `timeout_seconds` | `60` | config/decision_config.yaml |
| `timeout_seconds` | `150` | config/decision_config.yaml |
| `min_data_score` | `0.57` | config/decision_config.yaml |
| `min_llm_confidence` | `0.70` | config/decision_config.yaml |
| `core_passions` | `0.30` | config/decision_config.yaml |
| `energizing_topics` | `0.25` | config/decision_config.yaml |
| `flow_triggers` | `0.20` | config/decision_config.yaml |
| `evidence_quotes` | `0.15` | config/decision_config.yaml |
| `sentiment_polarity` | `0.10` | config/decision_config.yaml |
| `empty_list_penalty` | `0.12` | config/decision_config.yaml |
| `min_llm_confidence` | `0.65` | config/decision_config.yaml |
| `min_data_score` | `0.60` | config/decision_config.yaml |
| `user_core_frequency` | `0.3` | config/decision_config.yaml |
| `surface_persona` | `0.3` | config/decision_config.yaml |
| `alignment_score` | `0.2` | config/decision_config.yaml |
| `authentic_anchors` | `0.2` | config/decision_config.yaml |
| `empty_list_penalty` | `0.08` | config/decision_config.yaml |
| `min_data_score` | `0.55` | config/decision_config.yaml |
| `min_llm_confidence` | `0.60` | config/decision_config.yaml |
| `min_data_score` | `0.52` | config/decision_config.yaml |
| `min_llm_confidence` | `0.60` | config/decision_config.yaml |
| `dark_profile` | `0.30` | config/decision_config.yaml |
| `strategy` | `0.25` | config/decision_config.yaml |
| `nlp_sequence` | `0.25` | config/decision_config.yaml |
| `message` | `0.20` | config/decision_config.yaml |
| `empty_list_penalty` | `0.08` | config/decision_config.yaml |
| `min_data_score` | `0.40` | config/decision_config.yaml |
| `min_llm_confidence` | `0.55` | config/decision_config.yaml |
| `associated_platforms` | `0.30` | config/decision_config.yaml |
| `digital_footprint_score` | `0.25` | config/decision_config.yaml |
| `connected_emails` | `0.20` | config/decision_config.yaml |
| `connected_phones` | `0.15` | config/decision_config.yaml |
| `dark_web_hits` | `0.10` | config/decision_config.yaml |
| `empty_list_penalty` | `0.05` | config/decision_config.yaml |
| hız sınırı `api` | 300/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `initiate` | 5/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `aspasia` | 20/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `experimental` | 10/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `openai` | 60/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `speech` | 30/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `media` | 6/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `report` | 10/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `company` | 8/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `jury` | 6/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `language` | 60/60 sn | backend/api.py (RATE_LIMITS) |
| hız sınırı `ws` | 30/60 sn | backend/api.py (RATE_LIMITS) |
| rezonans reddi | `< 0.70` | agent_core/task_executor.py (halted_frequency) |

### `agent_core/agents/authenticity_auditor.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 102 | `temperature=0.2,` | parametre |

### `agent_core/agents/autonomous_verifier.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `→ `status=VERIFIED, confidence=0.70`; UncertaintyEngine bunu` | parametre |
| 84 | `MIN_CLAIM_SUPPORT_RATIO = 0.5` | parametre |
| 84 | `MIN_CLAIM_SUPPORT_RATIO = 0.5` | sabit |
| 827 | `if total == 0:` | karşılaştırma |
| 848 | `elif falsified > 0 and confirmed > 0:` | karşılaştırma |
| 850 | `elif confirmed > 0 and falsified == 0 and unknown == 0:` | karşılaştırma |
| 852 | `elif confirmed > 0 and falsified == 0:` | karşılaştırma |
| 875 | `if conclusive == 0:` | karşılaştırma |
| 923 | `elif falsified > 0 and confirmed > 0:` | karşılaştırma |
| 925 | `elif confirmed > 0 and falsified == 0 and unknown == 0:` | karşılaştırma |
| 927 | `elif confirmed > 0 and falsified == 0:` | karşılaştırma |
| 931 | `if conclusive == 0:` | karşılaştırma |

### `agent_core/agents/human_behavior.py` — 23 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 118 | `if response.status_code != 200:` | karşılaştırma |
| 157 | `timeout=httpx.Timeout(10.0, connect=5.0),` | parametre |
| 242 | `if (isinstance(getattr(result, "achilles_score", None), (int, float)) and result.achilles_score > 0.0)` | karşılaştırma |
| 286 | `if img is None or img.size == 0 or len(img.shape) < 2:` | karşılaştırma |
| 300 | `faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(20, 20))` | parametre |
| 320 | `if shoulder_roi is not None and shoulder_roi.size > 0:` | karşılaştırma |
| 323 | `if tension_level > 50:` | karşılaştırma |
| 330 | `psychological_weight=0.7,` | parametre |
| 336 | `if laplacian_var < 100:` | karşılaştırma |
| 340 | `confidence=0.8,` | parametre |
| 343 | `psychological_weight=0.6,` | parametre |
| 362 | `confidence=0.75,` | parametre |
| 365 | `psychological_weight=0.5,` | parametre |
| 372 | `if passive_count > 3:` | karşılaştırma |
| 376 | `confidence=0.6,` | parametre |
| 379 | `psychological_weight=0.3,` | parametre |
| 392 | `confidence=0.85,` | parametre |
| 395 | `psychological_weight=0.7,` | parametre |
| 415 | `if 0 <= hour <= 23:` | karşılaştırma |
| 417 | `if hour >= 23 or hour <= 4:` | karşılaştırma |
| 422 | `if total_valid > 0:` | karşılaştırma |
| 424 | `if ratio > 0.3:` | karşılaştırma |
| 431 | `psychological_weight=0.75,` | parametre |

### `agent_core/agents/lilith_growth.py` — 24 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 102 | `dopamine_potential: float = 0.85` | parametre |
| 103 | `serotonin_status_currency: float = 0.80` | parametre |
| 104 | `cortisol_urgency: float = 0.60` | parametre |
| 105 | `oxytocin_affinity: float = 0.70` | parametre |
| 122 | `pattern_interrupt_index: float = 0.90` | parametre |
| 123 | `cognitive_dissonance_score: float = 0.85` | parametre |
| 124 | `viral_coefficient_score: float = 8.4  # 0.0 - 10.0` | parametre |
| 212 | `def __init__(self, timeout: float = 7.0):` | parametre |
| 218 | `temperature: float = 0.7,` | parametre |
| 241 | `timeout: float = 45.0,` | parametre |
| 251 | `temperature: float = 0.7,` | parametre |
| 314 | `dopamine: Any = 0.85,` | parametre |
| 315 | `serotonin: Any = 0.80,` | parametre |
| 316 | `cortisol: Any = 0.60,` | parametre |
| 317 | `oxytocin: Any = 0.70,` | parametre |
| 318 | `cognitive_friction: Any = 0.25,` | parametre |
| 377 | `width: int = 1080,` | parametre |
| 378 | `height: int = 1080,` | parametre |
| 490 | `temperature=0.7,` | parametre |
| 559 | `confidence=0.5,` | parametre |
| 563 | `dopamine_potential=0.80,` | parametre |
| 564 | `serotonin_status_currency=0.75,` | parametre |
| 565 | `cortisol_urgency=0.60,` | parametre |
| 566 | `oxytocin_affinity=0.65,` | parametre |

### `agent_core/agents/mirror_truth.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 100 | `and result.alignment_score > 0.0` | karşılaştırma |
| 104 | `has_valid_evidence = has_reflection and (conf > 0.0)` | karşılaştırma |

### `agent_core/agents/osint_investigator.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 154 | `if scan.available and scan.scanned_count and scan.error_count == 0:` | karşılaştırma |
| 212 | `if scan.available and scan.scanned_count and scan.error_count == 0:` | karşılaştırma |
| 234 | `"Accept-Language": "en-US,en;q=0.9",` | parametre |
| 316 | `async with session.get(f"https://api.osint.industries/v1/user/{clean_username}", headers=headers, timeout=15) as resp:` | parametre |
| 317 | `if resp.status == 200:` | karşılaştırma |
| 332 | `error_code = "AUTH_FAILED" if resp.status in (401, 403) else "RATE_LIMITED" if resp.status == 429 else "PROVIDER_ERROR"` | karşılaştırma |

### `agent_core/agents/pattern_interrupt.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 181 | `compliance_score=100.0,` | parametre |

### `agent_core/agents/resonance_calculator.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `_DEPTH_MISMATCH_THRESHOLD = 0.35   # /Δdepth/ bunu aşarsa DERINLIK_UYUSMAZLIĞI` | parametre |
| 45 | `_ENERGY_LOW = 0.3                  # kullanıcı enerjisi bunun altındayken...` | parametre |
| 46 | `_ENERGY_HIGH = 0.8                 # ...hedef bunun üstündeyse ENERJI_UYUSMAZLIĞI` | parametre |
| 49 | `_VECTOR_ALIGNMENT_FLOOR = 0.5` | parametre |
| 226 | `if magnitude1 == 0 or magnitude2 == 0:` | karşılaştırma |

### `agent_core/agents/resonance_synthesizer.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 142 | `temperature=0.3,` | parametre |
| 150 | `has_valid_evidence = has_bridge and (conf > 0.0)` | karşılaştırma |

### `agent_core/agents/target_psyche_profiler.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 110 | `temperature=0.3,` | parametre |
| 118 | `has_valid_evidence = has_passions and (conf > 0.0)` | karşılaştırma |
| 195 | `temperature=0.3,` | parametre |
| 208 | `has_valid_evidence = has_frictions and (conf > 0.0)` | karşılaştırma |
| 276 | `temperature=0.3,` | parametre |
| 284 | `has_valid_evidence = has_style and (conf > 0.0)` | karşılaştırma |

### `agent_core/aspasia/aspasia_chief.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 264 | `temperature=0.4,` | parametre |
| 276 | `temperature=0.4,` | parametre |

### `agent_core/aspasia/interface.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 105 | `or (route.pricing["in"] == 0 and route.pricing["out"] == 0)` | karşılaştırma |
| 162 | `def __init__(self, gateway: Any, limit: int = 40):` | parametre |
| 397 | `self._audit: deque[Dict[str, Any]] = deque(maxlen=64)` | parametre |
| 635 | `_MAX_INSPECT = 25` | parametre |
| 793 | `cooling = {k: v for k, v in ph().items() if v and v > 0}` | karşılaştırma |

### `agent_core/capabilities/adapters_company.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 43 | `BUCKET_LIMIT = 25` | parametre |
| 43 | `BUCKET_LIMIT = 25` | sabit |
| 65 | `timeout_seconds = 240.0` | parametre |
| 166 | `timeout_seconds = 120.0` | parametre |
| 268 | `timeout_seconds = 120.0` | parametre |

### `agent_core/capabilities/adapters_jury.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `timeout_seconds = 180.0` | parametre |
| 55 | `timeout = 60.0` | parametre |

### `agent_core/capabilities/adapters_language.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 36 | `_MAX_EVIDENCE_CHARS = 500` | parametre |
| 47 | `timeout_seconds = 5.0` | parametre |
| 106 | `timeout_seconds = 35.0` | parametre |

### `agent_core/capabilities/adapters_media.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 39 | `MAX_LINES = 25` | parametre |
| 39 | `MAX_LINES = 25` | sabit |
| 85 | `timeout_seconds = 300.0` | parametre |
| 138 | `timeout_seconds = 300.0` | parametre |
| 226 | `timeout_seconds = 900.0` | parametre |
| 284 | `timeout_seconds = 120.0` | parametre |

### `agent_core/capabilities/adapters_osint.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 53 | `timeout_seconds = 75.0` | parametre |
| 109 | `if not items and notes["scanned_count"] and notes["error_count"] == 0:` | karşılaştırma |
| 142 | `timeout_seconds = 150.0` | parametre |
| 188 | `if not items and notes["scanned_count"] and notes["error_count"] == 0:` | karşılaştırma |
| 221 | `timeout_seconds = 20.0` | parametre |

### `agent_core/capabilities/adapters_report.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `MAX_SCRIPT_CHARS = 1200` | parametre |
| 37 | `MAX_SCRIPT_CHARS = 1200` | sabit |
| 186 | `timeout_seconds = 30.0` | parametre |

### `agent_core/capabilities/adapters_report_factory.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 58 | `timeout_seconds = 300.0` | parametre |

### `agent_core/capabilities/adapters_sensors.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 50 | `def _truncate(value: str, limit: int = 480) -> str:` | parametre |
| 67 | `timeout_seconds = 60.0` | parametre |
| 182 | `timeout_seconds = 90.0` | parametre |
| 311 | `timeout_seconds = 60.0` | parametre |
| 351 | `if proc.returncode != 0:` | karşılaştırma |
| 393 | `timeout_seconds = 30.0` | parametre |
| 426 | `if response.status_code != 200:` | karşılaştırma |

### `agent_core/capabilities/adapters_voice.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 46 | `MAX_TEXT_CHARS = 2000` | parametre |
| 46 | `MAX_TEXT_CHARS = 2000` | sabit |
| 70 | `position = 12` | parametre |
| 121 | `timeout_seconds = 60.0` | parametre |
| 245 | `if proc.returncode != 0:` | karşılaştırma |
| 248 | `if not out_path.exists() or out_path.stat().st_size == 0:` | karşılaştırma |
| 271 | `if response.status_code >= 400:` | karşılaştırma |
| 283 | `MAX_AUDIO_BYTES = 8 * 1024 * 1024` | parametre |
| 283 | `MAX_AUDIO_BYTES = 8 * 1024 * 1024` | sabit |
| 311 | `timeout_seconds = 120.0` | parametre |
| 429 | `if proc.returncode != 0:` | karşılaştırma |
| 454 | `if response.status_code >= 400:` | karşılaştırma |

### `agent_core/capabilities/adapters_web.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 57 | `DEFAULT_MAX_CHARS = 20_000` | parametre |
| 57 | `DEFAULT_MAX_CHARS = 20_000` | sabit |
| 109 | `timeout_seconds = 30.0` | parametre |
| 204 | `timeout_seconds = 60.0` | parametre |
| 280 | `timeout_seconds = 45.0` | parametre |
| 300 | `from scrapling.fetchers import Fetcher  # scrapling >= 0.9` | karşılaştırma |

### `agent_core/capabilities/base.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 193 | `timeout_seconds: float = 30.0` | parametre |

### `agent_core/chat/dialogue_manager.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 39 | `_DEFAULT_SESSION_TTL_SECONDS = 1800.0` | parametre |
| 40 | `_DEFAULT_MAX_SESSIONS = 512` | parametre |
| 74 | `if overflow > 0:` | karşılaştırma |

### `agent_core/config_loader.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 24 | `min_data_score: float = 0.60` | parametre |
| 25 | `min_llm_confidence: float = 0.65` | parametre |
| 28 | `empty_list_penalty: float = 0.1` | parametre |

### `agent_core/domain/memory_models.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 130 | `required_threshold: float = 0.70` | parametre |

### `agent_core/engines/frequency_engine.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 65 | `def __init__(self, bucket_hours=24, smooth_window=3, min_samples=4, flow_z=0.75, collapse_z=-0.75):` | parametre |
| 116 | `z = (smooth - mu) / sd if sd > 1e-9 else np.zeros_like(smooth)` | karşılaştırma |
| 153 | `night = sum(ts.hour >= 23 or ts.hour < 5 for ts, *_ in ev) / len(ev)` | karşılaştırma |

### `agent_core/engines/gravity_engine.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `if mass < 0.08 and pull < 1.3:` | karşılaştırma |
| 64 | `is_black_hole=pull >= self.black_hole_pull and mass >= 0.05,` | karşılaştırma |

### `agent_core/engines/key_engine.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `if freq.night_energy_share > 0.35` | karşılaştırma |
| 24 | `if freq.night_energy_share < 0.1` | karşılaştırma |
| 79 | `status=EvidenceStatus.OBSERVED if conf >= 0.5 else EvidenceStatus.WEAK,` | karşılaştırma |
| 86 | `timing_window="Akşam/gece saatleri." if freq.night_energy_share > 0.35 else "Gündüz saatleri.",` | karşılaştırma |

### `agent_core/engines/pulse_engine.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `def __init__(self, min_posts=5):` | parametre |
| 51 | `rh = "erratic" if vol > 0.85 else "variable" if vol > 0.55 else "steady" if vol > 0.3 else "mechanical"` | karşılaştırma |

### `agent_core/engines/seismos_engine.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `min_posts=5,` | parametre |
| 43 | `min_silence_hours=72,` | parametre |
| 44 | `tone_delta_threshold=0.55,` | parametre |

### `agent_core/engines/spectrum.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `MIN_SAMPLES = 8` | parametre |
| 41 | `MIN_SAMPLES = 8` | sabit |
| 60 | `bucket_hours: int = 24` | parametre |
| 76 | `bucket_hours: int = 24,` | parametre |
| 118 | `if usable.size == 0 or float(usable.sum()) <= 1e-12:` | karşılaştırma |
| 148 | `related = [p for p in all_peaks if p.power_share >= 0.5 * max_power]` | karşılaştırma |

### `agent_core/engines/strata_engine.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 16 | `def __init__(self, min_posts=12, extinction_threshold=0.05):` | parametre |
| 67 | `if ep > 0.35 and lp < self.extinction_threshold:` | karşılaştırma |

### `agent_core/engines/void_engine.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 34 | `def __init__(self, min_tokens=40, void_threshold=0.22, strong_void=0.4, interest_boost=0.2):` | parametre |
| 59 | `score = float(np.clip(delta / max(expected, 1e-6), 0, 1)) if delta > 0 else 0` | karşılaştırma |
| 60 | `if score < 0.12:` | karşılaştırma |
| 64 | `if score >= self.strong_void and (interest or expected >= 0.2)` | karşılaştırma |

### `agent_core/mcp/protocol.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 67 | `MAX_LINE_BYTES = 8 * 1024 * 1024` | parametre |
| 67 | `MAX_LINE_BYTES = 8 * 1024 * 1024` | sabit |
| 78 | `PARSE_ERROR = -32700` | parametre |
| 79 | `INVALID_REQUEST = -32600` | parametre |
| 80 | `METHOD_NOT_FOUND = -32601` | parametre |
| 81 | `INVALID_PARAMS = -32602` | parametre |
| 82 | `INTERNAL_ERROR = -32603` | parametre |
| 84 | `SERVER_NOT_INITIALIZED = -32002` | parametre |
| 86 | `UNSUPPORTED_PROTOCOL_VERSION = -32022` | parametre |

### `agent_core/mcp/results.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `_MAX_TEXT_CHARS = 4000` | parametre |
| 36 | `_MAX_EVIDENCE_ITEMS = 50` | parametre |

### `agent_core/mcp/state_bridge.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 56 | `_VAULT_CACHE_SECONDS = 5.0` | parametre |
| 90 | `timeout: float = 2.0,` | parametre |
| 150 | `def __init__(self, limit: int = 20, window_seconds: float = 60.0) -> None:` | parametre |
| 172 | `limit = 20` | parametre |
| 176 | `window = 60.0` | parametre |

### `agent_core/nlp/dark_nlp.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 75 | `if i > 0:` | karşılaştırma |

### `agent_core/psychology/dark_triad.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `DEPTH_MIRRORING_REACTION = 0.40` | parametre |
| 35 | `DEPTH_MIRRORING_REACTION = 0.40` | sabit |
| 36 | `DEPTH_ALLIANCE_REPETITION = 0.40` | parametre |
| 36 | `DEPTH_ALLIANCE_REPETITION = 0.40` | sabit |
| 60 | `if profile.narcissism > 0.7:` | karşılaştırma |
| 62 | `elif profile.machiavellianism > 0.6:` | karşılaştırma |
| 64 | `elif profile.psychopathy > 0.5:` | karşılaştırma |
| 106 | `(isinstance(n_rup, int) and not isinstance(n_rup, bool) and n_rup >= 1)` | karşılaştırma |

### `agent_core/safety/minor_gate.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `MINOR_AGE_LIMIT = 18` | parametre |
| 55 | `MINOR_AGE_LIMIT = 18` | sabit |
| 61 | `MIN_REASON_CHARS = 25` | parametre |
| 61 | `MIN_REASON_CHARS = 25` | sabit |

### `agent_core/scraper/instagram_ghost.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 54 | `caption: Optional[str] = Field(None, max_length=2200)` | parametre |
| 266 | `if depth > 14 or len(found) >= 24:` | karşılaştırma |
| 426 | `_PAIR_WINDOW = 5000` | parametre |
| 443 | `if _best_idx >= 0:` | karşılaştırma |
| 658 | `if limit <= 0 or not posts:` | karşılaştırma |
| 682 | `wait_until="domcontentloaded", timeout=15000,` | parametre |
| 746 | `await playwright_page.goto(target_url, wait_until="domcontentloaded", timeout=15000)` | parametre |
| 792 | `if total == 0:` | karşılaştırma |

### `agent_core/services/browser_session.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `VIEWPORT_W = 800` | parametre |
| 28 | `VIEWPORT_W = 800` | sabit |
| 29 | `VIEWPORT_H = 600` | parametre |
| 29 | `VIEWPORT_H = 600` | sabit |
| 127 | `await self._page.goto(target, wait_until="domcontentloaded", timeout=30_000)` | parametre |
| 219 | `await page.keyboard.type(text, delay=15)` | parametre |
| 235 | `await page.go_back(wait_until="domcontentloaded", timeout=15_000)` | parametre |

### `agent_core/services/canonical_memory.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 98 | `if entry.waiters == 0 and self._locks.get(task_id) is entry:` | karşılaştırma |

### `agent_core/services/company_recon.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 64 | `HARVESTER_TIMEOUT = 240.0` | parametre |
| 64 | `HARVESTER_TIMEOUT = 240.0` | sabit |
| 65 | `HTTP_TIMEOUT = 20.0` | parametre |
| 65 | `HTTP_TIMEOUT = 20.0` | sabit |
| 66 | `MAX_TEXT = 400` | parametre |
| 66 | `MAX_TEXT = 400` | sabit |
| 342 | `return self.status == 404` | karşılaştırma |
| 449 | `if status and 200 <= status < 400:` | karşılaştırma |
| 471 | `if status == 200:` | karşılaştırma |
| 484 | `if status == 200:` | karşılaştırma |
| 492 | `if status == 200:` | karşılaştırma |
| 603 | `max_pages: int = 5,` | parametre |
| 642 | `if status and 200 <= status < 400:` | karşılaştırma |

### `agent_core/services/crawl_enricher.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 17 | `psutil notu: crawl4ai `psutil>=6.1.1` beyan eder; open-interpreter` | karşılaştırma |
| 18 | ``psutil<6.0.0` beyan eder. Gerçek kullanım (kaynak okuması + çalışma zamanı` | karşılaştırma |
| 21 | `Bu yüzden `psutil<6` sabitlenir (open-interpreter'ın beyanına saygı).` | karşılaştırma |
| 34 | `DEFAULT_MAX_CHARS = 8000` | parametre |
| 34 | `DEFAULT_MAX_CHARS = 8000` | sabit |
| 35 | `MAX_MAX_CHARS = 50000` | parametre |
| 35 | `MAX_MAX_CHARS = 50000` | sabit |
| 36 | `DEFAULT_TIMEOUT = 20` | parametre |
| 36 | `DEFAULT_TIMEOUT = 20` | sabit |
| 37 | `MAX_TIMEOUT = 120` | parametre |
| 37 | `MAX_TIMEOUT = 120` | sabit |
| 39 | `MAX_RESEARCH_LIMIT = 5` | parametre |
| 39 | `MAX_RESEARCH_LIMIT = 5` | sabit |

### `agent_core/services/final_routing_policy.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `return self.tier == "free" and self.input_per_million_usd == 0.0 and self.output_per_million_usd == 0.0` | karşılaştırma |
| 318 | `assert QUOTAS["groq"]["rpm"] == 30 and QUOTAS["groq"]["rpd"] == 14400` | karşılaştırma |
| 320 | `assert QUOTAS["cerebras"]["rpm"] == 5 and QUOTAS["cerebras"]["tpm"] == 30000 and QUOTAS["cerebras"]["tpd"] == 1_000_000` | karşılaştırma |

### `agent_core/services/follower_audit.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `if follower_count <= 0:` | karşılaştırma |
| 63 | `data_completeness=0.3` | parametre |
| 76 | `if follower_count < 5000:` | karşılaştırma |
| 78 | `min_healthy = 1.5` | parametre |
| 79 | `elif follower_count < 25000:` | karşılaştırma |
| 81 | `min_healthy = 0.8` | parametre |
| 82 | `elif follower_count < 100000:` | karşılaştırma |
| 84 | `min_healthy = 0.5` | parametre |
| 87 | `min_healthy = 0.3` | parametre |

### `agent_core/services/graph_builder.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 27 | `_MAX_NODES = 60` | parametre |

### `agent_core/services/hindsight_memory.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 40 | `EMBEDDING_DIM = 384  # all-MiniLM-L6-v2 çıktı boyutu` | parametre |
| 40 | `EMBEDDING_DIM = 384  # all-MiniLM-L6-v2 çıktı boyutu` | sabit |
| 58 | `dedup_threshold: float = 0.95,` | parametre |
| 79 | `return sqlite3.connect(self.db_path, timeout=5)` | parametre |
| 264 | `top_k: int = 5,` | parametre |

### `agent_core/services/holehe_scanner.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 38 | `DEFAULT_TOTAL_TIMEOUT = 120` | parametre |
| 38 | `DEFAULT_TOTAL_TIMEOUT = 120` | sabit |
| 39 | `DEFAULT_CONCURRENCY = 20` | parametre |
| 39 | `DEFAULT_CONCURRENCY = 20` | sabit |
| 40 | `MAX_MODULES_LIMIT = 300` | parametre |
| 40 | `MAX_MODULES_LIMIT = 300` | sabit |
| 42 | `MAX_EMAIL_LEN = 254` | parametre |
| 42 | `MAX_EMAIL_LEN = 254` | sabit |
| 248 | `elif scanned > 0 and errors == 0:` | karşılaştırma |

### `agent_core/services/jury_consensus.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 157 | `if total == 0:` | karşılaştırma |
| 171 | `single_seat_claims=sum(1 for r in reports if r.seats == 1),` | karşılaştırma |

### `agent_core/services/language.py` — 17 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `MIN_LETTERS = 12` | parametre |
| 37 | `MIN_LETTERS = 12` | sabit |
| 40 | `SCRIPT_DOMINANCE = 0.60` | parametre |
| 40 | `SCRIPT_DOMINANCE = 0.60` | sabit |
| 130 | `MIN_SIGNAL = 0.012` | parametre |
| 130 | `MIN_SIGNAL = 0.012` | sabit |
| 133 | `_MARGIN_FULL = 0.65` | parametre |
| 143 | `if 0x0400 <= code <= 0x052F:` | karşılaştırma |
| 145 | `if (0x0041 <= code <= 0x007A) or (0x00C0 <= code <= 0x024F):` | karşılaştırma |
| 147 | `if 0x0600 <= code <= 0x06FF:` | karşılaştırma |
| 149 | `if 0x4E00 <= code <= 0x9FFF:` | karşılaştırma |
| 151 | `if 0x0370 <= code <= 0x03FF:` | karşılaştırma |
| 153 | `if 0x0590 <= code <= 0x05FF:` | karşılaştırma |
| 155 | `if 0x3040 <= code <= 0x30FF:` | karşılaştırma |
| 157 | `if 0xAC00 <= code <= 0xD7AF:` | karşılaştırma |
| 219 | `if top <= 0:` | karşılaştırma |
| 224 | `conf = 0.5 + 0.49 * min(1.0, margin / _MARGIN_FULL) * strength * abundance` | parametre |

### `agent_core/services/llm_gateway.py` — 33 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 419 | `if status == 429 or "429" in err or "rate limit" in err:` | karşılaştırma |
| 423 | `if status == 408 or "timeout" in err or "timed out" in err:` | karşılaştırma |
| 425 | `if isinstance(status, int) and 500 <= status < 600:` | karşılaştırma |
| 427 | `if status == 404 or "model_not_found" in err or "model unavailable" in err:` | karşılaştırma |
| 1079 | `if prompt_tokens < 0 or completion_tokens < 0:` | karşılaştırma |
| 1085 | `if not total_was_explicit and (total_tokens is None or total_tokens == 0):` | karşılaştırma |
| 1090 | `or total_tokens <= 0` | karşılaştırma |
| 1093 | `if prompt_tokens + completion_tokens <= 0:` | karşılaştırma |
| 1169 | `if self.spend_cap_usd > 0 and projected > self.spend_cap_usd:` | karşılaştırma |
| 1195 | `cost = reserved if reserved > 0 and not usage_is_trustworthy else observed_cost` | karşılaştırma |
| 1196 | `if reserved > 0 and not usage_is_trustworthy:` | karşılaştırma |
| 1208 | `if self.spend_cap_usd <= 0:` | karşılaştırma |
| 1290 | `return status in (408, 429) or 500 <= status < 600` | karşılaştırma |
| 1318 | `return isinstance(status, int) and (status in (408, 429) or 500 <= status < 600)` | karşılaştırma |
| 1461 | `if r > 0}` | karşılaştırma |
| 1746 | `if pricing is None and self.spend_cap_usd > 0:` | karşılaştırma |
| 1914 | `if not priced and self.spend_cap_usd > 0:` | karşılaştırma |
| 2094 | `temperature: float = 0.7,` | parametre |
| 2132 | `else ("pineal-deep-reasoning" if tier == 1 else "pineal-fast-extract")` | karşılaştırma |
| 2138 | `else model or (self.TIER_1_MODEL if tier == 1 else self.TIER_2_MODEL)` | karşılaştırma |
| 2300 | `elif self.spend_cap_usd > 0 and os.getenv("PINEAL_ALLOW_UNPRICED_MODELS", "0") != "1":` | karşılaştırma |
| 2525 | `if self.failure_count > 5:` | karşılaştırma |
| 2571 | `if effective_max_tokens < 1 or effective_max_tokens > self.max_output_tokens:` | karşılaştırma |
| 2644 | `if time.time() - self.circuit_opened_at > 60.0:` | karşılaştırma |
| 2699 | `elif self.spend_cap_usd > 0:` | karşılaştırma |
| 2780 | `if self.failure_count > 5:` | karşılaştırma |
| 2832 | `if effective_max_tokens < 1 or effective_max_tokens > self.max_output_tokens:` | karşılaştırma |
| 2915 | `elif self.spend_cap_usd > 0:` | karşılaştırma |
| 3015 | `if pos == -1:` | karşılaştırma |
| 3068 | `async def query_json(self, prompt: str, schema: Type[T], temperature: float = 0.7, tier: int = 1, model: str = None, ima` | parametre |
| 3081 | `selected_model = model or (self.TIER_1_MODEL if tier == 1 else self.TIER_2_MODEL)` | karşılaştırma |
| 3103 | `temperature: float = 0.7,` | parametre |
| 3177 | `temperature: float = 0.7,` | parametre |

### `agent_core/services/local_jury.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 62 | `MAX_SEATS = 5` | parametre |
| 62 | `MAX_SEATS = 5` | sabit |
| 277 | `if response.status_code >= 400:` | karşılaştırma |
| 373 | `timeout: float = 60.0,` | parametre |

### `agent_core/services/maigret_scanner.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 30 | `DEFAULT_SITE_TIMEOUT = 15` | parametre |
| 30 | `DEFAULT_SITE_TIMEOUT = 15` | sabit |
| 31 | `DEFAULT_TOTAL_TIMEOUT = 45` | parametre |
| 31 | `DEFAULT_TOTAL_TIMEOUT = 45` | sabit |
| 32 | `MAX_SITES_LIMIT = 500` | parametre |
| 32 | `MAX_SITES_LIMIT = 500` | sabit |
| 306 | `elif scanned > 0 and error_count == 0:` | karşılaştırma |

### `agent_core/services/media_forensics.py` — 21 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 80 | `MAX_DOWNLOAD_BYTES = 80 * 1024 * 1024` | parametre |
| 80 | `MAX_DOWNLOAD_BYTES = 80 * 1024 * 1024` | sabit |
| 81 | `MAX_SCENES = 40` | parametre |
| 81 | `MAX_SCENES = 40` | sabit |
| 82 | `MAX_INDEX_FILES = 500` | parametre |
| 82 | `MAX_INDEX_FILES = 500` | sabit |
| 145 | `async def fetch_media(source: str, *, timeout: float = 120.0) -> MediaFetch:` | parametre |
| 191 | `if proc.returncode != 0:` | karşılaştırma |
| 213 | `if response.status_code != 200:` | karşılaştırma |
| 275 | `def analyze_frames(path: str, *, sample_every: int = 5) -> FrameAnalysis:` | parametre |
| 327 | `if index % step == 0:` | karşılaştırma |
| 335 | `if correlation < 0.6:` | karşılaştırma |
| 338 | `timestamp = index / fps if fps > 0 else 0.0` | karşılaştırma |
| 364 | `duration_s=round(index / fps, 3) if fps > 0 else 0.0,` | karşılaştırma |
| 439 | `timeout=300,` | parametre |
| 443 | `if proc.returncode != 0 or not target.exists():` | karşılaştırma |
| 448 | `async def transcribe(path: str, *, timeout: float = 600.0) -> Transcript:` | parametre |
| 473 | `if response.status_code != 200:` | karşılaştırma |
| 498 | `if proc.returncode != 0:` | karşılaştırma |
| 538 | `def phash(path: str, *, size: int = 32, low: int = 8) -> str:` | parametre |
| 621 | `{"file": name, "phash": digest, "distance": distance, "similar": distance <= 10}` | karşılaştırma |

### `agent_core/services/memory_crystal.py` — 18 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `DEFAULT_MAX_FRAGMENTS = 300` | parametre |
| 41 | `DEFAULT_MAX_FRAGMENTS = 300` | sabit |
| 42 | `DEFAULT_RECALL_K = 8` | parametre |
| 42 | `DEFAULT_RECALL_K = 8` | sabit |
| 43 | `RECENCY_WINDOW_DAYS = 30.0` | parametre |
| 43 | `RECENCY_WINDOW_DAYS = 30.0` | sabit |
| 46 | `VECTOR_DIM = 256` | parametre |
| 46 | `VECTOR_DIM = 256` | sabit |
| 50 | `MIN_RECALL_SIMILARITY = 0.08` | parametre |
| 50 | `MIN_RECALL_SIMILARITY = 0.08` | sabit |
| 52 | `RELATIVE_RECALL_FLOOR = 0.5` | parametre |
| 52 | `RELATIVE_RECALL_FLOOR = 0.5` | sabit |
| 66 | `def _clean_text(value: Any, *, max_len: int = 280) -> str:` | parametre |
| 91 | `if norm > 0:` | karşılaştırma |
| 412 | `hits = [h for h in sorted(hits, key=lambda h: (-h.score, h.fragment_id)) if h.score > 0]` | karşılaştırma |
| 415 | `if best > 0.0:` | karşılaştırma |
| 429 | `if best > 0.0:` | karşılaştırma |
| 470 | `f"— kaynak: {_clean_text(source, max_len=120)} · skor {hit.score:.2f} ({', '.join(hit.reasons)})"` | parametre |

### `agent_core/services/memory_injector.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 38 | `def _sanitize_rule_text(text: str, *, max_len: int = 500) -> str:` | parametre |
| 111 | `tag = _sanitize_rule_text(r.get("tag", "KURAL") or "KURAL", max_len=64)` | parametre |
| 112 | `fact = _sanitize_rule_text(r.get("fact", "") or "", max_len=500)` | parametre |
| 126 | `max_rules = 50` | parametre |

### `agent_core/services/message_decision_context.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 62 | `if max_items < 0 or max_chars < 0:` | karşılaştırma |

### `agent_core/services/provider_manager.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 139 | `if value is not None and (not isinstance(value, (int, float)) or value < 0):` | karşılaştırma |
| 181 | `if self.context_window is not None and self.context_window <= 0:` | karşılaştırma |
| 278 | `if self.priority < 0:` | karşılaştırma |
| 280 | `if not isinstance(self.weight, (int, float)) or self.weight <= 0:` | karşılaştırma |
| 298 | `if self.remaining_fraction is not None and not 0 <= self.remaining_fraction <= 1:` | karşılaştırma |

### `agent_core/services/psychodynamic_depth.py` — 15 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 72 | `if total <= 0 or len(dist) <= 1:` | karşılaştırma |
| 75 | `ent = -sum(p * math.log(p) for p in probs if p > 0.0)` | karşılaştırma |
| 121 | `c1 = 1.0 if n_texts > 0 else 0.0` | karşılaştırma |
| 122 | `if n_texts > 0:` | karşılaştırma |
| 146 | `elif aesthetic_present or n_images > 0:` | karşılaştırma |
| 147 | `c2 = 0.5` | parametre |
| 150 | `if c2 > 0:` | karşılaştırma |
| 166 | `n_samples = samples if isinstance(samples, int) and samples > 0 else 0` | karşılaştırma |
| 182 | `c3 = 1.0 if n_samples >= 3 else (0.5 if n_samples > 0 else 0.0)` | karşılaştırma |
| 183 | `if c3 > 0:` | karşılaştırma |
| 200 | `if c4 > 0 and er_val is not None:` | karşılaştırma |
| 226 | `if total <= 0:` | karşılaştırma |
| 235 | `carriers = [name for name, w in zip(CHANNELS, weights) if w > 0]` | karşılaştırma |
| 237 | `if c1 == 0:` | karşılaştırma |
| 263 | `def measure_saturation(image_paths: Any, max_side: int = 64) -> Dict[str, Any]:` | parametre |

### `agent_core/services/quota_governor.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `_APPROACHING_FRACTION = 0.10` | parametre |
| 36 | `_MINUTE_SECONDS = 60.0` | parametre |
| 37 | `_DAY_SECONDS = 24 * 3600.0` | parametre |
| 52 | `if value is not None and (not isinstance(value, int) or value <= 0):` | karşılaştırma |
| 132 | `if isinstance(prompt_tokens, int) and prompt_tokens > 0:` | karşılaştırma |
| 134 | `if isinstance(completion_tokens, int) and completion_tokens > 0:` | karşılaştırma |
| 136 | `if tokens > 0:` | karşılaştırma |
| 155 | `if status_code != 429:` | karşılaştırma |
| 241 | `if remaining_fraction is not None and remaining_fraction <= 0:` | karşılaştırma |
| 272 | `if fraction is not None and fraction <= 0:` | karşılaştırma |

### `agent_core/services/quote_guard.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 67 | `if best >= 1.0:` | karşılaştırma |

### `agent_core/services/redis_bus.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 120 | `await self._client.set(key, data, ex=3600)` | parametre |
| 122 | `self._client.set(key, data, ex=3600)` | parametre |

### `agent_core/services/report_factory.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 70 | `def slugify(value: str, *, limit: int = 48) -> str:` | parametre |
| 213 | `if y < 25 * mm:` | karşılaştırma |
| 241 | `row_h = 46` | parametre |
| 242 | `header_h = 90` | parametre |
| 243 | `width = 1000` | parametre |
| 299 | `timeout=180,` | parametre |
| 303 | `if proc.returncode != 0 or not path.exists():` | karşılaştırma |

### `agent_core/services/response_cache.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 33 | `MAX_CACHABLE_PROMPT_CHARS = 32_000` | parametre |
| 33 | `MAX_CACHABLE_PROMPT_CHARS = 32_000` | sabit |
| 36 | `DEFAULT_TTL_SECONDS = 7 * 24 * 3600` | parametre |
| 36 | `DEFAULT_TTL_SECONDS = 7 * 24 * 3600` | sabit |
| 40 | `DEFAULT_MAX_ROWS = 50_000` | parametre |
| 40 | `DEFAULT_MAX_ROWS = 50_000` | sabit |
| 43 | `_PRUNE_EVERY_WRITES = 256` | parametre |
| 47 | `DEFAULT_PRUNE_INTERVAL_SECONDS = 900` | parametre |
| 47 | `DEFAULT_PRUNE_INTERVAL_SECONDS = 900` | sabit |
| 98 | `conn = sqlite3.connect(self.db_path, timeout=5, check_same_thread=False)` | parametre |
| 174 | `temperature: float = 0.7,` | parametre |

### `agent_core/services/routed_chat.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 171 | `or rate < 0` | karşılaştırma |
| 281 | `max_output_tokens: int = 4096,` | parametre |
| 790 | `if config_path.stat().st_size > 1_048_576:` | karşılaştırma |

### `agent_core/services/search_engine.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 118 | `async def search(self, query: str, num_results: int = 5) -> SearchOutcome:` | parametre |
| 136 | `async with open_client(purpose="search", timeout=10.0) as client:` | parametre |
| 233 | `if code == 429:` | karşılaştırma |
| 250 | `async with open_client(purpose="search", target=url, timeout=10.0) as _client:` | parametre |
| 253 | `if res.status_code == 200:` | karşılaştırma |
| 274 | `async with open_client(purpose="search", target=url, timeout=10.0) as _client:` | parametre |
| 277 | `if res.status_code == 200:` | karşılaştırma |
| 299 | `async with open_client(purpose="search", target=url, timeout=10.0) as _client:` | parametre |
| 302 | `if res.status_code == 200:` | karşılaştırma |
| 324 | `async with open_client(purpose="search", target=url, timeout=10.0) as _client:` | parametre |
| 327 | `if res.status_code == 200:` | karşılaştırma |

### `agent_core/services/socid_enricher.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 20 | `REQUEST_TIMEOUT = 10.0` | parametre |
| 20 | `REQUEST_TIMEOUT = 10.0` | sabit |
| 94 | `if resp.status_code != 200:` | karşılaştırma |

### `agent_core/services/task_lifecycle.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 81 | `self.retention_seconds = 1800.0` | parametre |
| 82 | `self._sweep_interval_seconds = 30.0` | parametre |

### `agent_core/services/taste_filter.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 39 | `DEFAULT_TASTE_THRESHOLD = 0.70` | parametre |
| 39 | `DEFAULT_TASTE_THRESHOLD = 0.70` | sabit |
| 152 | `if hedges >= 3 or (word_count and hedges / word_count * 100 >= 3):` | karşılaştırma |
| 167 | `if word_count >= 120:` | karşılaştırma |
| 169 | `if lexical < 0.45:` | karşılaştırma |
| 174 | `if emojis >= 2:` | karşılaştırma |
| 269 | `def telemetry_summary(storage: Optional[str] = None, limit: int = 20) -> Dict[str, Any]:` | parametre |

### `agent_core/services/theme_cluster.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 23 | `THEME_SIM_THRESHOLD = 0.30` | parametre |
| 23 | `THEME_SIM_THRESHOLD = 0.30` | sabit |
| 25 | `_EXEMPLAR_LEN = 120` | parametre |
| 43 | `if dot == 0:` | karşılaştırma |
| 47 | `if na == 0.0 or nb == 0.0:` | karşılaştırma |
| 59 | `isolated_anomaly_count. n == 0 ise sifir-govdeli sonuc doner (hata yok).` | karşılaştırma |
| 73 | `if n == 0:` | karşılaştırma |

### `agent_core/services/threshold_calibration.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `DEFAULT_THRESHOLD = 0.70` | parametre |
| 37 | `DEFAULT_THRESHOLD = 0.70` | sabit |
| 43 | `DEFAULT_MIN_SAMPLES = 30` | parametre |
| 43 | `DEFAULT_MIN_SAMPLES = 30` | sabit |
| 313 | `def _wilson(successes: int, total: int, z: float = 1.96) -> List[float]:` | parametre |
| 315 | `if total <= 0:` | karşılaştırma |
| 324 | `def _reliability(pairs: Sequence[Tuple[float, bool]], bins: int = 5) -> Tuple[List[ReliabilityBin], float]:` | parametre |
| 329 | `if total == 0:` | karşılaştırma |
| 383 | `if positives == 0 or negatives == 0:` | karşılaştırma |

### `agent_core/services/timing_forensics.py` — 18 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 17 | `ENTROPY_JUMP_THRESHOLD = 0.5   # /ΔH/ (nat) uzeri = entropi sictamasi` | parametre |
| 17 | `ENTROPY_JUMP_THRESHOLD = 0.5   # /ΔH/ (nat) uzeri = entropi sictamasi` | sabit |
| 18 | `VARIANCE_SHIFT_RATIO = 3.0     # varyans orani uzeri = varyans makasi` | parametre |
| 18 | `VARIANCE_SHIFT_RATIO = 3.0     # varyans orani uzeri = varyans makasi` | sabit |
| 19 | `_VAR_FLOOR = 0.01              # sifira-bolum kilidi (saat^2)` | parametre |
| 43 | `return round(-sum(p * math.log(p) for p in probs if p > 0.0), 3)` | karşılaştırma |
| 47 | `if hour >= 23 or hour < 5:` | karşılaştırma |
| 49 | `if hour < 9:` | karşılaştırma |
| 51 | `if hour < 18:` | karşılaştırma |
| 66 | `ruptur aramasi icin n >= 4 (her yari en az 2 ornek).` | karşılaştırma |
| 127 | `if n >= 4:` | karşılaştırma |
| 190 | `"note": "n<4: ruptur aranmadi (yari basina en az 2 ornek gerekir)"` | karşılaştırma |
| 191 | `if n < 4 else "ok",` | karşılaştırma |
| 202 | `night = sum(1 for h in hours if h >= 23 or h < 5)   # 23:00-04:59` | karşılaştırma |
| 203 | `evening = sum(1 for h in hours if 20 <= h < 23)` | karşılaştırma |
| 204 | `workday = sum(1 for h in hours if 9 <= h < 18)` | karşılaştırma |
| 213 | `if drift_hours > 12:` | karşılaştırma |
| 215 | `if drift_hours < -12:` | karşılaştırma |

### `agent_core/services/token_optimizer.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 96 | `min_item_chars: int = 256` | parametre |
| 106 | `if not 0 <= self.min_item_chars <= 1_000_000:` | karşılaştırma |
| 108 | `if not 1 <= self.max_item_bytes <= 16_000_000:` | karşılaştırma |
| 110 | `if not 1 <= self.max_total_bytes <= 64_000_000:` | karşılaştırma |

### `agent_core/services/translation.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 40 | `MAX_TEXT_CHARS = 2000` | parametre |
| 40 | `MAX_TEXT_CHARS = 2000` | sabit |
| 44 | `_CLI_TIMEOUT = 30.0` | parametre |
| 177 | `if response.status_code >= 400:` | karşılaştırma |
| 219 | `if proc.returncode != 0:` | karşılaştırma |

### `agent_core/services/uncertainty_engine.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 132 | `if total_fields == 0:` | karşılaştırma |
| 167 | `final_score = total_score / total_weight if total_weight > 0 else 0.0` | karşılaştırma |
| 199 | `if evidence_count == 0:` | karşılaştırma |
| 211 | `if evidence_count == 0:` | karşılaştırma |
| 317 | `confidence=0.1,` | parametre |
| 323 | `if combined_confidence > 0.95 and has_absolutes:` | karşılaştırma |
| 326 | `confidence=0.9,` | parametre |

### `agent_core/services/unified_router.py` — 36 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 101 | `provider_open_seconds: float = 60.0` | parametre |
| 102 | `max_provider_open_seconds: float = 900.0` | parametre |
| 103 | `rate_limit_cooldown_seconds: float = 60.0` | parametre |
| 104 | `quota_cooldown_seconds: float = 3600.0` | parametre |
| 105 | `transient_cooldown_seconds: float = 5.0` | parametre |
| 106 | `credential_cooldown_seconds: float = 300.0` | parametre |
| 107 | `model_lock_seconds: float = 300.0` | parametre |
| 108 | `max_retry_after_seconds: float = 7 * 24 * 3600.0` | parametre |
| 109 | `lkg_ttl_seconds: float = 15 * 60.0` | parametre |
| 112 | `max_attempts: int = 8` | parametre |
| 116 | `if not 1 <= self.provider_failure_threshold <= 100:` | karşılaştırma |
| 133 | `if not 100 <= self.max_state_entries <= 100_000:` | karşılaştırma |
| 135 | `if not 10 <= self.max_session_entries <= 100_000:` | karşılaştırma |
| 137 | `if not 1 <= self.max_attempts <= 100:` | karşılaştırma |
| 139 | `if not 2 <= self.fusion_width <= 10:` | karşılaştırma |
| 153 | `max_output_tokens: int = 4096` | parametre |
| 171 | `if self.minimum_context is not None and self.minimum_context <= 0:` | karşılaştırma |
| 176 | `or not 0 <= self.minimum_quality <= 1` | karşılaştırma |
| 179 | `if self.estimated_input_tokens < 0 or self.max_output_tokens < 1:` | karşılaştırma |
| 181 | `if self.estimated_input_tokens > 10_000_000 or self.max_output_tokens > 10_000_000:` | karşılaştırma |
| 371 | `or not 0 <= score <= 1` | karşılaştırma |
| 537 | `if math.isfinite(latency_ms) and latency_ms >= 0:` | karşılaştırma |
| 579 | `if cooldown > 0:` | karşılaştırma |
| 729 | `scores[target.execution_key] = 1.0 if maximum <= 0 else 1 - cost / maximum` | karşılaştırma |
| 824 | `0.5 if not math.isfinite(cost) else 1.0 if maximum_cost <= 0 else max(0.0, 1 - cost / maximum_cost)` | karşılaştırma |
| 831 | `0.5 if latency is None else 1.0 if maximum_latency <= 0 else max(0.0, 1 - latency / maximum_latency)` | karşılaştırma |
| 837 | `verification_factor = 0.2 if target.verification.status is VerificationStatus.FAILED else 1.0` | parametre |
| 998 | `((key, state) for key, state in self._target_state.items() if state.active_requests == 0),` | karşılaştırma |
| 1024 | `if count <= 1:` | karşılaştırma |
| 1040 | `if status == 401 or any(marker in text for marker in ("invalid_api_key", "unauthorized")):` | karşılaştırma |
| 1042 | `if status == 403 or "permission denied" in text:` | karşılaştırma |
| 1048 | `if status == 429:` | karşılaştırma |
| 1052 | `if status == 408:` | karşılaştırma |
| 1054 | `if isinstance(status, int) and 500 <= status <= 599:` | karşılaştırma |
| 1067 | `maximum: float = 7 * 24 * 3600.0,` | parametre |
| 1127 | `utilization = 0.5 if remaining is None else 1.0 - remaining` | parametre |

### `agent_core/services/upstream_findings.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `_MAX_PROMPT_CHARS = 2000` | parametre |
| 36 | `_MAX_CORE_CHARS = 280` | parametre |

### `agent_core/services/verdict_synthesizer.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 20 | `_CLAIM_LIMIT = 280` | parametre |
| 21 | `_TOTAL_BUDGET = 2000` | parametre |
| 22 | `_MAX_LINES = 12` | parametre |

### `agent_core/services/vision_analyzer.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 104 | `async with open_client(purpose="media", target=image_url, timeout=15.0, follow_redirects=False) as new_client:` | parametre |
| 107 | `if resp.status_code != 200:` | karşılaştırma |
| 197 | `async with open_client(purpose="media", timeout=15.0, follow_redirects=False) as client:` | parametre |
| 251 | `temperature=0.2,` | parametre |
| 258 | `has_evidence = result.confidence > 0.5` | karşılaştırma |

### `agent_core/shadow/shadow_executor.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 239 | `if observed_traits > 0 else 0.0` | karşılaştırma |

### `agent_core/task_executor.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 116 | `UPSTREAM_FINDINGS_BUDGET_CHARS = 2000` | parametre |
| 116 | `UPSTREAM_FINDINGS_BUDGET_CHARS = 2000` | sabit |
| 275 | `def _finding_core(result: Any, limit: int = 280) -> str:` | parametre |
| 387 | `if not limit or limit <= 0:` | karşılaştırma |
| 448 | `return positional >= 3` | karşılaştırma |
| 455 | ``limit <= 0` ise sınır yoktur (eski davranış). Süre aşımı DİĞER` | karşılaştırma |
| 671 | `async with open_client(purpose="media", follow_redirects=False, timeout=15.0) as client:` | parametre |
| 689 | `verified = await self.llm_gateway.query(prompt, temperature=0.1, tier=1)` | parametre |
| 1125 | `_verified = _cap <= 0 or (` | karşılaştırma |
| 1218 | `kayma_str = f"+{kayma:.1f}sa" if kayma >= 0 else f"{kayma:.1f}sa"` | karşılaştırma |
| 1411 | `timeline.entries if timeline.rejected_item_count == 0 else []` | karşılaştırma |
| 1998 | `if agent_name == "resonance_calc" and hasattr(result, "compatibility_score") and result.compatibility_score < 0.70:` | karşılaştırma |

### `agent_core/utils/security.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 119 | `if spend_cap <= 0:` | karşılaştırma |
| 396 | `_REDACTOR_CACHE_LIMIT = 8` | parametre |

### `agent_core/workers/agent_worker.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 137 | `async def probe_backend(backend_url: str, *, timeout: float = 5.0) -> bool:` | parametre |
| 148 | `return response.status_code < 500` | karşılaştırma |
| 191 | `heartbeat_interval: float = 30.0,` | parametre |
| 334 | `"--heartbeat-interval", type=float, default=30.0, help="Canlılık yayın aralığı (saniye)"` | parametre |

### `android/app/src/main/java/com/example/pineal/MainActivity.kt` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 137 | `.padding(horizontal = 14.dp, vertical = 8.dp)` | parametre |
| 161 | `fontSize = 9.sp,` | parametre |
| 163 | `letterSpacing = 0.5.sp` | parametre |
| 175 | `.padding(horizontal = 6.dp, vertical = 3.dp)` | parametre |
| 180 | `fontSize = 9.sp,` | parametre |
| 199 | `contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),` | parametre |
| 204 | `Text("🇹🇷 TR", fontSize = 9.sp, fontWeight = FontWeight.Bold)` | parametre |
| 214 | `contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),` | parametre |
| 219 | `Text("🇬🇧 EN", fontSize = 9.sp, fontWeight = FontWeight.Bold)` | parametre |
| 265 | `fontSize = 11.sp,` | parametre |
| 304 | `fontSize = 11.sp,` | parametre |
| 349 | `fontSize = 8.sp,` | parametre |
| 351 | `letterSpacing = 0.5.sp` | parametre |

### `android/app/src/main/java/com/example/pineal/engine/ForensicReconEngine.kt` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 74 | `temperature = 0.2f` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/AgentChainCard.kt` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `"COMPLETED" -> Triple(MatrixGreen.copy(alpha=0.15f), "COMPLETED", MatrixGreenLight)` | parametre |
| 56 | `"PROCESSING" -> Triple(WarningGold.copy(alpha=0.2f), "PROCESSING", WarningGoldLight)` | parametre |
| 57 | `"FAILED", "HALTED" -> Triple(BloodRed.copy(alpha=0.2f), "HALTED", BloodRedLight)` | parametre |
| 64 | `.padding(horizontal = 8.dp, vertical = 2.dp)` | parametre |
| 69 | `fontSize = 9.sp,` | parametre |
| 132 | `fontSize = 11.sp,` | parametre |
| 136 | `if (agent.confidence > 0.0) {` | karşılaştırma |
| 182 | `fontSize = 9.sp,` | parametre |
| 214 | `fontSize = 11.sp,` | parametre |
| 220 | `fontSize = 12.sp,` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/AspasiaChatCard.kt` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 128 | `contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),` | parametre |
| 138 | `Text(s.explainStateBtn, fontSize = 9.sp, fontWeight = FontWeight.Bold)` | parametre |
| 167 | `.background(CyberGold.copy(alpha = 0.15f), RoundedCornerShape(16.dp))` | parametre |
| 169 | `.padding(horizontal = 8.dp, vertical = 4.dp)` | parametre |
| 182 | `Text(text = "${msg.sender}:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)` | parametre |
| 183 | `Text(text = msg.text, fontSize = 11.sp, color = TextMain)` | parametre |
| 195 | `Text(text = "ASPASIA:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyberGold)` | parametre |
| 196 | `Text(text = msg.text, fontSize = 11.sp, color = TextMain, lineHeight = 16.sp)` | parametre |
| 214 | `placeholder = { Text(s.chatPlaceholder, fontSize = 11.sp, color = TextMuted) },` | parametre |
| 276 | `contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/CognitiveRadarChart.kt` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 36 | `val levels = 5` | parametre |
| 44 | `if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)` | karşılaştırma |
| 76 | `if (i == 0) dataPath.moveTo(x, y) else dataPath.lineTo(x, y)` | karşılaştırma |
| 82 | `color = LuxuryPurple.copy(alpha = 0.3f)` | parametre |
| 100 | `radius = 8f,` | parametre |
| 124 | `fontSize = 11.sp,` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/HistorySheet.kt` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 79 | `contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)` | parametre |
| 90 | `.padding(vertical = 24.dp),` | parametre |
| 95 | `fontSize = 11.sp,` | parametre |
| 103 | `.heightIn(max = 360.dp),` | parametre |
| 123 | `fontSize = 12.sp,` | parametre |
| 139 | `fontSize = 9.sp,` | parametre |
| 144 | `fontSize = 9.sp,` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/HolisticProfileCard.kt` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 36 | `.border(1.dp, BorderDim.copy(alpha=0.5f), RoundedCornerShape(16.dp)),` | parametre |
| 38 | `colors = CardDefaults.cardColors(containerColor = SurfaceDark.copy(alpha=0.9f))` | parametre |
| 78 | `letterSpacing = 0.5.sp` | parametre |
| 84 | `if (m.creativity > 0.0 // m.analytical > 0.0 // m.empathy > 0.0 // m.leadership > 0.0 // m.adaptability > 0.0) {` | karşılaştırma |
| 115 | `if (isCritical) BloodRed.copy(alpha=0.4f) else MatrixGreenDim,` | parametre |
| 131 | `letterSpacing = 0.5.sp` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/PinealBackground.kt` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `radius = 2000f` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/ReconInputCard.kt` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `fontSize = 11.sp,` | parametre |
| 45 | `lineHeight = 14.sp` | parametre |
| 53 | `.heightIn(min = 60.dp),` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/ReconRadarCard.kt` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 32 | `.border(1.dp, BorderDim.copy(alpha=0.5f), RoundedCornerShape(16.dp)),` | parametre |
| 34 | `colors = CardDefaults.cardColors(containerColor = SurfaceDark.copy(alpha=0.9f))` | parametre |
| 81 | `.border(1.dp, statusColor.copy(alpha=0.3f), RoundedCornerShape(16.dp)),` | parametre |
| 87 | `Surface(shape = RoundedCornerShape(16.dp), color = statusColor.copy(alpha = 0.1f)) {` | parametre |
| 93 | `modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)` | parametre |
| 117 | `.border(1.dp, MatrixGreenDim.copy(alpha=0.5f), RoundedCornerShape(16.dp)),` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/TargetInputCard.kt` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 38 | `.border(1.dp, NeonCyan.copy(alpha=0.3f), RoundedCornerShape(topEnd = 16.dp, bottomStart = 16.dp))` | parametre |
| 39 | `.background(SurfaceDark, RoundedCornerShape(topEnd = 16.dp, bottomStart = 16.dp))` | parametre |
| 91 | `selectedContainerColor = NeonCyan.copy(alpha = 0.2f),` | parametre |
| 110 | `Text("DEEP_OSINT_EXTRACTION", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)` | parametre |
| 111 | `Text("Requires Apify/PhantomBuster API Key", color = TextMuted, fontSize = 9.sp)` | parametre |
| 130 | `shape = RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp),` | parametre |
| 143 | `fontSize = 14.sp` | parametre |
| 159 | `.padding(horizontal = 8.dp, vertical = 10.dp)` | parametre |
| 161 | `Text(text = "", color = NeonCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace)` | parametre |
| 165 | `textStyle = TextStyle(color = TextMain, fontSize = 12.sp, fontFamily = FontFamily.Monospace),` | parametre |
| 170 | `Text(text = placeholder, color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/components/TelemetryAndLogsCard.kt` — 18 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 103 | `fontSize = 12.sp,` | parametre |
| 122 | `fontSize = 9.sp,` | parametre |
| 135 | `.background(BloodRed.copy(alpha = 0.15f), RoundedCornerShape(16.dp))` | parametre |
| 136 | `.border(1.dp, BloodRed.copy(alpha = 0.4f), RoundedCornerShape(16.dp))` | parametre |
| 137 | `.padding(horizontal = 6.dp, vertical = 2.dp)` | parametre |
| 139 | `Text(text = flag, fontSize = 8.sp, color = BloodRedLight)` | parametre |
| 159 | `Text(text = "CACHE HIT", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)` | parametre |
| 160 | `Text(text = state.telemetry.cacheHitRate, fontSize = 11.sp, color = CyberCyanLight, fontWeight = FontWeight.Bold)` | parametre |
| 170 | `Text(text = "HITS", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)` | parametre |
| 171 | `Text(text = "${state.telemetry.cacheHits}", fontSize = 11.sp, color = MatrixGreenLight, fontWeight = FontWeight.Bold)` | parametre |
| 181 | `Text(text = "LLM ÇAĞRISI", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)` | parametre |
| 182 | `Text(text = "${state.telemetry.llmCallsObserved}", fontSize = 11.sp, color = CyberGoldLight, fontWeight = FontWeight.Bol` | parametre |
| 210 | `fontSize = 11.sp,` | parametre |
| 216 | `fontSize = 9.sp,` | parametre |
| 245 | `fontSize = 9.sp,` | parametre |
| 247 | `lineHeight = 13.sp` | parametre |
| 282 | `fontSize = 9.sp,` | parametre |
| 347 | `Text(s.sealBtn, fontSize = 11.sp, fontWeight = FontWeight.Bold)` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/theme/Theme.kt` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 31 | `bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp),` | parametre |
| 32 | `bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp),` | parametre |
| 34 | `titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 20.sp),` | parametre |
| 35 | `titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 16.sp),` | parametre |
| 36 | `titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 14.sp),` | parametre |
| 37 | `labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp),` | parametre |
| 39 | `labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 8.sp)` | parametre |

### `android/app/src/main/java/com/example/pineal/ui/theme/Type.kt` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `fontSize = 24.sp,` | parametre |
| 20 | `fontSize = 20.sp,` | parametre |
| 21 | `letterSpacing = 0.5.sp,` | parametre |
| 27 | `fontSize = 16.sp,` | parametre |
| 28 | `letterSpacing = 0.5.sp,` | parametre |
| 34 | `fontSize = 14.sp,` | parametre |
| 40 | `fontSize = 14.sp,` | parametre |
| 41 | `lineHeight = 20.sp,` | parametre |
| 47 | `fontSize = 12.sp,` | parametre |
| 48 | `lineHeight = 16.sp,` | parametre |

### `backend/api.py` — 127 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 145 | `_spend_unlimited = (_spend_cap == 0.0)` | karşılaştırma |
| 237 | `return JSONResponse(health_status, status_code=503)` | parametre |
| 240 | `return JSONResponse(health_status, status_code=503)` | parametre |
| 335 | `return JSONResponse(body, status_code=503)` | parametre |
| 353 | `return JSONResponse(body, status_code=401)` | parametre |
| 389 | `status_code=429,` | parametre |
| 398 | `status_code=429,` | parametre |
| 411 | `status_code=429,` | parametre |
| 443 | `status_code=422,` | parametre |
| 454 | `return JSONResponse(body, status_code=500)` | parametre |
| 567 | `if overflow > 0:` | karşılaştırma |
| 669 | `_TELEMETRY_CAPABILITY_TTL_S = 300.0` | parametre |
| 997 | `_MAX_TERMINATE_REASON_LENGTH = 500` | parametre |
| 1021 | `return JSONResponse(body, status_code=503)` | parametre |
| 1038 | `status_code=403,` | parametre |
| 1056 | `status_code=403,` | parametre |
| 1130 | `raise HTTPException(status_code=400, detail="INVALID_CLIENT_ID")` | parametre |
| 1134 | `raise HTTPException(status_code=400, detail="INVALID_CLIENT_ID") from None` | parametre |
| 1282 | `"queue": asyncio.Queue(maxsize=2000),` | parametre |
| 1344 | `tools: Optional[list[dict[str, Any]]] = Field(default=None, max_length=128)` | parametre |
| 1348 | `user: Optional[str] = Field(default=None, max_length=256)` | parametre |
| 1520 | `status_code=400,` | parametre |
| 1530 | `status_code=400,` | parametre |
| 1542 | `status_code=400,` | parametre |
| 1553 | `status_code=400,` | parametre |
| 1563 | `and savings.applications > 0` | karşılaştırma |
| 1648 | `status_code=429,` | parametre |
| 1653 | `status_code=400,` | parametre |
| 1658 | `status_code = 400` | parametre |
| 1662 | `status_code = 503` | parametre |
| 1673 | `error_type = "rate_limit_error" if upstream_status == 429 else "invalid_request_error"` | karşılaştırma |
| 1675 | `status_code = 502` | parametre |
| 1694 | `status_code=502,` | parametre |
| 1756 | `_ROOM_PRUNE_INTERVAL_SECONDS = 30.0` | parametre |
| 1969 | `retention = 1800.0` | parametre |
| 1990 | `if overflow > 0:` | karşılaştırma |
| 2008 | `if overflow > 0:` | karşılaştırma |
| 2085 | `_WS_SEND_TIMEOUT_S = 5.0` | parametre |
| 2250 | `url: str = Field(max_length=8_192)` | parametre |
| 2253 | `rituals: str = Field(default="", max_length=32_000)` | parametre |
| 2254 | `playlist: str = Field(default="", max_length=32_000)` | parametre |
| 2255 | `envies: str = Field(default="", max_length=32_000)` | parametre |
| 2256 | `scraper_type: str = Field(default="instagram", max_length=64)` | parametre |
| 2260 | `aspasia_goals: List[str] = Field(default_factory=list, max_length=64)` | parametre |
| 2432 | `search_tasks = [executor.search_engine.search(q, num_results=6) for q in queries]` | parametre |
| 2854 | `status_code=429,` | parametre |
| 2879 | `status_code=503,` | parametre |
| 2931 | `status_code=400,` | parametre |
| 2936 | `status_code=400,` | parametre |
| 3090 | `keep = 5` | parametre |
| 3241 | `return JSONResponse({"error": {"code": "AGENT_UPDATE_FAILED", "message": str(e)[:200]}}, status_code=500)` | parametre |
| 3302 | `status_code=423` | parametre |
| 3453 | `status_code=423,` | parametre |
| 3527 | `case_type: str = Field(default="", max_length=64)` | parametre |
| 3531 | `council_approvals: List[str] = Field(default_factory=list, max_length=32)` | parametre |
| 3532 | `case_id: str = Field(default="", max_length=128)` | parametre |
| 3602 | `status_code=451,` | parametre |
| 3684 | `status_code=400,` | parametre |
| 3691 | `status_code=400,` | parametre |
| 3710 | `status_code=503,` | parametre |

### `backend/middleware/body_size_limit.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 42 | `self.max_bytes = 1048576` | parametre |

### `backend/routes/language.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `client_id: str = Field(default="default", max_length=128)` | parametre |
| 52 | `client_id: str = Field(default="default", max_length=128)` | parametre |
| 98 | `status_code=429,` | parametre |
| 148 | `status_code=429,` | parametre |

### `backend/routes/support.py` — 24 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 4 | `(``tests/unit/test_api_monolith_ratchet.py`` → ``MAX_LINES = 6000``; kural:` | parametre |
| 49 | `action: str = Field(default="provide", max_length=32)` | parametre |
| 50 | `note: str = Field(default="", max_length=500)` | parametre |
| 56 | `status_code=400,` | parametre |
| 76 | `if cap <= 0.0:` | karşılaştırma |
| 154 | `status_code=409,` | parametre |
| 159 | `status_code=404,` | parametre |
| 193 | `status_code=409,` | parametre |
| 198 | `status_code=404,` | parametre |
| 217 | `status_code=404,` | parametre |
| 224 | `status_code=409,` | parametre |
| 229 | `status_code=400,` | parametre |
| 242 | `status_code=409,` | parametre |
| 254 | `status_code=404,` | parametre |
| 260 | `status_code=409,` | parametre |
| 279 | `status_code=429,` | parametre |
| 299 | `status_code=409,` | parametre |
| 304 | `status_code=404,` | parametre |
| 322 | `status_code=409,` | parametre |
| 338 | `status_code=409,` | parametre |
| 348 | `status_code=409,` | parametre |
| 381 | `status_code=409,` | parametre |
| 389 | `status_code=409,` | parametre |
| 398 | `status_code=409,` | parametre |

### `backend/routes/tasks.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 4 | `(``tests/unit/test_api_monolith_ratchet.py`` → ``MAX_LINES = 6000``; kural:` | parametre |
| 146 | `status_code=400,` | parametre |
| 160 | `status_code=500,` | parametre |
| 166 | `status_code=404,` | parametre |

### `backend/routes/websocket.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 47 | `WS_AUTH_TIMEOUT_S = 5.0` | parametre |
| 47 | `WS_AUTH_TIMEOUT_S = 5.0` | sabit |
| 50 | `_CLOSE_TRY_AGAIN = 1013` | parametre |
| 52 | `_CLOSE_POLICY = 1008` | parametre |

### `backend/security/task_access.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 6 | `(``tests/unit/test_api_monolith_ratchet.py`` → ``MAX_LINES = 6000``) gövdeleri` | parametre |
| 48 | `value = 128` | parametre |

### `backend/security/task_ownership.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 89 | `connection = sqlite3.connect(path, timeout=5.0)` | parametre |

### `frontend/src/App.svelte` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `if (telemetryData.agent_statuses && Object.keys(telemetryData.agent_statuses).length > 0) {` | karşılaştırma |
| 55 | `if (Object.keys(mapped).length > 0) {` | karşılaştırma |
| 291 | `if (data.agents && data.agents.length > 0) {` | karşılaştırma |

### `frontend/src/components/AgentRack.svelte` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 80 | `$: hasBackendStatus = Object.keys(statuses).length > 0;` | karşılaştırma |

### `frontend/src/components/AtlasPinealCockpit.svelte` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 31 | `let meshSize = 180;` | parametre |
| 65 | `eyeScale = 1.016 + Math.sin(elapsed * 0.5) * 0.012;` | parametre |
| 73 | `if (vw < 1200) meshSize = 120;` | karşılaştırma |
| 73 | `if (vw < 1200) meshSize = 120;` | parametre |
| 74 | `else if (vw < 1600) meshSize = 150;` | karşılaştırma |
| 74 | `else if (vw < 1600) meshSize = 150;` | parametre |
| 75 | `else meshSize = 180;` | parametre |
| 160 | `if (typeof value === 'string') return value.trim().length > 0;` | karşılaştırma |
| 161 | `if (Array.isArray(value)) return value.length > 0;` | karşılaştırma |
| 417 | `: companyInfo.modes.length > 0` | karşılaştırma |
| 615 | `micRecorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) micChunks.push(e.data); };` | karşılaştırma |

### `frontend/src/components/CockpitEntry.svelte` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 27 | `: progress < 30` | karşılaştırma |
| 29 | `: progress < 65` | karşılaştırma |
| 31 | `: progress < 100` | karşılaştırma |
| 72 | `const dur = 1700;` | parametre |
| 77 | `if (p >= 0.5 && p < 0.53) playClick(520, 40);` | karşılaştırma |
| 78 | `if (p < 1) {` | karşılaştırma |
| 113 | `const max = 512;` | parametre |
| 184 | `<div class="plaque-sub">360° BÜTÜNCÜL İNSAN TANIMA İSTASYONU</div>` | karşılaştırma |

### `frontend/src/components/HolographicResonanceMesh.svelte` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 18 | `export let size: number = 520;` | parametre |
| 20 | `export let intensity: number = 0.85;` | parametre |
| 170 | `c.lineWidth = 1.2;` | parametre |
| 179 | `c.lineWidth = 0.8;` | parametre |
| 201 | `c.lineWidth = 0.5 + Math.min(1.2, link.weight * 0.15);` | parametre |
| 214 | `c.shadowBlur = 5 + pulse * 5;` | parametre |
| 228 | `const text = node.label.length > 14 ? `${node.label.slice(0, 13)}…` : node.label;` | karşılaştırma |

### `frontend/src/components/OrganikIrisCanvas.svelte` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 8 | `export let size: number = 420;` | parametre |
| 55 | `if (newSize > 0) {` | karşılaştırma |

### `frontend/src/components/PinealEye.svelte` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 7 | `export let size: number = 232;` | parametre |
| 35 | `if (dist < 1) {` | karşılaştırma |
| 50 | `if (e.touches.length > 0) handleMove(e.touches[0].clientX, e.touches[0].clientY);` | karşılaştırma |

### `frontend/src/components/SupportPanel.svelte` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 24 | `return sid.length > 26 ? sid.slice(0, 26) + '…' : sid;` | karşılaştırma |
| 86 | `{#if $supportRequests.length > 0 && $supportTaskId}` | karşılaştırma |

### `frontend/src/components/TacticalWarRoom.svelte` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 333 | `<span class="col-icon">⚡</span> 12 AJAN OPERASYON MATRİSİ` | karşılaştırma |
| 374 | `style="width: {conf !== null ? (conf * 100) : 0}%; background: {conf !== null && conf >= 0.7 ? '#10b981' : conf !== null` | karşılaştırma |
| 409 | `{#if detectedUrls.length > 0}` | karşılaştırma |
| 566 | `{#if run.call_ids && run.call_ids.length > 0}` | karşılaştırma |

### `frontend/src/components/UnifiedCompactPanel.svelte` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 109 | `let throttleAngle = 45;` | parametre |
| 110 | `let mixtureAngle = 120;` | parametre |
| 111 | `let propAngle = 210;` | parametre |
| 142 | `let odometer = 87;` | parametre |
| 143 | `$: if ($logs.length > 0) {` | karşılaştırma |
| 144 | `odometer = 87 + $logs.length;` | parametre |
| 533 | `{ k: 'TAVAN', ktr: 'CAP', v: $sysTelemetry.ok ? ($sysTelemetry.spendCapUsd > 0 ? `$${$sysTelemetry.spendCapUsd.toFixed(2` | karşılaştırma |
| 857 | `<span class="forensic-name">7 PILLARS</span>` | karşılaştırma |
| 858 | `<span class="forensic-tr">7 SÜTUN</span>` | karşılaştırma |

### `frontend/src/components/diesel/AnalogGauge.svelte` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 23 | `const r2 = 40;` | parametre |

### `frontend/src/components/visualizers/NeuralTelemetryBoard.svelte` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 9 | `Object.keys(telemetry).length > 0 &&` | karşılaştırma |
| 47 | `if (activeAgentsCount > 0) {` | karşılaştırma |
| 51 | `flowSpeed = 0.8;` | parametre |
| 55 | `flowSpeed = 3.5;` | parametre |
| 100 | `<div class="status-dot" class:pulsing={isOnline && activeAgentsCount > 0} class:offline-dot={!isOnline}></div>` | karşılaştırma |

### `frontend/src/lib/consoleAudio.ts` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 26 | `export function playClick(freq = 180, ms = 40) {` | parametre |
| 34 | `g.gain.value = 0.08;` | parametre |

### `frontend/src/lib/irisRenderer.ts` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 105 | `public setProcessing(active: boolean, intensity = 0.6) {` | parametre |
| 164 | `this.scale = 1.016 + baseBreath + procBreath;` | parametre |

### `frontend/src/lib/telemetry.ts` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 92 | `integrityPct: total > 0 ? Math.round((ready / total) * 100) : 0,` | karşılaştırma |

### `functions/api/[[path]].ts` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 83 | `if (upstream.status >= 300 && upstream.status < 400) {` | karşılaştırma |

### `live_llm_gate.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 83 | `executor.llm_gateway.max_output_tokens = 600` | parametre |

### `scripts/archive/analyze_target_instagram.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 88 | `await page.goto(target_url, timeout=45000, wait_until="domcontentloaded")` | parametre |
| 114 | `return Array.from(document.querySelectorAll('img[alt]')).map(img => img.getAttribute('alt')).filter(a => a && a.length >` | karşılaştırma |

### `scripts/archive/benchmark_download.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `if elapsed < 1.5:` | karşılaştırma |

### `scripts/archive/flow_roentgen.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 127 | `if depth > 6:` | karşılaştırma |
| 174 | `"""Gateway'i stub'lar. hang_seconds > 0 ise çağrılar askıda bırakılır.` | karşılaştırma |
| 285 | `def _drain_ws(ws, *, limit: int = 400, stop_on_result: bool = True, budget_s: float = 30.0):` | parametre |
| 314 | `body = response.json() if response.status_code == 200 else {"error": response.text}` | karşılaştırma |
| 315 | `frames = _drain_ws(ws) if response.status_code == 200 else []` | karşılaştırma |
| 394 | `with _patched_scraper(_TARGET_PROFILE), _stub_llm(hang_seconds=120):` | parametre |
| 403 | `if response.status_code == 200:` | karşılaştırma |
| 405 | `if index == 0:` | karşılaştırma |

### `scripts/archive/live_provider_probe.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 83 | `with httpx.Client(timeout=25, follow_redirects=True) as client:` | parametre |
| 88 | `if r.status_code != 200:` | karşılaştırma |

### `scripts/archive/ws_leak_probe.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 15 | `Çıkış kodu 0 = izole (leak==0 VE her istemci kendi sırrını aldı), 1 = ihlal/geçersiz.` | karşılaştırma |
| 37 | `msg = await asyncio.wait_for(ws.recv(), timeout=0.25)` | parametre |
| 101 | `"verdict": "ISOLATED" if (leak == 0 and own_missing == 0) else "VIOLATION_OR_INVALID",` | karşılaştırma |
| 103 | `return 0 if (leak == 0 and own_missing == 0) else 1` | karşılaştırma |

### `scripts/audit_regression.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 295 | `def _code_hits(rel: str, pattern: str, *, limit: int = 8) -> List[str]:` | parametre |
| 375 | `if idx == -1:` | karşılaştırma |
| 593 | `if idx == -1:` | karşılaştırma |
| 651 | `if idx == -1:` | karşılaştırma |
| 962 | `status = _hits(rel, r"status_code=400")` | parametre |

### `scripts/generate_inventory_page.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 200 | `out["desc"] = first_para(doc, limit=620, paragraphs=2)` | parametre |
| 215 | `def first_para(text: str, limit: int = 420, paragraphs: int = 1) -> str:` | parametre |
| 614 | `d.classList.toggle('hidden',vis===0&&needle.length>0);` | karşılaştırma |
| 833 | `ayrı modüle taşındı: <b>6.000 → 5.916 satır</b>, tavan da 5.916'ya DÜŞÜRÜLDÜ` | karşılaştırma |

### `scripts/preflight_9router.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 8 | `4. Çıktıyı JSON olarak raporlar ve hata durumunda exit code != 0 döner (CI uyumlu).` | karşılaştırma |
| 82 | `client = httpx.Client(timeout=30.0)` | parametre |
| 110 | `ok = resp.status_code == 200` | karşılaştırma |
| 145 | `ok = resp.status_code == 200` | karşılaştırma |

### `scripts/verify_openrouter_catalog.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 111 | `if actual_in != 0.0 or actual_out != 0.0:` | karşılaştırma |
| 130 | `if actual_in != 0.0 or actual_out != 0.0:` | karşılaştırma |
| 147 | `with urllib.request.urlopen(request, timeout=20) as response:` | parametre |

### `tests/audit/test_auditor_round2_findings.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `reg.retention_seconds = 60.0` | parametre |
| 41 | `assert removed == 1` | karşılaştırma |
| 52 | `reg.retention_seconds = 60.0` | parametre |
| 61 | `reg2.retention_seconds = 60.0` | parametre |
| 70 | `reg3.retention_seconds = 60.0` | parametre |
| 82 | `reg.retention_seconds = 60.0` | parametre |
| 208 | `assert r_long.status_code == 422, f"200 karakterlik task_id 422 vermedi: {r_long.status_code}"` | karşılaştırma |
| 210 | `assert r_bad.status_code == 400, f"geçersiz task_id biçimi 400 vermedi: {r_bad.status_code}"` | karşılaştırma |
| 213 | `assert r_halt.status_code == 422` | karşılaştırma |
| 216 | `assert r_reason.status_code == 400` | karşılaştırma |
| 230 | `assert r.status_code == 400, f"200 karakterlik task_id 400 vermedi: {r.status_code}"` | karşılaştırma |
| 288 | `assert r.status_code == 200, f"bozuk learnings.json hâlâ 500 üretiyor: {r.status_code} {r.text[:100]}"` | karşılaştırma |
| 324 | `assert score == 0.9` | karşılaştırma |

### `tests/audit/test_boss11_frame_contract.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 78 | `assert delivery["frame_errors_total"] == 1` | karşılaştırma |
| 105 | `assert delivery["frame_errors_total"] == 1` | karşılaştırma |

### `tests/audit/test_boss6_authentic_vector_telemetry.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `compatibility_score: float = 0.9` | parametre |
| 32 | `confidence: float = 0.9` | parametre |
| 73 | `return schema(depth=0.8, energy=0.6, achilles_heel="x", core_wound="y", dark_detail="z")` | parametre |

### `tests/audit/test_boss7_b9_wiring.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 40 | `machiavellianism=0.6,` | parametre |
| 41 | `narcissism=0.4,` | parametre |
| 42 | `psychopathy=0.2,` | parametre |
| 115 | `authenticity_score = 0.8` | parametre |
| 118 | `confidence = 0.8` | parametre |
| 157 | `authenticity_score = 0.8` | parametre |
| 160 | `confidence = 0.8` | parametre |

### `tests/audit/test_boss8_agent_timeout.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 4 | `zinciri teorik en kötüde 3 model x 3 taşıma x 45s = 405s sürebiliyordu; görev` | parametre |
| 27 | `compatibility_score: float = 0.9` | parametre |
| 31 | `confidence: float = 0.9` | parametre |
| 67 | `min_llm_confidence=0.65, graceful_degradation=True,` | parametre |
| 68 | `timeout_seconds=0.05 if name == "human_behavior" else 0.0,` | parametre |
| 69 | `field_weights={}, min_data_score=0.6,` | parametre |
| 75 | `await asyncio.wait_for(stuck.wait(), timeout=5)` | parametre |

### `tests/audit/test_production_audit_findings.py` — 23 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 69 | `assert calls["n"] == 1, (` | karşılaştırma |
| 99 | `assert rows == 0, f"{rows} süresi dolmuş satır hâlâ duruyor (disk sızıntısı)"` | karşılaştırma |
| 100 | `assert free > 0, "silinen satırların alanı serbest bırakılmadı"` | karşılaştırma |
| 101 | `assert cache.pruned >= 500, f"pruned sayacı {cache.pruned}; silmeler izlenmiyor"` | karşılaştırma |
| 132 | `assert rows == 1, (` | karşılaştırma |
| 136 | `assert cache.pruned >= 10, f"pruned={cache.pruned}; zaman temelli budama çalışmadı"` | karşılaştırma |
| 166 | `assert rows == 0, (` | karşılaştırma |
| 170 | `assert restarted.pruned >= 25` | karşılaştırma |
| 180 | `cache = ResponseCache(db_path=str(tmp_path / "fail.db"), ttl_seconds=60)` | parametre |
| 188 | `assert cache.errors >= 1` | karşılaştırma |
| 199 | `cache = ResponseCache(db_path=str(tmp_path / "pragma.db"), ttl_seconds=60)` | parametre |
| 208 | `memory_cache = ResponseCache(db_path=":memory:", ttl_seconds=60)` | parametre |
| 275 | `assert api._ROOM_TTL_SECONDS == 1800.0, (` | karşılaştırma |
| 461 | `assert sweeps["n"] < 40, (` | karşılaştırma |
| 542 | `"çağrılmıyor — 'skor < 0.6 ise halt' sözleşmesi uygulanmıyor"` | karşılaştırma |
| 589 | `assert ticks > 0, "bekleme sırasında event loop hiç işlemedi (senkron blokaj)"` | karşılaştırma |
| 619 | `assert response.status_code != 500, (` | karşılaştırma |
| 736 | `assert state["max"] == 1, f"aynı anda {state['max']} merge içerdeydi; kilit dışlama sağlamıyor"` | karşılaştırma |
| 737 | `assert state["errors"] == 0, f"{state['errors']}/8 merge hata verdi; kilit korumuyor"` | karşılaştırma |
| 793 | `a = ResponseCache(db_path=db, ttl_seconds=7 * 24 * 3600)` | parametre |
| 856 | `cache = ResponseCache(db_path=db, ttl_seconds=3600)` | parametre |
| 955 | `assert codes[0] != 429, "ilk istek sınırlanmamalıydı"` | karşılaştırma |
| 991 | `async def close(self, code=1000):` | parametre |

### `tests/audit/test_responsibility_rules.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 171 | `assert idx != -1, "probe fallback log satırı yok"` | karşılaştırma |
| 179 | `assert idx != -1, "kapanış yayını arıza izi yok"` | karşılaştırma |
| 207 | `assert idx != -1` | karşılaştırma |
| 267 | `assert gate != -1` | karşılaştırma |
| 274 | `assert fn != -1` | karşılaştırma |
| 276 | `body = src[fn : nxt if nxt != -1 else None]` | karşılaştırma |

### `tests/audit/test_round3_residue_findings.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 140 | `assert r.status_code == 503, f"doymuş oda 503 vermedi: {r.status_code} {r.text[:80]}"` | karşılaştırma |
| 227 | `assert r1.status_code == 200, (` | karşılaştırma |
| 231 | `assert r2.status_code == 200, "quarantine sonrası ikinci istek 500"` | karşılaştırma |
| 260 | `assert r.status_code == 200` | karşılaştırma |

### `tests/audit/test_support_flow_acceptance.py` — 14 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 34 | `confidence: float = 0.95,` | parametre |
| 43 | `data_score=0.9 if not suspicious else 0.3,` | parametre |
| 74 | `confidence: float = 0.9` | parametre |
| 111 | `assert calls["searxng"] == 1, "birincil sağlayıcı denenmedi"` | karşılaştırma |
| 112 | `assert calls["duckduckgo"] == 1, "izinli alternatif denenmedi"` | karşılaştırma |
| 231 | `assert counts["cognitive_profiler"] == 1, "tamamlanan ajan tekrar çalıştırıldı"` | karşılaştırma |
| 232 | `assert counts["depth_analyst"] == 2, "destek sonrası engelli ajan devam etmedi"` | karşılaştırma |
| 402 | `assert calls["n"] == 1, "sınırsız tekrar var"` | karşılaştırma |
| 425 | `assert cap_calls["n"] == 1` | karşılaştırma |
| 496 | `assert calls["n"] == 1` | karşılaştırma |
| 505 | `assert calls["n"] == 1, "tamamlanan yan etki gereksiz yine çalıştı"` | karşılaştırma |
| 531 | `timeout=120,` | parametre |
| 546 | `assert proc1.returncode == 0, proc1.stderr[-800:]` | karşılaştırma |
| 557 | `assert proc2.returncode == 0, proc2.stderr[-800:]` | karşılaştırma |

### `tests/e2e/test_cross_stack_runtime.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 58 | `type(self).release.wait(timeout=5)` | parametre |
| 113 | `assert response.status_code == 200` | karşılaştırma |
| 133 | `assert started.status_code == 200` | karşılaştırma |
| 149 | `assert handler.request_count >= 2` | karşılaştırma |

### `tests/e2e/test_llm_protocol.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 47 | `if calls["n"] == 1:` | karşılaştırma |
| 54 | `assert calls["n"] == 2, "429 sonrası tek retry beklenir"` | karşılaştırma |
| 70 | `assert calls["n"] == 1, "auth hatası retry edilmemeli"` | karşılaştırma |
| 84 | `gw.failure_count = 5  # sınırdayız` | parametre |

### `tests/e2e/test_openai_compatibility.py` — 19 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 105 | `assert response.status_code == 200` | karşılaştırma |
| 111 | `assert captured["body"]["max_tokens"] == 128` | karşılaştırma |
| 121 | `assert gateway.call_log[0]["prompt_tokens"] == 100` | karşılaştırma |
| 122 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 123 | `assert gateway.spend_usd > 0` | karşılaştırma |
| 168 | `assert response.status_code == 200` | karşılaştırma |
| 200 | `assert response.status_code == 200` | karşılaştırma |
| 233 | `assert response.status_code == 200` | karşılaştırma |
| 285 | `assert missing.status_code == 401` | karşılaştırma |
| 287 | `assert accepted.status_code == 200` | karşılaştırma |
| 315 | `assert response.status_code == 400` | karşılaştırma |
| 317 | `assert calls == 0` | karşılaştırma |
| 360 | `assert response.status_code == 200` | karşılaştırma |
| 379 | `assert locked.status_code == 200` | karşılaştırma |
| 413 | `assert completions.attempts == 1` | karşılaştırma |
| 437 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 438 | `assert gateway.budget_status()["reserved_usd"] == 0` | karşılaştırma |
| 493 | `assert completions.calls == 1` | karşılaştırma |
| 494 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |

### `tests/e2e/test_smoke.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 20 | `assert r.status_code == 200` | karşılaştırma |
| 29 | `assert r.status_code == 200` | karşılaştırma |
| 41 | `assert r.status_code == 200` | karşılaştırma |
| 54 | `assert r.status_code == 200` | karşılaştırma |

### `tests/integration/test_agent_rack_wiring.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 45 | `compatibility_score: float = 0.9` | parametre |
| 67 | `reality_index=0.9,` | parametre |
| 103 | `uncertainty.evaluate.return_value = DummyCheck(confidence=0.9, is_suspicious=False)` | parametre |

### `tests/integration/test_aspasia_chat_api.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `assert r.status_code == 200, f"chat() imza kayması geri gelebilir: {r.text[:300]}"` | karşılaştırma |
| 42 | `assert r.status_code == 200` | karşılaştırma |
| 56 | `assert r.status_code == 200` | karşılaştırma |

### `tests/integration/test_badhost_auth_bypass.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 5 | `Zafiyet: Starlette <=1.0.0 request.url'u DOĞRULANMAMIŞ Host header'ından` | karşılaştırma |
| 40 | `Not: starlette>=1.0.1 Host'u doğruladığı için request.url.path zaten` | karşılaştırma |
| 70 | `assert r.status_code == 401, (` | karşılaştırma |
| 84 | `assert r.status_code == 401` | karşılaştırma |
| 97 | `assert r.status_code == 200` | karşılaştırma |
| 105 | `assert client.get("/api/telemetry", params={"client_id": cid}).status_code == 401` | karşılaştırma |
| 108 | `).status_code == 200` | karşılaştırma |

### `tests/integration/test_calibration_api_faz_b.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 33 | `assert created.status_code == 200, created.text` | karşılaştırma |
| 38 | `assert adjudicated.status_code == 200, adjudicated.text` | karşılaştırma |
| 47 | `assert quote["threshold"] == 0.70` | karşılaştırma |
| 50 | `assert payload["ledger"]["labeled"] == 0` | karşılaştırma |
| 63 | `assert rows["rows"] == 9 and rows["labeled"] == 0` | karşılaştırma |
| 77 | `assert quote["threshold"] != 0.70` | karşılaştırma |
| 78 | `assert 0.5 <= quote["threshold"] <= 0.95` | karşılaştırma |
| 116 | `assert response.status_code == 404` | karşılaştırma |

### `tests/integration/test_canonical_memory.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 25 | `assert data["evidence"][0]["target_authentic_vector"]["depth"] == 0.8` | karşılaştırma |

### `tests/integration/test_claim_gate_executor.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 25 | `confidence: float = 0.9` | parametre |
| 52 | `confidence=0.9,` | parametre |
| 86 | `confidence=0.9,` | parametre |
| 87 | `compliance_score=100.0,` | parametre |
| 104 | `confidence=0.9,` | parametre |
| 126 | `reality_index=0.9,` | parametre |
| 161 | `executor.uncertainty.evaluate.return_value = Check(confidence=0.9)` | parametre |
| 172 | `reality_index=0.9,` | parametre |

### `tests/integration/test_company_api_faz_d.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 86 | `assert payload["evidence_total"] == 0` | karşılaştırma |
| 101 | `assert response.status_code == 400` | karşılaştırma |
| 110 | `assert response.status_code == 400` | karşılaştırma |
| 146 | `assert seo["counts"]["evidence"] == 2` | karşılaştırma |

### `tests/integration/test_depth_verification_trace_executor.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 30 | `confidence: float = 0.9` | parametre |
| 54 | `confidence=0.9,` | parametre |
| 68 | `reality_index=0.3,` | parametre |
| 107 | `assert depth["quote_guard"]["dropped_fake_quote"] == 0` | karşılaştırma |
| 108 | `assert depth["quote_guard"]["verification_quote_sources"] == 1` | karşılaştırma |
| 116 | `assert trace["claims_available"] == 1` | karşılaştırma |
| 147 | `assert depth["quote_guard"]["verification_quote_sources"] == 0` | karşılaştırma |
| 148 | `assert depth["quote_guard"]["dropped_fake_quote"] == 1` | karşılaştırma |
| 150 | `assert depth["verification_trace"]["claims_available"] == 0` | karşılaştırma |

### `tests/integration/test_faz3_security.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 20 | `assert r.status_code == 200` | karşılaştırma |
| 27 | `assert r.status_code == 401` | karşılaştırma |
| 37 | `assert r.status_code == 200` | karşılaştırma |
| 45 | `assert r.status_code == 200` | karşılaştırma |
| 67 | `assert new.status_code == 200` | karşılaştırma |
| 78 | `assert r.status_code == 429` | karşılaştırma |

### `tests/integration/test_holistic_e2e.py` — 16 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 24 | `sentiment_polarity=0.8,` | parametre |
| 26 | `confidence=0.9` | parametre |
| 34 | `confidence=0.85` | parametre |
| 42 | `confidence=0.9` | parametre |
| 48 | `resonance_score=0.94,` | parametre |
| 52 | `confidence=0.95` | parametre |
| 59 | `alignment_score=0.9,` | parametre |
| 61 | `confidence=0.9` | parametre |
| 78 | `confidence=0.8,` | parametre |
| 79 | `micro_signals=[MicroSignal(signal_type="authentic", confidence=0.9, location="text_subtext", evidence="test", psychologi` | parametre |
| 80 | `achilles_score=85.0,` | parametre |
| 81 | `resonance_potential=0.9` | parametre |
| 88 | `confidence=0.95,` | parametre |
| 89 | `compliance_score=100.0,` | parametre |
| 96 | `depth=0.8, energy=0.5, achilles_heel="estetik", core_wound="yüzeysellik", dark_detail="sessizlik"` | parametre |
| 157 | `assert res.holistic_profile.bridge.resonance_score == 0.94` | karşılaştırma |

### `tests/integration/test_jury_api_faz_d.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 156 | `assert payload["counted"] == 3` | karşılaştırma |

### `tests/integration/test_language_api_faz_d.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 74 | `assert payload["confidence"] >= 0.85` | karşılaştırma |
| 85 | `assert payload["confidence"] == 0.0` | karşılaştırma |

### `tests/integration/test_live_fixes_2026_09.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 177 | `assert calls["scrape"] == 3, "retry loop PINEAL_SCRAPE_MAX_ATTEMPTS kez denemeli"` | karşılaştırma |
| 178 | `assert calls["execute"] == 0, "KANITSIZ profille executor çalıştırılamaz"` | karşılaştırma |
| 201 | `assert calls["scrape"] == 1, "kanıt yoksa denemek anlamsız"` | karşılaştırma |
| 202 | `assert calls["execute"] == 0` | karşılaştırma |
| 230 | `assert calls["scrape"] == 1` | karşılaştırma |
| 231 | `assert calls["execute"] == 1, "başarılı kazımadan sonra operasyon koşmalı"` | karşılaştırma |
| 272 | `assert pas[0]["result"]["confidence"] == 0.9, "en yeni kayıt kalmalı"` | karşılaştırma |
| 435 | `return PassionProfile(core_passions=["çay"], confidence=0.6)` | parametre |

### `tests/integration/test_llm_gateway_integration.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 49 | `assert gateway.client.chat.completions.attempts == 3` | karşılaştırma |
| 62 | `assert gateway.client.chat.completions.attempts == 1` | karşılaştırma |

### `tests/integration/test_mcp_server_stdio.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 83 | `timeout=120,` | parametre |
| 85 | `assert proc.returncode == 0, f"MCP sunucusu çöktü: {proc.stderr[-800:]}"` | karşılaştırma |
| 139 | `assert structured["evidence_count"] == 1` | karşılaştırma |
| 177 | `assert rendered["structuredContent"]["evidence_count"] == 0` | karşılaştırma |
| 191 | `assert responses[0]["result"]["structuredContent"]["evidence_count"] == 1` | karşılaştırma |
| 192 | `assert open_api.hits >= 1  # kanıt: kasa durumu GERÇEKTEN API'den okundu` | karşılaştırma |

### `tests/integration/test_media_api_faz_d.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 134 | `assert payload["evidence_total"] == 0` | karşılaştırma |
| 160 | `assert frames["notes"]["width"] == 120 and frames["notes"]["height"] == 90` | karşılaştırma |
| 173 | `assert response.status_code == 400` | karşılaştırma |

### `tests/integration/test_memory_crystal_api_faz_b.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `assert payload["fragment_count"] == 0` | karşılaştırma |
| 50 | `assert summary["fragment_count"] == 2` | karşılaştırma |
| 51 | `assert summary["task_count"] == 2` | karşılaştırma |
| 95 | `assert record["result"]["recalled"] >= 1` | karşılaştırma |

### `tests/integration/test_p2_release_gate.py` — 15 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `sentiment_polarity=0.8,` | parametre |
| 24 | `confidence=0.9` | parametre |
| 33 | `confidence=0.85` | parametre |
| 42 | `confidence=0.9` | parametre |
| 49 | `resonance_score=0.95,` | parametre |
| 53 | `confidence=0.95` | parametre |
| 59 | `alignment_score=0.9,` | parametre |
| 61 | `confidence=0.9` | parametre |
| 81 | `confidence=0.8,` | parametre |
| 82 | `micro_signals=[MicroSignal(signal_type="authentic", confidence=0.9, location="text_subtext", evidence="test", psychologi` | parametre |
| 83 | `achilles_score=85.0,` | parametre |
| 84 | `resonance_potential=0.9` | parametre |
| 90 | `confidence=0.95,` | parametre |
| 91 | `compliance_score=100.0,` | parametre |
| 117 | `depth=0.8, energy=0.4, achilles_heel="yalnizlik", core_wound="anlasilmama", dark_detail="sessizlik"` | parametre |

### `tests/integration/test_report_capabilities.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 161 | `assert pdf["rejected_item_count"] == 1` | karşılaştırma |
| 174 | `assert response.status_code == 400` | karşılaştırma |

### `tests/integration/test_resonance_executor_signature.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 19 | `return_value=UncertaintyReport(confidence=0.95, is_suspicious=False, reason="test")` | parametre |
| 25 | `alignment_score=0.9,` | parametre |
| 33 | `confidence=0.8,` | parametre |
| 34 | `micro_signals=[MicroSignal(signal_type="authentic", confidence=0.9, location="bio", evidence="gercek", psychological_wei` | parametre |
| 35 | `achilles_score=85.0,` | parametre |
| 36 | `resonance_potential=0.8` | parametre |
| 40 | `overall_authenticity_score=0.9` | parametre |
| 45 | `confidence=0.9,` | parametre |
| 46 | `compliance_score=0.9,` | parametre |

### `tests/integration/test_run_task_cli.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `timeout=120,` | parametre |
| 42 | `assert proc.returncode == 2` | karşılaştırma |
| 58 | `assert proc.returncode == 3` | karşılaştırma |
| 67 | `assert proc.returncode == 4` | karşılaştırma |
| 78 | `assert proc.returncode == 0, proc.stderr[-500:]` | karşılaştırma |
| 100 | `assert proc.returncode == 0, proc.stderr[-500:]` | karşılaştırma |

### `tests/integration/test_scraper_error_handling.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 39 | `assert page.attempts == 3` | karşılaştırma |
| 51 | `assert page.attempts == 3  # Max retries` | karşılaştırma |
| 62 | `assert page.attempts == 1  # Should not retry` | karşılaştırma |

### `tests/integration/test_speech_api_faz_c.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 23 | `def _wav(seconds: float = 1.5, rate: int = 8000) -> bytes:` | parametre |
| 135 | `assert result["duration_ms"] == 1500` | karşılaştırma |
| 139 | `assert audio.status_code == 200` | karşılaştırma |
| 178 | `assert frame["duration_ms"] == 1500` | karşılaştırma |
| 242 | `assert response.status_code == 400` | karşılaştırma |

### `tests/integration/test_support_cockpit.py` — 31 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `confidence: float = 0.9` | parametre |
| 59 | `def _report(confidence: float = 0.95) -> UncertaintyReport:` | parametre |
| 63 | `reason="yeterli kanıt" if confidence >= 0.65 else "güven düşük",` | karşılaştırma |
| 64 | `data_score=0.9 if confidence >= 0.65 else 0.3,` | karşılaştırma |
| 64 | `data_score=0.9 if confidence >= 0.65 else 0.3,` | parametre |
| 116 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 189 | `timeout: float = 15.0) -> str:` | parametre |
| 200 | `if r.status_code == 200:` | karşılaştırma |
| 239 | `stop.wait(timeout=6.0)` | parametre |
| 246 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 267 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 277 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 287 | `assert counts["cognitive_profiler"] == 1, counts` | karşılaştırma |
| 288 | `assert counts["depth_analyst"] >= 2, counts  # engelli tur + devam turu` | karşılaştırma |
| 335 | `assert r.status_code == 403, r.text` | karşılaştırma |
| 344 | `assert r2.status_code == 403, r2.text` | karşılaştırma |
| 363 | `assert r1.status_code == 200, r1.text` | karşılaştırma |
| 369 | `assert r2.status_code == 409, r2.text` | karşılaştırma |
| 388 | `).status_code == 200` | karşılaştırma |
| 404 | `assert r1.status_code == 200, r1.text` | karşılaştırma |
| 406 | `assert r2.status_code == 409, r2.text` | karşılaştırma |
| 421 | `assert r.status_code == 409, r.text` | karşılaştırma |
| 457 | `assert r.status_code == 423, r.text` | karşılaştırma |
| 465 | `assert r.status_code == 423, r.text` | karşılaştırma |
| 474 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 496 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 517 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 519 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 541 | `assert r.status_code == 409, r.text` | karşılaştırma |
| 546 | `assert r.status_code == 404, r.text` | karşılaştırma |
| 555 | `assert r.status_code == 200` | karşılaştırma |

### `tests/integration/test_task_executor_flow.py` — 21 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 9 | `compatibility_score: float = 0.9` | parametre |
| 19 | `reality_index=0.9,` | parametre |
| 38 | `uncertainty.evaluate.return_value = DummyCheck(confidence=0.9, is_suspicious=False)` | parametre |
| 103 | `assert adapter_record["result"]["item_count"] == 0` | karşılaştırma |
| 109 | `assert timeline_record["result"]["entry_count"] == 0` | karşılaştırma |
| 130 | `executor.uncertainty.evaluate.return_value = DummyCheck(confidence=0.4, is_suspicious=False)` | parametre |
| 148 | `executor.uncertainty.evaluate.return_value = DummyCheck(confidence=0.8, is_suspicious=True, reason="Inconsistent")` | parametre |
| 156 | `assert input_data["target_analysis"]["compatibility_score"] == 0.9` | karşılaştırma |
| 169 | `executor.agents["resonance_calc"].execute = AsyncMock(return_value=DummyResult(compatibility_score=0.5))` | parametre |
| 198 | `intensity=7.0,` | parametre |
| 296 | `assert timeline_record["result"]["excluded_strategy_count"] == 1` | karşılaştırma |
| 368 | `confidence=0.8,` | parametre |
| 369 | `compliance_score=100.0,` | parametre |
| 376 | `confidence=0.8,` | parametre |
| 377 | `compliance_score=100.0,` | parametre |
| 443 | `assert expected_context.excluded_counts["absence"] > 0` | karşılaştırma |
| 444 | `assert expected_context.excluded_counts["inference"] > 0` | karşılaştırma |
| 445 | `assert expected_context.excluded_counts["strategy"] > 0` | karşılaştırma |
| 507 | `confidence=0.97,` | parametre |
| 508 | `achilles_score=50.0,` | parametre |
| 509 | `resonance_potential=0.6,` | parametre |

### `tests/integration/test_task_retention.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 32 | `assert r.status_code == 200` | karşılaştırma |
| 34 | `assert found and found[0]["evidence_count"] == 1` | karşılaştırma |
| 41 | `assert r.status_code == 200` | karşılaştırma |
| 50 | `assert r.status_code == 404` | karşılaştırma |
| 66 | `assert response.status_code == 200` | karşılaştırma |

### `tests/integration/test_taste_filter_api_faz_c.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 75 | `assert taste_filter.telemetry_summary()["total"] == 0` | karşılaştırma |
| 85 | `assert summary["dropped"] == 1` | karşılaştırma |

### `tests/integration/test_vault_unlock_and_routing.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 26 | `assert r.status_code == 200` | karşılaştırma |

### `tests/integration/test_ws_ordering.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 27 | `assert r.status_code == 200` | karşılaştırma |

### `tests/test_instagram_ghost.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `"""Güven < 0.6 ise halt - Faz 4 kuralı"""` | karşılaştırma |
| 51 | `follower_count=1000,` | parametre |

### `tests/test_llm_json_repair.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 23 | `if call_count == 1:` | karşılaştırma |
| 32 | `assert result.confidence == 0.9` | karşılaştırma |
| 33 | `assert call_count == 2  # It should trigger repair` | karşılaştırma |
| 52 | `assert call_count == 1  # no second paid repair attempt` | karşılaştırma |
| 70 | `assert call_count == 1` | karşılaştırma |
| 82 | `if call_count == 1:` | karşılaştırma |
| 90 | `assert call_count == 2` | karşılaştırma |

### `tests/test_pillar_engines.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 15 | `def data(n=24, gap=12):` | parametre |
| 21 | `t += timedelta(days=20) if i == gap else timedelta(hours=26 + i % 7)` | parametre |
| 38 | `assert r.status == EvidenceStatus.OBSERVED and len(r.waveform) == len(r.timeline) and 0 <= r.night_energy_share <= 1` | karşılaştırma |
| 42 | `r = await SeismosEngine(min_silence_hours=48, silence_factor=3).analyze(data())` | parametre |
| 43 | `assert SeismicKind.SILENCE_GAP in {e.kind for e in r.events} and all(1 <= e.intensity <= 10 for e in r.events)` | karşılaştırma |
| 47 | `r = await VoidEngine(min_tokens=20).analyze(data())` | parametre |
| 48 | `assert r.signals and 0 <= r.global_absence_index <= 1` | karşılaştırma |

### `tests/test_router.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `confidence: float = 0.5` | parametre |
| 17 | `return self.UR(confidence=0.5)` | parametre |

### `tests/test_scraper_fallback.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 38 | `assert exc.value.code == 1` | karşılaştırma |

### `tests/test_six_stamps_integration.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 66 | `assert snap_data['timing_forensics']['night_owl_score'] == 0.8` | karşılaştırma |
| 68 | `assert snap_data['depth_report']['reality_index'] == 0.85` | karşılaştırma |
| 69 | `assert snap_data['depth_report']['quote_guard']['kept'] == 1` | karşılaştırma |
| 75 | `assert snap_data['osint_footprint']['digital_footprint_score'] == 0.9` | karşılaştırma |
| 86 | `assert res_data['timing_forensics']['night_owl_score'] == 0.8` | karşılaştırma |
| 87 | `assert res_data['depth_report']['reality_index'] == 0.85` | karşılaştırma |
| 90 | `assert res_data['osint_footprint']['digital_footprint_score'] == 0.9` | karşılaştırma |

### `tests/test_system_modules.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `assert res.theme_analysis["n_texts"] == 1` | karşılaştırma |
| 30 | `assert analyzer.generate_strategy(DarkTriadProfile(narcissism=0.8))["vector"] == "mirroring"` | parametre |

### `tests/unit/test_agent_worker.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 220 | `heartbeat_interval=0.01,` | parametre |
| 314 | `assert captured["heartbeat_interval"] == 30.0` | karşılaştırma |

### `tests/unit/test_alternative_web_research.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 28 | `async def search(self, query, num_results=5):` | parametre |
| 59 | `assert research["total_results_searched"] == 2` | karşılaştırma |
| 127 | `assert r.status_code == 200` | karşılaştırma |

### `tests/unit/test_android_parity_labels.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 105 | `while index < len(text) and depth > 0:` | karşılaştırma |

### `tests/unit/test_api_monolith_ratchet.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `MEASURED_AT_AUDIT = 6034` | parametre |
| 41 | `MEASURED_AT_AUDIT = 6034` | sabit |
| 42 | `MEASURED_AFTER_FIRST_SPLIT = 5937` | parametre |
| 42 | `MEASURED_AFTER_FIRST_SPLIT = 5937` | sabit |
| 43 | `MEASURED_AFTER_SECOND_SPLIT = 5916` | parametre |
| 43 | `MEASURED_AFTER_SECOND_SPLIT = 5916` | sabit |
| 49 | `MAX_LINES = 5916` | parametre |
| 49 | `MAX_LINES = 5916` | sabit |

### `tests/unit/test_aspasia_chief_layer.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 268 | `assert doc["evidence_count"] == 2` | karşılaştırma |
| 373 | `assert cmd_i != -1, "ASPASIA serbest metni komut kanalini kullanmali"` | karşılaştırma |

### `tests/unit/test_aspasia_depth_hukmu.py` — 15 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 32 | `def _depth_doc(comp=0.42, react=0.61, nrup=2,` | parametre |
| 56 | `def _task_file(task_id, evidence, confidence=0.8):` | parametre |
| 114 | `assert digest["compensation_index"] == 0.42` | karşılaştırma |
| 115 | `assert digest["reaction_formation_index"] == 0.61` | karşılaştırma |
| 116 | `assert digest["n_ruptures"] == 2` | karşılaştırma |
| 121 | `first = _sealed_evidence(_depth_doc(comp=0.10, react=0.10))` | parametre |
| 122 | `second = _sealed_evidence(_depth_doc(comp=0.42, react=0.61))` | parametre |
| 124 | `assert digest["compensation_index"] == 0.42` | karşılaştırma |
| 151 | `assert sealed["depth"]["reaction_formation_index"] == 0.61` | karşılaştırma |
| 167 | `assert "derinlik: telafi=0.42 reaksiyon=0.61 kırılma=2 [entropy_jump+variance_shift]" in digest` | parametre |
| 186 | `assert bridge["tasks"][0]["depth"]["compensation_index"] == 0.42` | karşılaştırma |
| 189 | `assert "derinlik=telafi=0.42 reaksiyon=0.61 kırılma=2 [entropy_jump+variance_shift]" in digest` | parametre |
| 235 | `assert "derinlik: telafi=0.42" in digest` | parametre |
| 246 | `assert "derinlik=telafi=0.42" in digest` | parametre |
| 266 | `assert "telafi=0.42 reaksiyon=0.61" in captured["prompt"]` | parametre |

### `tests/unit/test_aspasia_promotion.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 84 | `usage = SimpleNamespace(prompt_tokens=1000, completion_tokens=200)` | parametre |
| 145 | `assert groq["limits"]["rpm"] == 30 and groq["limits"]["rpd"] == 14400` | karşılaştırma |
| 150 | `assert cere["limits"]["tpm"] == 30000 and cere["limits"]["tpd"] == 1_000_000` | karşılaştırma |

### `tests/unit/test_aspasia_state_consistency.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 290 | `assert bridge["tasks"][0]["evidence_count"] == 1` | karşılaştırma |

### `tests/unit/test_audit_regression.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 111 | `assert meta["finding_count"] == 24` | karşılaştırma |
| 238 | `[sys.executable, str(driver)], cwd=tmp_path, capture_output=True, text=True, timeout=300` | parametre |
| 240 | `assert proc.returncode == 1, (` | karşılaştırma |
| 723 | `timeout=300,` | parametre |
| 725 | `assert out.returncode == 0, out.stdout[-3_000:] + out.stderr[-3_000:]` | karşılaştırma |
| 728 | `assert payload["meta"]["finding_count"] == 24` | karşılaştırma |

### `tests/unit/test_authentic_vector_unavailable.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `assert vec["depth"] == 0.7` | karşılaştırma |

### `tests/unit/test_authenticity_auditor.py` — 14 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 18 | `"""Görsel kanıt olmadığında analiz yapılmadan confidence=0.1 ile erken dönülmelidir."""` | parametre |
| 26 | `assert res.confidence == 0.0` | karşılaştırma |
| 27 | `assert res.authenticity_score == 0.0` | karşılaştırma |
| 36 | `"""Metinsel beyan (bio ve posts) olmadığında confidence=0.1 ile erken dönülmelidir."""` | parametre |
| 44 | `assert res.confidence == 0.0` | karşılaştırma |
| 45 | `assert res.authenticity_score == 0.0` | karşılaştırma |
| 55 | `authenticity_score=0.88,` | parametre |
| 58 | `confidence=0.92` | parametre |
| 78 | `assert res.authenticity_score == 0.88` | karşılaştırma |
| 79 | `assert res.confidence == 0.92` | karşılaştırma |
| 86 | `assert call_kwargs["temperature"] == 0.2` | karşılaştırma |
| 91 | `"""LLM hatasında confidence=0.2 fallback dönmeli ve logger.warning istisnayı kaydetmelidir."""` | parametre |
| 105 | `assert res.confidence == 0.0` | karşılaştırma |
| 106 | `assert res.authenticity_score == 0.0` | karşılaştırma |

### `tests/unit/test_body_size_limit.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 8 | `5. Content-Length > 1 MiB olan isteklerin 413 BODY_TOO_LARGE ile reddedildiği.` | karşılaştırma |
| 35 | `assert result.returncode != 0` | karşılaştırma |
| 77 | `assert response.status_code != 413` | karşılaştırma |
| 82 | `oversized_len = 1048576 + 1024  # ~1.001 MiB` | parametre |
| 89 | `assert response.status_code == 413` | karşılaştırma |
| 99 | `for _ in range(20):     # 20 * 64 KiB = 1.25 MiB (> 1 MiB)` | parametre |
| 107 | `assert response.status_code == 413` | karşılaştırma |
| 122 | `assert res_ok.status_code != 413` | karşılaştırma |
| 130 | `assert res_over.status_code == 413` | karşılaştırma |
| 174 | `assert response.status_code == 500` | karşılaştırma |
| 200 | `middleware = BodySizeLimitMiddleware(exploding_app, max_bytes=1024)` | parametre |
| 256 | `middleware = BodySizeLimitMiddleware(cancelling_app, max_bytes=1024)` | parametre |

### `tests/unit/test_capability_spine_faz0.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 186 | `assert kernel.evaluate(frozenset({"budget"}), PolicyState(spent_usd=2.0, budget_usd=1.0)).reason == (` | parametre |
| 234 | `reg.register(_DummyCapability(sleep=0.2))` | parametre |
| 237 | `CapabilityContext(timeout_seconds=0.01),` | parametre |
| 274 | `assert result.duration_ms >= 0` | karşılaştırma |
| 285 | `assert seen[0]["evidence_count"] == 1` | karşılaştırma |

### `tests/unit/test_change_tracker_faz_b.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 108 | `assert report.unchanged_count == 1  # ortak bulgu` | karşılaştırma |
| 120 | `assert report.unchanged_count == 2` | karşılaştırma |
| 133 | `assert report.unchanged_count == 0` | karşılaştırma |
| 158 | `keep=5,` | parametre |
| 171 | `assert payload["snapshots"][0]["entry_count"] == 1` | karşılaştırma |

### `tests/unit/test_cognitive_profiler.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `assert res.confidence == 0.0` | karşılaştırma |
| 25 | `confidence=0.9` | parametre |
| 41 | `assert res.confidence == 0.9` | karşılaştırma |

### `tests/unit/test_company_capabilities.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 110 | `assert result.notes["counts"]["emails"] == 1` | karşılaştırma |

### `tests/unit/test_company_recon.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 40 | `<url><loc>{base}/</loc><lastmod>2026-09-01</lastmod></url>` | karşılaştırma |
| 243 | `assert checks["sitemap"].detail["entries"] == 3` | karşılaştırma |
| 254 | `assert robots.status == 404 and robots.absent is True` | karşılaştırma |

### `tests/unit/test_concurrent_spend_cap.py` — 14 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 12 | `completion_tokens = 500` | parametre |
| 41 | `if self.calls == 1:` | karşılaştırma |
| 92 | `assert completions.calls == 2` | karşılaştırma |
| 111 | `assert gateway.spend_usd == 0.0` | karşılaştırma |
| 112 | `assert gateway._reserved_spend_usd == 0.0` | karşılaştırma |
| 132 | `assert completions.calls == 2` | karşılaştırma |
| 135 | `assert gateway.call_log[-1]["attempt"] == 2` | karşılaştırma |
| 136 | `assert gateway._reserved_spend_usd == 0.0` | karşılaştırma |
| 147 | `assert gateway._reserved_spend_usd > 0` | karşılaştırma |
| 153 | `assert gateway._reserved_spend_usd == 0.0` | karşılaştırma |
| 182 | `assert gateway._reserved_spend_usd == 0.0` | karşılaştırma |
| 205 | `assert gateway.spend_usd == 0.0` | karşılaştırma |
| 206 | `assert gateway._reserved_spend_usd == 0.0` | karşılaştırma |
| 208 | `assert gateway.call_log[-1]["cost_usd"] == 0.0` | karşılaştırma |

### `tests/unit/test_config_contract.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 168 | `assert default_cfg.timeout_seconds == 120.0` | karşılaştırma |
| 169 | `assert cfg.get_agent_config("pineal_7pillar").timeout_seconds == 60.0` | karşılaştırma |
| 170 | `assert cfg.get_agent_config("depth_analyst").timeout_seconds == 150.0` | karşılaştırma |
| 181 | `mission_budget = 300  # backend/api.py PINEAL_TASK_TIMEOUT_SECONDS varsayılanı` | parametre |

### `tests/unit/test_consolidation_faz1_5.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 54 | `yaratamaz (eski kod concurrency>=2'de client sızdırıyordu)."""` | karşılaştırma |
| 85 | `res = await scan_email("a@b.com", modules=mods, site_timeout=5)` | parametre |
| 86 | `assert created["n"] == 1  # TEK istemci — sızıntı yok` | karşılaştırma |
| 87 | `assert res.scanned_count == 4` | karşılaştırma |
| 89 | `assert res.error_count == 0` | karşılaştırma |
| 131 | `results = await asyncio.gather(*(scan_username("soxoj", limit=5) for _ in range(3)))` | parametre |
| 132 | `assert calls["n"] == 1  # tek yükleme` | karşılaştırma |
| 133 | `assert all(r.scanned_count == 5 for r in results)` | karşılaştırma |

### `tests/unit/test_crawl_enricher.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 179 | `async def search(self, query, num_results=5):` | parametre |
| 294 | `assert stats["kept"] == 1` | karşılaştırma |
| 295 | `assert stats["dropped_fake_quote"] == 0` | karşılaştırma |
| 300 | `assert stats["kept"] == 0` | karşılaştırma |
| 301 | `assert stats["dropped_fake_quote"] == 1  # mevcut anti-halüsinasyon davranışı` | karşılaştırma |
| 306 | `assert stats["kept"] == 0  # yalnız dict + boş olmayan text kabul` | karşılaştırma |
| 323 | `assert r.status_code == 400` | karşılaştırma |
| 343 | `assert r.status_code == 200` | karşılaştırma |

### `tests/unit/test_dark_nlp_and_shadow.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 97 | `lambda profile_data: DarkTriadProfile(narcissism=0.8),` | parametre |
| 121 | `assert 0.0 <= res.confidence <= 1.0` | karşılaştırma |

### `tests/unit/test_deferred_agent_evidence_gate.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 29 | `confidence=0.9,` | parametre |
| 33 | `return_value=MagicMock(confidence=0.1, is_suspicious=True, reason="insufficient evidence")` | parametre |

### `tests/unit/test_dependency_health.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 116 | `assert response.status_code == 200` | karşılaştırma |

### `tests/unit/test_depth_and_forensics.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 16 | `assert res["samples"] == 4` | karşılaştırma |
| 17 | `assert res["night_share"] == 0.75  # 3 out of 4 are night` | karşılaştırma |
| 28 | `assert rep.data_completeness == 1.0` | karşılaştırma |
| 64 | `assert stats["checked"] == 3` | karşılaştırma |
| 65 | `assert stats["kept"] == 2` | karşılaştırma |
| 66 | `assert stats["dropped_fake_quote"] == 1` | karşılaştırma |

### `tests/unit/test_depth_failure_wiring.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 16 | `compatibility_score: float = 0.9` | parametre |
| 20 | `confidence: float = 0.9` | parametre |
| 85 | `reality_index=0.82,` | parametre |

### `tests/unit/test_depth_verification_trace.py` — 24 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 95 | `assert stats["dropped_fake_quote"] == 1` | karşılaştırma |
| 97 | `assert stats["verification_quote_sources"] == 0` | karşılaştırma |
| 98 | `assert cleaned["verification_trace"]["claims_available"] == 0` | karşılaştırma |
| 105 | `assert stats["dropped_fake_quote"] == 0` | karşılaştırma |
| 106 | `assert stats["verification_quote_sources"] == 1` | karşılaştırma |
| 107 | `assert stats["linked_to_verification"] == 1` | karşılaştırma |
| 121 | `assert trace["claims_available"] == 1` | karşılaştırma |
| 122 | `assert trace["quote_anchors"] == 1` | karşılaştırma |
| 140 | `assert stats["verification_quote_sources"] == 0` | karşılaştırma |
| 141 | `assert stats["dropped_fake_quote"] == 1` | karşılaştırma |
| 144 | `assert cleaned["verification_trace"]["claims_available"] == 1` | karşılaştırma |
| 145 | `assert cleaned["verification_trace"]["quote_anchors"] == 0` | karşılaştırma |
| 167 | `assert stats["verification_quote_sources"] == 0` | karşılaştırma |
| 186 | `assert stats["verification_quote_sources"] == 0` | karşılaştırma |
| 205 | `assert stats["rejected_claim_ids"] == 1` | karşılaştırma |
| 206 | `assert cleaned["verification_trace"]["rejected_claim_ids"] == 1` | karşılaştırma |
| 221 | `assert stats["linked_to_verification"] == 1` | karşılaştırma |
| 222 | `assert stats["rejected_claim_ids"] == 0` | karşılaştırma |
| 249 | `assert stats["verification_quote_sources"] == 2` | karşılaştırma |
| 282 | `assert stats["checked"] == 2 and stats["kept"] == 1` | karşılaştırma |
| 314 | `assert control.quote_guard["dropped_fake_quote"] == 1` | karşılaştırma |
| 318 | `assert treatment.quote_guard["dropped_fake_quote"] == 0` | karşılaştırma |
| 339 | `assert rep.reality_index == 0.0` | karşılaştırma |
| 349 | `r = DepthReport(reality_index=0.5, reality_rationale="", essence_one_liner="")` | parametre |

### `tests/unit/test_engine_determinism.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 57 | `times.append(base + timedelta(hours=8 * i))` | parametre |
| 59 | `times.append(times[-1] + timedelta(days=12))` | parametre |
| 61 | `times.append(times[-1] + timedelta(hours=8 * i))` | parametre |
| 69 | `if i < 10:` | karşılaştırma |
| 121 | `timeout=300,` | parametre |
| 123 | `assert proc.returncode == 0, f"PYTHONHASHSEED={seed} koşusu çöktü: {proc.stderr[-1500:]}"` | karşılaştırma |

### `tests/unit/test_evidence_hash_and_fallback_gate.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 9 | `confidence: float = 0.9` | parametre |
| 21 | `assert report.confidence == 0.0` | karşılaştırma |
| 46 | `def _bundle(when: datetime, absence: float = 0.75) -> PillarBundle:` | parametre |
| 53 | `expected_presence=0.9,` | parametre |
| 54 | `actual_presence=0.1,` | parametre |
| 55 | `absence_delta=0.8,` | parametre |
| 71 | `second = PinealExecutor._hash_evidence_result(_bundle(_T0 + timedelta(hours=7, minutes=13)))` | parametre |
| 78 | `assert PinealExecutor._hash_evidence_result(_bundle(_T0, absence=0.75)) != \` | parametre |
| 79 | `PinealExecutor._hash_evidence_result(_bundle(_T0, absence=0.31))` | parametre |
| 93 | `assert payload["void"]["global_absence_index"] == 0.75` | karşılaştırma |

### `tests/unit/test_evidence_timeline.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 74 | `assert timeline.excluded_strategy_count == 1` | karşılaştırma |
| 75 | `assert timeline.rejected_item_count == 1` | karşılaştırma |
| 106 | `assert timeline.excluded_strategy_count == 0` | karşılaştırma |
| 107 | `assert timeline.rejected_item_count == 0` | karşılaştırma |

### `tests/unit/test_execute_with_timeout.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 259 | `assert agent.calls == 1, f"ajan {agent.calls} kez koştu; beklenen 1"` | karşılaştırma |
| 276 | `assert agent.calls == 1` | karşılaştırma |

### `tests/unit/test_executor_confidence_semantics.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 7 | `"passion_mapper": AgentRun(task_id="x", agent_name="passion_mapper", status="completed", confidence=0.8),` | parametre |
| 8 | `"friction_detector": AgentRun(task_id="x", agent_name="friction_detector", status="completed", confidence=0.6),` | parametre |
| 9 | `"cognitive_profiler": AgentRun(task_id="x", agent_name="cognitive_profiler", status="failed", confidence=0.99),` | parametre |
| 10 | `"shadow_executor": AgentRun(task_id="x", agent_name="shadow_executor", status="completed", confidence=0.99),` | parametre |

### `tests/unit/test_experimental_engine_contract.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 132 | `assert r.status_code == 400, f"{path} ({reason}) → {r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 155 | `assert r.status_code == 400, f"{path} → {r.status_code}"` | karşılaştırma |
| 182 | `assert r.status_code == 200, f"{path} ({reason}) → {r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 200 | `assert r.status_code == 200, f"{path} → {r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 273 | `assert r.status_code == 503, r.text[:200]` | karşılaştırma |
| 283 | `assert r.status_code == 503, r.text[:200]` | karşılaştırma |
| 294 | `assert r.status_code == 503, r.text[:200]` | karşılaştırma |
| 321 | `assert r.status_code == 502, f"{r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 343 | `assert r.status_code == 503, f"{r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 350 | `assert api._module_unavailable_response(None, "m").status_code == 503` | karşılaştırma |

### `tests/unit/test_final_routing_policy.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 200 | `assert QUOTAS["groq"]["rpm"] == 30` | karşılaştırma |
| 201 | `assert QUOTAS["groq"]["rpd"] == 14_400` | karşılaştırma |
| 207 | `assert QUOTAS["cerebras"]["rpm"] == 5` | karşılaştırma |
| 208 | `assert QUOTAS["cerebras"]["tpm"] == 30_000` | karşılaştırma |
| 209 | `assert QUOTAS["cerebras"]["tpd"] == 1_000_000` | karşılaştırma |
| 272 | `assert spec.input_per_million_usd == 0.0` | karşılaştırma |
| 273 | `assert spec.output_per_million_usd == 0.0` | karşılaştırma |

### `tests/unit/test_final_spec_compliance.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 126 | `assert res.a == 1` | karşılaştırma |
| 142 | `assert gw._reserved_spend_usd == 0.0  # reservation sizdirmasi yok` | karşılaştırma |
| 301 | `if n <= 3:` | karşılaştırma |
| 326 | `assert gw._reserved_spend_usd == 0.0  # cap reddi => iade edilecek rezervasyon yok` | karşılaştırma |
| 466 | `if n < 3:` | karşılaştırma |
| 474 | `assert res.a == 1` | karşılaştırma |
| 476 | `assert gw._reserved_spend_usd == 0.0` | karşılaştırma |
| 477 | `assert gw.spend_usd > 0.0  # bozuk AMA faturalanmis 2 cagri bedava sayilmadi` | karşılaştırma |

### `tests/unit/test_final_sweep_honesty.py` — 17 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 29 | `assert profile.exploitability == 0.0` | karşılaştırma |
| 30 | `assert profile.narcissism == 0.0` | karşılaştırma |
| 41 | `strategy = analyzer.generate_strategy(DarkTriadProfile(narcissism=0.2))` | parametre |
| 52 | `assert profile.narcissism == 0.0` | karşılaştırma |
| 53 | `assert profile.exploitability == 0.0` | karşılaştırma |
| 56 | `assert themes["n_texts"] == 1` | karşılaştırma |
| 57 | `assert themes["n_themes"] == 1` | karşılaştırma |
| 58 | `assert themes["repetition_score"] == 1.0` | karşılaştırma |
| 74 | `assert result.confidence == 0.0` | karşılaştırma |
| 115 | `confidence=0.8,` | parametre |
| 116 | `compliance_score=100.0,` | parametre |
| 155 | `baseline_volatility = 0.4` | parametre |
| 160 | `night_energy_share = 0.5` | parametre |
| 179 | `baseline_volatility = 0.4` | parametre |
| 185 | `baseline_volatility = 0.4` | parametre |
| 194 | `assert rhythm_observed.confidence == 1.0` | karşılaştırma |
| 202 | `assert rhythm_weak.confidence == 0.5` | karşılaştırma |

### `tests/unit/test_forensic_closers_vault_rack_gravity_carrier.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 158 | `assert resp.status_code == 400` | karşılaştırma |
| 171 | `assert resp.status_code == 400` | karşılaştırma |
| 245 | `capture_output=True, text=True, env=env, timeout=120,` | parametre |
| 247 | `assert proc.returncode == 0, proc.stderr[-500:]` | karşılaştırma |
| 277 | `assert resp["count"] >= 12` | karşılaştırma |

### `tests/unit/test_friction_detector.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `assert res.confidence == 0.0` | karşılaştırma |
| 25 | `confidence=0.85` | parametre |
| 39 | `assert res.confidence == 0.85` | karşılaştırma |

### `tests/unit/test_gateway_cost_and_retry.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 53 | `assert calls["n"] == 0, "ücretli HTTP çağrısı hiç yapılmamalı"` | karşılaştırma |
| 70 | `assert calls["n"] == 1` | karşılaştırma |
| 71 | `assert gw.unpriced_calls == 1` | karşılaştırma |
| 73 | `assert gw.spend_usd == 0.0` | karşılaştırma |
| 103 | `assert calls["n"] == 1` | karşılaştırma |
| 108 | `assert calls["n"] == 1, "ikinci çağrı cache'ten gelmeli"` | karşılaştırma |
| 125 | `assert calls["n"] == 1, "[018] 400 retry edilmemeli (eski davranış 3 kez deniyordu)"` | karşılaştırma |
| 141 | `assert calls["n"] == 1` | karşılaştırma |
| 150 | `if calls["n"] == 1:` | karşılaştırma |
| 162 | `assert calls["n"] == 2` | karşılaştırma |
| 171 | `if calls["n"] <= 2:` | karşılaştırma |
| 182 | `assert calls["n"] == 3` | karşılaştırma |

### `tests/unit/test_gather_contract.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 52 | `MIN_RATIONALE_CHARS = 30` | parametre |
| 52 | `MIN_RATIONALE_CHARS = 30` | sabit |
| 70 | `if depth == 0:` | karşılaştırma |

### `tests/unit/test_glue_forensics_wiring.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 79 | `follower_count=1200,` | parametre |
| 88 | `like_count=45,` | parametre |
| 156 | `assert rep.following_count == 123` | karşılaştırma |
| 163 | `assert rep.post_count == 0` | karşılaştırma |
| 220 | `assert first.like_count == 12` | karşılaştırma |
| 221 | `assert first.comment_count == 2` | karşılaştırma |
| 222 | `assert first.taken_at is not None and first.taken_at.year == 2024` | karşılaştırma |
| 266 | `assert executor.execute_task.await_count == 3` | karşılaştırma |
| 278 | `if calls["n"] == 1:` | karşılaştırma |
| 344 | `model_dump=lambda: {}, exploitability=0.5` | parametre |

### `tests/unit/test_google_gemini_direct.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 162 | `if n == 1:` | karşılaştırma |
| 164 | `err.status_code = 429` | parametre |

### `tests/unit/test_gorev1_reel_video_chrono.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 112 | `assert by_code["AAA"]["taken_at"].year == 2024` | karşılaştırma |
| 113 | `assert by_code["AAA"]["like_count"] == 10` | karşılaştırma |
| 114 | `assert by_code["AAA"]["comment_count"] == 1` | karşılaştırma |
| 161 | `assert detail["taken_at"].year == 2024` | karşılaştırma |

### `tests/unit/test_gorev2_artiklar.py` — 24 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 49 | `assert DEPTH_MIRRORING_REACTION == 0.40` | karşılaştırma |
| 50 | `assert DEPTH_ALLIANCE_REPETITION == 0.40` | karşılaştırma |
| 54 | `s = DarkTriadAnalyzer().strategy_from_depth(_depth(react=0.61))` | parametre |
| 58 | `assert s["signal"]["reaction_formation_index"] == 0.61` | karşılaştırma |
| 62 | `s = DarkTriadAnalyzer().strategy_from_depth(_depth(rep=0.55))` | parametre |
| 65 | `assert s["signal"]["repetition_score"] == 0.55` | karşılaştırma |
| 73 | `assert s["signal"]["n_ruptures"] == 2` | karşılaştırma |
| 77 | `"""'n_ruptures >= 1 VEYA entropy_jump' — tur tek basina yeter."""` | karşılaştırma |
| 85 | `_depth(react=0.40))["vector"] == "mirroring"` | parametre |
| 87 | `_depth(react=0.399))["vector"] == "unobserved"` | parametre |
| 89 | `_depth(rep=0.40))["vector"] == "alliance"` | parametre |
| 91 | `_depth(rep=0.399))["vector"] == "unobserved"` | parametre |
| 96 | `_depth(react=0.9, rep=0.9, nrup=5, kinds=["entropy_jump"]))` | parametre |
| 99 | `_depth(react=0.1, rep=0.9, nrup=5, kinds=["entropy_jump"]))` | parametre |
| 134 | `"psychodynamic_depth": _depth(react=0.61),` | parametre |
| 162 | `assert res["n_total"] == 2` | karşılaştırma |
| 163 | `assert res["n_measured"] == 0` | karşılaştırma |
| 219 | `assert res["mean_saturation"] == 0.375` | karşılaştırma |
| 220 | `assert res["n_measured"] == 2` | karşılaştırma |
| 221 | `assert res["n_total"] == 3` | karşılaştırma |
| 234 | `assert res["n_measured"] == 0` | karşılaştırma |
| 246 | `assert res["n_measured"] == 1` | karşılaştırma |
| 247 | `assert res["mean_saturation"] == 1.0` | karşılaştırma |
| 266 | `assert sig["n_ruptures"] == 2` | karşılaştırma |

### `tests/unit/test_gorev2_depth_engine.py` — 57 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `assert res["n_texts"] == 2` | karşılaştırma |
| 36 | `assert res["n_themes"] == 1` | karşılaştırma |
| 38 | `assert res["repetition_score"] == 1.0` | karşılaştırma |
| 39 | `assert res["isolated_anomaly_count"] == 0` | karşılaştırma |
| 47 | `assert res["n_themes"] == 2` | karşılaştırma |
| 48 | `assert res["repetition_score"] == 0.5` | karşılaştırma |
| 50 | `assert res["isolated_anomaly_count"] == 2` | karşılaştırma |
| 59 | `assert res["n_themes"] == 2` | karşılaştırma |
| 60 | `assert res["repetition_score"] == 0.667` | karşılaştırma |
| 62 | `assert res["themes"][1]["size"] == 1` | karşılaştırma |
| 68 | `assert cluster_texts([])["n_themes"] == 0` | karşılaştırma |
| 69 | `assert cluster_texts([])["repetition_score"] == 0.0` | karşılaştırma |
| 70 | `assert cluster_texts(["", "  ", None, 123])["n_texts"] == 0` | karşılaştırma |
| 71 | `assert cluster_texts(["tek"])["n_themes"] == 1` | karşılaştırma |
| 72 | `assert THEME_SIM_THRESHOLD == 0.30` | karşılaştırma |
| 99 | `assert traj["n"] == 6` | karşılaştırma |
| 105 | `assert jump["magnitude"] > 0.5` | karşılaştırma |
| 115 | `assert traj["var_ratio"] > 3.0` | karşılaştırma |
| 116 | `assert traj["entropy_jump"] == 0.0` | karşılaştırma |
| 123 | `assert three["n"] == 3` | karşılaştırma |
| 125 | `assert "n<4" in three["note"]` | karşılaştırma |
| 140 | `assert eng["like_mean_first"] == 20.0` | karşılaştırma |
| 141 | `assert eng["like_mean_second"] == 50.0` | karşılaştırma |
| 142 | `assert eng["like_shift_ratio"] == 2.5` | karşılaştırma |
| 152 | `assert res["samples"] == 4` | karşılaştırma |
| 153 | `assert res["night_share"] == 0.75` | karşılaştırma |
| 154 | `assert res["trajectory"]["n"] == 4` | karşılaştırma |
| 199 | `assert all(0.0 <= ch[k] <= 1.0 for k in ("intensity", "coherence", "completeness"))` | karşılaştırma |
| 202 | `assert rep["confidence"] > 0.0` | karşılaştırma |
| 206 | `assert matrix[i][i] == 0.0` | karşılaştırma |
| 209 | `assert 0.0 <= matrix[i][j] <= 1.0` | karşılaştırma |
| 210 | `assert 0.0 <= rep["compensation_index"] <= 1.0` | karşılaştırma |
| 211 | `assert 0.0 <= rep["reaction_formation_index"] <= 1.0` | karşılaştırma |
| 213 | `assert rep["channels"]["declaration"]["signals"]["n_texts"] == 3` | karşılaştırma |
| 229 | `assert rep["epistemic_weights"]["w_declaration"] == 0.0` | karşılaştırma |
| 230 | `assert rep["confidence"] > 0.0` | karşılaştırma |
| 232 | `assert rep["channels"]["declaration"]["completeness"] == 0.0` | karşılaştırma |
| 243 | `assert weights["w_declaration"] == 0.0` | karşılaştırma |
| 244 | `assert weights["w_social"] == 0.0` | karşılaştırma |
| 252 | `assert rep["confidence"] == 0.0` | karşılaştırma |
| 253 | `assert all(w == 0.0 for w in rep["epistemic_weights"].values())` | karşılaştırma |
| 264 | `assert rep["confidence"] == 0.0` | karşılaştırma |
| 281 | `assert rep["confidence"] > 0.0` | karşılaştırma |
| 283 | `assert rhythm["n_ruptures"] == 0` | karşılaştırma |
| 294 | `assert rep["channels"]["rhythm"]["signals"]["n_ruptures"] == 0` | karşılaştırma |
| 306 | `assert profile.machiavellianism == 0.0` | karşılaştırma |
| 307 | `assert profile.narcissism == 0.0` | karşılaştırma |
| 308 | `assert profile.psychopathy == 0.0` | karşılaştırma |
| 309 | `assert profile.exploitability == 0.0` | karşılaştırma |
| 310 | `assert profile.theme_analysis["n_texts"] == 3` | karşılaştırma |
| 311 | `assert profile.theme_analysis["n_themes"] == 2` | karşılaştırma |
| 318 | `assert analyzer.analyze({}).theme_analysis["n_texts"] == 0` | karşılaştırma |
| 319 | `assert analyzer.analyze({"posts": "tek metin", "bio": ""}).theme_analysis["n_texts"] == 1` | karşılaştırma |
| 326 | `assert analyzer.generate_strategy(DarkTriadProfile(narcissism=0.8))["vector"] == "mirroring"` | parametre |
| 327 | `assert analyzer.generate_strategy(DarkTriadProfile(machiavellianism=0.7))["vector"] == "alliance"` | parametre |
| 328 | `assert analyzer.generate_strategy(DarkTriadProfile(psychopathy=0.6))["vector"] == "thrill"` | parametre |
| 329 | `assert analyzer.generate_strategy(DarkTriadProfile(narcissism=0.2))["vector"] == "unobserved"` | parametre |

### `tests/unit/test_graph_faz_b.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 53 | `assert graph.edge_count > 0` | karşılaştırma |
| 90 | `assert graph.node_count == 0` | karşılaştırma |
| 99 | `assert graph.node_count <= 10` | karşılaştırma |
| 160 | `assert r.status_code == 200` | karşılaştırma |
| 163 | `assert body["node_count"] >= 2` | karşılaştırma |
| 179 | `assert r.status_code == 400` | karşılaştırma |

### `tests/unit/test_health_degraded.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 10 | `- PINEAL_ENV=production + OPENROUTER_MAX_SPEND_USD=5 → spend_cap_unlimited: false` | parametre |
| 29 | `assert r.status_code == 200` | karşılaştırma |
| 43 | `assert r.status_code == 200` | karşılaştırma |
| 55 | `assert r.status_code == 503` | karşılaştırma |
| 64 | `assert r.status_code == 503` | karşılaştırma |
| 89 | `"""production + spend_cap > 0 → SPEND_CAP_UNLIMITED degraded_reasons'a girmez."""` | karşılaştırma |
| 114 | `assert r.status_code == 200` | karşılaştırma |

### `tests/unit/test_hindsight_memory.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 32 | `if vec[0] == 0.0 and vec[1] == 0.0:` | karşılaştırma |
| 66 | `assert data["evidence"][0]["target_authentic_vector"]["depth"] == 0.8` | karşılaştırma |
| 99 | `assert 0.0 <= results[0]["similarity"] <= 1.0` | karşılaştırma |
| 121 | `assert mem.get_task_memory("t")["evidence"][0]["x"] == 1` | karşılaştırma |

### `tests/unit/test_holehe_scanner.py` — 24 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 90 | `site_timeout=5,` | parametre |
| 95 | `assert res.scanned_count == 2` | karşılaştırma |
| 96 | `assert res.error_count == 0` | karşılaştırma |
| 179 | `site_timeout=5,` | parametre |
| 181 | `assert res.error_count == 1` | karşılaştırma |
| 182 | `assert res.scanned_count == 2` | karşılaştırma |
| 195 | `site_timeout=5,` | parametre |
| 200 | `assert res.error_count == res.scanned_count == 3` | karşılaştırma |
| 210 | `assert scanned == 1` | karşılaştırma |
| 211 | `assert errors == 1` | karşılaştırma |
| 220 | `assert scanned == 2` | karşılaştırma |
| 221 | `assert errors == 1` | karşılaştırma |
| 230 | `site_timeout=5,` | parametre |
| 235 | `assert res.error_count == 0` | karşılaştırma |
| 264 | `profile = self._profile(associated_platforms=["GitHub"], confidence=0.5)` | parametre |
| 270 | `assert merged.confidence == 0.5  # 1/10 kapsama mevcut 0.5'in altında -> ezilmez` | karşılaştırma |
| 273 | `assert merged.email_scan_sealed == 1` | karşılaştırma |
| 280 | `scan = _res(available=True, found=[], scanned=8, errors=0)` | parametre |
| 286 | `assert merged.confidence == 0.0` | karşılaştırma |
| 292 | `scan = _res(available=False, reason="provider_errors", scanned=8, errors=8)` | parametre |
| 316 | `assert r.status_code == 400` | karşılaştırma |
| 328 | `scan = _res(available=False, reason="provider_errors", scanned=5, errors=5)` | parametre |
| 334 | `assert r.status_code == 200` | karşılaştırma |
| 338 | `assert body["error_count"] == 5` | karşılaştırma |

### `tests/unit/test_human_behavior.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 37 | `MicroSignal(signal_type="tension", confidence=0.8, location="a", evidence="e", psychological_weight=0.5)` | parametre |
| 42 | `MicroSignal(signal_type="defense", confidence=0.8, location="b", evidence="e", psychological_weight=0.5),` | parametre |
| 43 | `MicroSignal(signal_type="contradiction", confidence=0.8, location="c", evidence="evid", psychological_weight=0.8)` | parametre |
| 59 | `MicroSignal(signal_type="x", confidence=0.8, location="b", evidence="e", psychological_weight=0.5)` | parametre |
| 65 | `assert score == 35.0` | karşılaştırma |
| 108 | `mock_var.var.return_value = 50.0` | parametre |
| 150 | `confidence=0.8,` | parametre |
| 152 | `achilles_score=10.0,` | parametre |
| 153 | `resonance_potential=0.5,` | parametre |

### `tests/unit/test_human_behavior_evidence_contract.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 45 | `confidence=0.8,` | parametre |
| 48 | `signal_type="defense", confidence=0.9, location="linguistic",` | parametre |
| 49 | `evidence="'Sadece' kelimesi tespiti", psychological_weight=0.8,` | parametre |
| 52 | `achilles_score=42.0,` | parametre |
| 53 | `resonance_potential=0.7,` | parametre |
| 84 | `assert result.achilles_score == 0.0` | karşılaştırma |
| 95 | `assert result.achilles_score == 42.0` | karşılaştırma |

### `tests/unit/test_instagram_ghost_captions.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 33 | `+ '"shortcode":"DefGhi_1","display_url":"https://scontent/1.jpg\\u0026se=7",'` | parametre |
| 44 | `assert post.display_url == "https://scontent/1.jpg&se=7"` | parametre |
| 66 | `assert req_pos != -1, "requirements.txt kurulum satırı kayıp"` | karşılaştırma |
| 67 | `assert osint_pos != -1, "OSINT yığını launcher'dan hiç kurulmuyor"` | karşılaştırma |
| 68 | `assert browser_pos != -1, "Playwright chromium launcher'dan kurulmuyor"` | karşılaştırma |

### `tests/unit/test_inventory_page.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 56 | `assert proc.returncode == 0, (` | karşılaştırma |
| 132 | `dupes = [p for p, n in Counter(paths).items() if n > 1]` | karşılaştırma |

### `tests/unit/test_jury_consensus_faz_b.py` — 14 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `assert audit.seats == 3` | karşılaştırma |
| 45 | `assert audit.counted == 3` | karşılaştırma |
| 67 | `assert audit.counted == 0` | karşılaştırma |
| 83 | `assert audit.quorum_required == 3` | karşılaştırma |
| 117 | `assert summary.claims_audited == 2` | karşılaştırma |
| 118 | `assert summary.mismatches == 1` | karşılaştırma |
| 120 | `assert summary.single_seat_claims == 0` | karşılaştırma |
| 121 | `assert 0.0 <= summary.mean_strength <= 1.0` | karşılaştırma |
| 127 | `assert summary.claims_audited == 0` | karşılaştırma |
| 128 | `assert summary.mismatches == 0` | karşılaştırma |
| 178 | `assert report.consensus["claims_audited"] >= 1` | karşılaştırma |
| 179 | `assert report.consensus["mismatches"] == 0` | karşılaştırma |
| 204 | `assert report.consensus["quorum_met_claims"] == 0` | karşılaştırma |
| 208 | `assert report.unknown_claims >= 1` | karşılaştırma |

### `tests/unit/test_language_capabilities.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 83 | `assert item.scope["confidence"] >= 0.5` | karşılaştırma |
| 163 | `assert scope["language_confidence"] >= 0.5` | karşılaştırma |

### `tests/unit/test_language_detect.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 67 | `assert finding.confidence >= 0.85  # temiz metin: yüksek ama dürüst` | karşılaştırma |
| 84 | `assert finding.confidence == 0.0` | karşılaştırma |
| 119 | `assert finding.confidence <= 0.60  # marj küçük: güven ŞİŞİRİLMEZ` | karşılaştırma |
| 124 | `assert finding.confidence <= 0.75  # 3 sözcük 0.99 olamaz` | karşılaştırma |
| 129 | `assert 0.5 <= conf <= 0.99` | karşılaştırma |

### `tests/unit/test_lilith_growth.py` — 30 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 61 | `assert result.confidence == 0.95` | karşılaştırma |
| 63 | `assert result.neurochemical_profile.dopamine_potential >= 0.05` | karşılaştırma |
| 65 | `assert 0.0 <= result.neuro_metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 81 | `assert pkg.confidence == 0.5` | karşılaştırma |
| 86 | `assert pkg.neuro_metrics.viral_coefficient_score > 0.0` | karşılaştırma |
| 116 | `assert 0.0 <= result.neuro_metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 127 | `dopamine=0.95, serotonin=0.90, cortisol=0.70, oxytocin=0.60, cognitive_friction=0.20` | parametre |
| 129 | `assert metrics.viral_coefficient_score > 5.0` | karşılaştırma |
| 135 | `dopamine=0.30, serotonin=0.40, cortisol=0.98, oxytocin=0.20, cognitive_friction=0.50` | parametre |
| 145 | `assert 0.5 <= metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 146 | `assert 0.0 <= metrics.pattern_interrupt_index <= 1.0` | karşılaştırma |
| 147 | `assert 0.0 <= metrics.cognitive_dissonance_score <= 1.0` | karşılaştırma |
| 152 | `assert metrics.viral_coefficient_score > 0.0` | karşılaştırma |
| 163 | `assert 0.5 <= metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 175 | `assert 0.5 <= metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 179 | `dopamine=999.0, serotonin=999.0, cortisol=999.0, oxytocin=999.0,` | parametre |
| 180 | `cognitive_friction=0.0001,` | parametre |
| 182 | `assert metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 187 | `dopamine_potential=5.0,` | parametre |
| 188 | `serotonin_status_currency=-3.0,` | parametre |
| 192 | `assert 0.0 <= chem.dopamine_potential <= 1.0` | karşılaştırma |
| 193 | `assert 0.0 <= chem.serotonin_status_currency <= 1.0` | karşılaştırma |
| 194 | `assert 0.0 <= chem.cortisol_urgency <= 1.0` | karşılaştırma |
| 195 | `assert 0.0 <= chem.oxytocin_affinity <= 1.0` | karşılaştırma |
| 198 | `viral_coefficient_score=999.0,` | parametre |
| 199 | `pattern_interrupt_index=-1.0,` | parametre |
| 200 | `cognitive_dissonance_score=2.0,` | parametre |
| 203 | `assert 0.0 <= metrics.viral_coefficient_score <= 10.0` | karşılaştırma |
| 204 | `assert 0.0 <= metrics.pattern_interrupt_index <= 1.0` | karşılaştırma |
| 205 | `assert 0.0 <= metrics.cognitive_dissonance_score <= 1.0` | karşılaştırma |

### `tests/unit/test_llm_call_observability.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 63 | `confidence=0.9,` | parametre |

### `tests/unit/test_llm_gateway.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 78 | `assert gateway.spend_usd == 0.0` | karşılaştırma |
| 110 | `gateway.spend_cap_usd = 10.0` | parametre |
| 112 | `assert gateway.budget_status()["active_reservations"] == 1` | karşılaştırma |
| 114 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 115 | `assert gateway.budget_status()["reserved_usd"] == 0` | karşılaştırma |
| 121 | `gateway.spend_usd = 0.9` | parametre |
| 124 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |

### `tests/unit/test_local_jury.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 48 | `if outer.status >= 400:` | karşılaştırma |
| 218 | `assert verdict.counted == 2` | karşılaştırma |
| 238 | `assert verdict.counted == 2` | karşılaştırma |
| 252 | `stub = _LocalLLM({}, status=500)` | parametre |
| 265 | `assert verdict.counted == 2 and verdict.consensus is True` | karşılaştırma |

### `tests/unit/test_maigret_db_env.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 67 | `assert res.db_sites == 3` | karşılaştırma |
| 68 | `assert res.scanned_count == 3` | karşılaştırma |
| 82 | `assert res.db_sites == 1` | karşılaştırma |
| 112 | `assert res.db_sites == 0` | karşılaştırma |
| 127 | `res1 = await maigret_scanner.scan_username("soxoj", limit=5)` | parametre |
| 128 | `assert res1.db_sites == 1` | karşılaştırma |
| 131 | `res2 = await maigret_scanner.scan_username("soxoj", limit=5)` | parametre |
| 132 | `assert res2.db_sites == 2  # bayat önbellekle 1 dönmedi` | karşılaştırma |
| 164 | `assert result.notes["db_sites"] == 1` | karşılaştırma |

### `tests/unit/test_maigret_db_refresh.py` — 30 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 43 | `assert stats.added == 1` | karşılaştırma |
| 64 | `assert stats.skipped == 1` | karşılaştırma |
| 65 | `assert stats.skip_reasons["unsupported_mode"] == 1` | karşılaştırma |
| 66 | `assert stats.added == 0` | karşılaştırma |
| 72 | `assert stats.skipped == 1` | karşılaştırma |
| 73 | `assert stats.skip_reasons["empty_url"] == 1` | karşılaştırma |
| 92 | `assert stats.filled == 1` | karşılaştırma |
| 93 | `assert stats.added == 0` | karşılaştırma |
| 107 | `assert stats.unchanged == 1` | karşılaştırma |
| 108 | `assert stats.filled == 0` | karşılaştırma |
| 109 | `assert stats.added == 0` | karşılaştırma |
| 121 | `assert stats.candidates == 1` | karşılaştırma |
| 122 | `assert stats.added == 1` | karşılaştırma |
| 158 | `assert stats.candidates == 1` | karşılaştırma |
| 159 | `assert stats.added == 1` | karşılaştırma |
| 180 | `assert stats.added == 1` | karşılaştırma |
| 191 | `assert stats.skipped == 1` | karşılaştırma |
| 192 | `assert stats.skip_reasons["unsupported_mode"] == 1` | karşılaştırma |
| 198 | `assert stats.skip_reasons["empty_url"] == 1` | karşılaştırma |
| 206 | `assert stats.skip_reasons["no_site_name"] == 1` | karşılaştırma |
| 211 | `assert stats.filled == 1` | karşılaştırma |
| 293 | `assert report.base_sites == 2` | karşılaştırma |
| 294 | `assert report.final_sites == 4  # GitHub, Meccut, YeniSherlock, YeniWmn` | karşılaştırma |
| 296 | `assert report.sherlock.added == 1` | karşılaştırma |
| 297 | `assert report.sherlock.filled == 1  # GitHub urlMain doldu` | karşılaştırma |
| 298 | `assert report.sherlock.skipped == 1` | karşılaştırma |
| 300 | `assert report.wmn.added == 1` | karşılaştırma |
| 301 | `assert report.wmn.filled == 1  # Meccut alanları doldu` | karşılaştırma |
| 320 | `assert rc == 0` | karşılaştırma |
| 325 | `assert report["final_sites"] == 2` | karşılaştırma |

### `tests/unit/test_maigret_scanner.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 75 | `assert res.scanned_count == 2` | karşılaştırma |
| 111 | `assert res.error_count == 2` | karşılaştırma |
| 112 | `assert res.scanned_count == 2` | karşılaştırma |
| 194 | `assert res.error_count == 2` | karşılaştırma |
| 220 | `assert res.scanned_count == 2` | karşılaştırma |
| 251 | `assert profile.confidence == 0.1  # 1/10 gözlenen kapsama` | karşılaştırma |
| 254 | `assert profile.username_scan_sealed == 1` | karşılaştırma |
| 271 | `scan = _res(available=True, found=[], scanned=8, errors=0)` | parametre |
| 275 | `assert profile.confidence == 0.0` | karşılaştırma |
| 294 | `assert r.status_code == 400` | karşılaştırma |

### `tests/unit/test_mcp_protocol.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `assert msg["id"] == 7 and msg["method"] == "tools/list"` | karşılaştırma |
| 57 | `assert err["id"] == 3` | karşılaştırma |

### `tests/unit/test_mcp_results.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 6 | `resultType = 2026-07-28).` | parametre |
| 23 | `confidence=0.62,` | parametre |
| 30 | `duration_ms=42,` | parametre |
| 46 | `assert structured["evidence_count"] == 1` | karşılaştırma |
| 49 | `assert structured["duration_ms"] == 42` | karşılaştırma |
| 117 | `assert rendered["structuredContent"]["evidence_count"] == 60` | karşılaştırma |

### `tests/unit/test_mcp_server.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 33 | `mcp_server, "vault_state", lambda client_id="default", *, env=None, timeout=2.0: (False, "")` | parametre |
| 43 | `lambda client_id="default", *, env=None, timeout=2.0: (True, "vault_api_unreachable:URLError"),` | parametre |
| 99 | `assert result["ttlMs"] > 0 and result["cacheScope"] == "public"` | karşılaştırma |
| 156 | `assert structured["evidence_count"] == 0` | karşılaştırma |
| 171 | `assert structured["evidence_count"] == 1` | karşılaştırma |
| 253 | `assert structured["evidence_count"] == 0` | karşılaştırma |

### `tests/unit/test_mcp_state_bridge.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 106 | `assert api.hits == 1` | karşılaştırma |
| 137 | `api = _StubAPI('{"locked": false}', status=500)` | parametre |
| 144 | `api = _StubAPI("", status=302, location="https://uzak.example.com/status")` | parametre |
| 156 | `assert api.hits == 1  # bayat cevapla uzun süre koşulmaz ama her çağrıda da sorulmaz` | karşılaştırma |
| 165 | `assert api.hits == 2` | karşılaştırma |
| 202 | `assert limiter.allow("t", now=2.0) is False  # kota doldu` | parametre |
| 203 | `assert limiter.allow("t", now=11.5) is True  # pencere kaydı` | parametre |
| 213 | `assert limiter.limit == 3 and limiter.window == 5.0` | karşılaştırma |
| 217 | `assert limiter.limit == 20 and limiter.window == 60.0` | karşılaştırma |
| 265 | `api = _StubAPI('{"locked": false}', delay=0.8)` | parametre |
| 269 | `env={"PINEAL_API_URL": api.url}, timeout=0.15` | parametre |

### `tests/unit/test_media_forensics.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `value = 220 if (x // 8) % 2 == 0 else 40` | parametre |
| 46 | `value = 220 if ((x - 80) ** 2 + (y - 60) ** 2) < 1600 else 40` | parametre |
| 57 | `def _make_video(path, *, pixel_format="mp4v", fps=10.0, frames=30, switch_at=15):` | parametre |
| 124 | `assert len(fetched.sha256) == 64 and fetched.bytes > 0` | karşılaştırma |
| 184 | `assert analysis.fps == pytest.approx(10.0, abs=0.5)` | parametre |
| 185 | `assert analysis.frames >= 29` | karşılaştırma |
| 186 | `assert analysis.width == 320 and analysis.height == 240` | karşılaştırma |
| 187 | `assert analysis.brightness_mean == pytest.approx(110, abs=15)` | parametre |
| 189 | `assert 1.0 <= analysis.scenes[0] <= 2.0` | karşılaştırma |
| 196 | `assert analysis.dominant_color == pytest.approx((200, 30, 30), abs=6)` | parametre |
| 285 | `result = mf.visual_similarity(str(near), top_k=5)` | parametre |
| 287 | `assert result.index_size >= 3` | karşılaştırma |

### `tests/unit/test_memory_crystal_faz_b.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 63 | `assert again.fragments[0].seen_count == 2` | karşılaştırma |
| 64 | `assert again.fragments[0].weight > 1.0` | karşılaştırma |
| 108 | `assert top["similarity"] > 0` | karşılaştırma |
| 173 | `assert payload["fragment_count"] == 1` | karşılaştırma |
| 174 | `assert payload["task_count"] == 1` | karşılaştırma |
| 248 | `assert response.status_code == 200` | karşılaştırma |
| 253 | `assert body["fragment_count"] == 0` | karşılaştırma |
| 275 | `assert response.status_code == 400` | karşılaştırma |

### `tests/unit/test_message_decision_context.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 80 | `assert limited.excluded_counts["item_limit"] == 1` | karşılaştırma |
| 113 | `confidence=0.8,` | parametre |
| 114 | `compliance_score=100.0,` | parametre |

### `tests/unit/test_minor_gate_api.py` — 17 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 191 | `if minor_at < 0:` | karşılaştırma |
| 193 | `if vault_at >= 0 and minor_at > vault_at:` | karşılaştırma |
| 238 | `assert r.status_code == 451, f"{path} beyanlı odada {r.status_code} döndü: {r.text[:200]}"` | karşılaştırma |
| 276 | `assert r.status_code == 451, f"{path} → {r.status_code}: {r.text[:200]}"` | karşılaştırma |
| 304 | `assert blocked.status_code == 451` | karşılaştırma |
| 326 | `assert blocked is not None and blocked.status_code == 451` | karşılaştırma |
| 329 | `assert r.status_code == 451` | karşılaştırma |
| 398 | `assert r.status_code != 451, f"{path} onaylı vakada 451 döndü: {r.text[:200]}"` | karşılaştırma |
| 399 | `if r.status_code == 200:` | karşılaştırma |
| 422 | `assert r.status_code == 451, f"çocuk kapısı kasa kapısının arkasında kaldı: {r.status_code}"` | karşılaştırma |
| 435 | `assert r.status_code != 451, "kapatma engellendi: zombi tarayıcı riski"` | karşılaştırma |
| 454 | `assert r.status_code == 200, r.text[:200]` | karşılaştırma |
| 462 | `assert r2.status_code == 451` | karşılaştırma |
| 484 | `assert r.status_code == 451, f"{path} beyan varken {r.status_code} döndü"` | karşılaştırma |
| 499 | `assert r.status_code != 451, f"{path} beyansız 451 döndü: {r.text[:200]}"` | karşılaştırma |
| 572 | `assert r.status_code == 503` | karşılaştırma |
| 584 | `assert r.status_code == 400` | karşılaştırma |

### `tests/unit/test_model_chains.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 47 | `assert call_count >= 2` | karşılaştırma |
| 66 | `assert call_count == 1, "AUTH hatasında sıradaki modele düşülmemeli, hemen yükseltilmeli"` | karşılaştırma |
| 80 | `return SampleSchema(title=f"Başarı: {model}", score=0.95)` | parametre |
| 87 | `assert call_count >= 2` | karşılaştırma |
| 93 | `reality_index=0.85,` | parametre |
| 106 | `assert report.reality_index == 0.85` | karşılaştırma |
| 140 | `resonance_score=0.9,` | parametre |
| 152 | `assert res.resonance_score == 0.9` | karşılaştırma |

### `tests/unit/test_multi_provider_routing.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 259 | `async def fake_query_json(prompt=None, schema=None, temperature=0.7, tier=1,` | parametre |

### `tests/unit/test_no_decision_run_status.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 73 | `assert UncertaintyReport(is_suspicious=False, confidence=0.9, reason="x").no_decision is False` | parametre |
| 79 | `confidence=0.9,` | parametre |
| 88 | `assert report.confidence == 0.0` | karşılaştırma |
| 96 | `compatibility_score: float = 0.9` | parametre |
| 139 | `assert run.confidence == 0.0` | karşılaştırma |
| 155 | `compatibility_score=0.82,` | parametre |
| 161 | `domain="tutkular", state="confirmed", overlap=0.8,` | parametre |
| 181 | `assert run.confidence is not None and run.confidence >= 0.65` | karşılaştırma |
| 200 | `confidence=0.8,` | parametre |

### `tests/unit/test_no_mock_in_production.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 121 | `assert psutil.virtual_memory().total > 0          # open-interpreter` | karşılaştırma |
| 122 | `assert psutil.disk_usage("/").free > 0             # open-interpreter` | karşılaştırma |
| 123 | `assert psutil.Process().pid > 0                    # crawl4ai` | karşılaştırma |

### `tests/unit/test_no_placeholder_user_and_verifier_contract.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 112 | `assert report.confidence == 0.0` | karşılaştırma |
| 134 | `assert report.confidence == 0.0` | karşılaştırma |
| 149 | `assert report.confidence == 0.0` | karşılaştırma |
| 169 | `assert result.confidence == 0.0` | karşılaştırma |
| 171 | `assert result.alignment_score == 0.0` | karşılaştırma |

### `tests/unit/test_no_secret_leak.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 65 | `assert r.status_code == 200` | karşılaştırma |

### `tests/unit/test_osint_investigator.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `assert res.confidence == 0.0` | karşılaştırma |
| 38 | `digital_footprint_score=0.75,` | parametre |
| 40 | `confidence=0.85` | parametre |
| 54 | `assert res.digital_footprint_score == 0.0` | karşılaştırma |
| 55 | `assert res.confidence == 0.0` | karşılaştırma |
| 75 | `assert res.confidence == 0.0` | karşılaştırma |

### `tests/unit/test_p0_repairs.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 17 | `return UncertaintyReport(confidence=0.9, is_suspicious=False, reason="test")` | parametre |
| 80 | `assert report.overall_authenticity_score == 0.0` | karşılaştırma |

### `tests/unit/test_p1_1_unavailable_contract.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 15 | `assert res.confidence == 0.0` | karşılaştırma |
| 25 | `assert res.confidence == 0.0` | karşılaştırma |
| 35 | `assert res.authenticity_score == 0.0` | karşılaştırma |
| 36 | `assert res.confidence == 0.0` | karşılaştırma |
| 46 | `assert res.reality_index == 0.0` | karşılaştırma |

### `tests/unit/test_p1_5_scraper_errors.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 12 | `H. evaluate_confidence: düşük veri → score < 0.6` | karşılaştırma |
| 53 | `assert mock_page.goto.call_count == 3, (` | karşılaştırma |
| 88 | `assert call_tracker["n"] == 1, (` | karşılaştırma |
| 178 | `"""Follower ve bio yok, post yok → confidence < 0.6 (executor HALT yapmalı)."""` | karşılaştırma |
| 188 | `assert score < 0.6, f"Beklenen score < 0.6, gelen: {score}"` | karşılaştırma |
| 197 | `follower_count=1000,` | parametre |
| 202 | `assert score <= 0.4, f"Private profil max 0.4 olmalı, gelen: {score}"` | karşılaştırma |

### `tests/unit/test_parallel_llm_provenance.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `if self.attempts == 1:` | karşılaştırma |
| 128 | `assert completions.attempts == 2` | karşılaştırma |
| 131 | `assert call["attempt"] == 2` | karşılaştırma |

### `tests/unit/test_passion_mapper.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `assert res.confidence == 0.0` | karşılaştırma |
| 24 | `sentiment_polarity=0.7,` | parametre |
| 26 | `confidence=0.9` | parametre |
| 40 | `assert res.sentiment_polarity == 0.7` | karşılaştırma |
| 41 | `assert res.confidence == 0.9` | karşılaştırma |

### `tests/unit/test_pattern_interrupt_grounding.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 10 | `assert result.confidence == 0.0` | karşılaştırma |

### `tests/unit/test_pillar_evidence_adapter.py` — 39 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 42 | `intensity=8.0,` | parametre |
| 55 | `expected_presence=0.22,` | parametre |
| 56 | `actual_presence=0.03,` | parametre |
| 57 | `absence_delta=0.19,` | parametre |
| 58 | `absence_score=0.86,` | parametre |
| 70 | `energy=0.8,` | parametre |
| 72 | `mean_text_len=40,` | parametre |
| 81 | `peak_energy=0.8,` | parametre |
| 82 | `mean_energy=0.6,` | parametre |
| 88 | `PhaseShift(platform_a="example", platform_b="other", lag_hours=2.0, correlation=0.75)` | parametre |
| 90 | `energy_mean=0.5,` | parametre |
| 91 | `energy_std=0.2,` | parametre |
| 92 | `night_energy_share=0.6,` | parametre |
| 109 | `extinction_confidence=0.75,` | parametre |
| 110 | `early_presence=0.6,` | parametre |
| 111 | `late_presence=0.01,` | parametre |
| 119 | `early_value=120.0,` | parametre |
| 120 | `late_value=75.0,` | parametre |
| 121 | `drift_ratio=0.625,` | parametre |
| 128 | `evidence_refs=["strata:depth_days=60"],` | parametre |
| 135 | `mass=2.0,` | parametre |
| 136 | `density=0.5,` | parametre |
| 137 | `pull=1.25,` | parametre |
| 144 | `total_anchors_scanned=5,` | parametre |
| 152 | `value=40,` | parametre |
| 153 | `z_score=1.5,` | parametre |
| 154 | `baseline=25,` | parametre |
| 158 | `baseline_volatility=0.2,` | parametre |
| 173 | `confidence=0.5,` | parametre |
| 200 | `assert frequency.source_metrics["night_energy_share"] == 0.6` | karşılaştırma |
| 201 | `assert phase.source_metrics["correlation"] == 0.75` | karşılaştırma |
| 204 | `assert gravity.source_metrics["recurrence"] == 3` | karşılaştırma |
| 206 | `assert pulse.source_metrics["source_baseline"] == 25` | karşılaştırma |
| 223 | `assert observation.source_metrics["intensity"] == 8.0` | karşılaştırma |
| 224 | `assert observation.source_metrics["gap_hours"] == 47.0` | karşılaştırma |
| 249 | `assert absence.scope["source_count"] == 3` | karşılaştırma |
| 252 | `assert absence.source_metrics["absence_score"] == 0.86` | karşılaştırma |
| 282 | `assert fossil.source_metrics["source_extinction_confidence"] == 0.75` | karşılaştırma |
| 299 | `assert gate.source_metrics["source_key_report_confidence"] == 0.5` | karşılaştırma |

### `tests/unit/test_pillar_transport_contract.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 91 | `assert frame["psychodynamic_depth"]["confidence"] == 0.9` | karşılaştırma |

### `tests/unit/test_provider_aware_agent_chains.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 68 | `assert route.input_per_million_usd == 0.0  # ROUTES free-tier doğrulaması` | karşılaştırma |
| 114 | `async def fake_query_json(prompt=None, schema=None, temperature=0.7, tier=1,` | parametre |
| 133 | `_patch_transport(gw, attempts, lambda n, m, r: TimeoutError("408 timed out") if n < 2 else '{"ok":1}')` | karşılaştırma |

### `tests/unit/test_provider_manager.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 49 | `context_window=32_000,` | parametre |
| 100 | `assert catalog.model_count >= 7` | karşılaştırma |
| 132 | `assert catalog.model_count == 1_500` | karşılaştırma |
| 183 | `targets = manager.targets_for(required_capabilities={"tools"}, minimum_context=16_000)` | parametre |
| 193 | `remaining_fraction=0.75,` | parametre |
| 202 | `assert target.quota.remaining_fraction == 0.75` | karşılaştırma |

### `tests/unit/test_quota_governor.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 11 | `"groq": QuotaLimits(rpm=30, rpd=14_400),` | parametre |
| 12 | `"cerebras": QuotaLimits(rpm=5, tpm=30_000, tpd=1_000_000),` | parametre |
| 20 | `assert governor.limits_for("groq").rpm == 30` | karşılaştırma |
| 21 | `assert governor.limits_for("groq").rpd == 14_400` | karşılaştırma |
| 22 | `assert governor.limits_for("cerebras").rpm == 5` | karşılaştırma |
| 23 | `assert governor.limits_for("cerebras").tpm == 30_000` | karşılaştırma |
| 24 | `assert governor.limits_for("cerebras").tpd == 1_000_000` | karşılaştırma |
| 50 | `prompt_tokens=30_000,` | parametre |
| 82 | `governor.record_failure("cerebras", "gpt-oss-120b", status_code=503)` | parametre |
| 91 | `status_code=429,` | parametre |
| 101 | `QuotaLimits(rpm=-5)` | parametre |

### `tests/unit/test_report_factory.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 73 | `assert package.notes["rejected_item_count"] == 1` | karşılaştırma |
| 74 | `assert package.notes["excluded_strategy_count"] == 1` | karşılaştırma |

### `tests/unit/test_resonance.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 13 | `assert 0.0 < result < 1.0` | karşılaştırma |
| 22 | `assert result == 0.0  # Valid return for disjoint vectors` | karşılaştırma |
| 39 | `assert result == 0.0` | karşılaştırma |
| 127 | `assert result.compatibility_score > 0.0` | karşılaştırma |

### `tests/unit/test_resonance_synthesizer.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 46 | `resonance_score=0.92,` | parametre |
| 50 | `confidence=0.95,` | parametre |
| 56 | `assert gateway.query_json_chain.await_count == 1, (` | karşılaştırma |
| 71 | `gateway = _gateway(return_value=AuthenticBridge(confidence=0.9, resonance_score=0.5, suggested_opening_message="Merhaba"` | parametre |
| 76 | `assert gateway.query_json_chain.await_count == 1` | karşılaştırma |
| 82 | `gateway = _gateway(return_value=AuthenticBridge(confidence=0.9, suggested_opening_message="Merhaba"))` | parametre |
| 97 | `gateway = _gateway(return_value=AuthenticBridge(confidence=0.9))` | parametre |
| 107 | `assert result.confidence == 0.0` | karşılaştırma |
| 110 | `assert gateway.query_json_chain.await_count == 0` | karşılaştırma |
| 114 | `gateway = _gateway(return_value=AuthenticBridge(confidence=0.9))` | parametre |
| 120 | `assert gateway.query_json_chain.await_count == 0` | karşılaştırma |
| 129 | `assert result.confidence == 0.0` | karşılaştırma |

### `tests/unit/test_response_cache.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 29 | `key = cache.make_key(prompt="merhaba", model="m1", system_prompt="s", temperature=0.1)` | parametre |
| 33 | `assert cache.hits == 1 and cache.misses == 1` | karşılaştırma |
| 37 | `k1 = ResponseCache.make_key("p", model="m1", system_prompt="s", temperature=0.1)` | parametre |
| 38 | `k2 = ResponseCache.make_key("p", model="m2", system_prompt="s", temperature=0.1)` | parametre |
| 39 | `k3 = ResponseCache.make_key("p", model="m1", system_prompt="X", temperature=0.1)` | parametre |
| 40 | `k4 = ResponseCache.make_key("p", model="m1", system_prompt="s", temperature=0.9)` | parametre |
| 109 | `assert call_count == 1, "ikinci çağrı cache'ten gelmeli, ağ'a yalnızca 1 kez gidilmeli"` | karşılaştırma |
| 110 | `assert gw.cache.hits == 1` | karşılaştırma |
| 144 | `assert gw.client.chat.completions.create.await_count == 2, "vision istekleri asla cache'lenmemeli"` | karşılaştırma |
| 145 | `assert gw.cache.hits == 0` | karşılaştırma |
| 160 | `assert gw.client.chat.completions.create.await_count == 2` | karşılaştırma |

### `tests/unit/test_retina_faz_a.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 194 | `assert timeline.rejected_item_count == 0` | karşılaştırma |
| 214 | `assert summary["sealed_count"] == 1` | karşılaştırma |
| 286 | `return types.SimpleNamespace(id=42)` | parametre |
| 316 | `assert series[0]["like_count"] == 3` | karşılaştırma |
| 351 | `like_count = 5` | parametre |
| 359 | `following_count = 50` | parametre |
| 361 | `media_count = 12` | parametre |

### `tests/unit/test_retina_faz_a_wiring.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 103 | `assert profile["posts_meta"][0]["like_count"] == 3` | karşılaştırma |

### `tests/unit/test_room_ownership_idor.py` — 9 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 154 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 158 | `assert stolen.status_code == 403, stolen.text` | karşılaştırma |
| 173 | `assert r.status_code == 403, f"{path} -> {r.status_code} {r.text}"` | karşılaştırma |
| 190 | `assert hijack.status_code == 403, hijack.text` | karşılaştırma |
| 196 | `assert status.status_code == 200` | karşılaştırma |
| 211 | `assert destroyed.status_code == 403, destroyed.text` | karşılaştırma |
| 220 | `"client_id": room, "api_key": "sk-or-v1-alice-real-key"}).status_code == 200` | karşılaştırma |
| 223 | `assert r.status_code == 200, f"{path} -> {r.status_code} {r.text}"` | karşılaştırma |
| 228 | `assert r.status_code == 401` | karşılaştırma |

### `tests/unit/test_routing_cost_firewall.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 93 | `assert state["calls"] == 0, "paid route must never reach the network without permission"` | karşılaştırma |
| 107 | `assert state["calls"] == 1` | karşılaştırma |
| 122 | `assert state["calls"] == 1` | karşılaştırma |
| 146 | `assert state["calls"] == 1` | karşılaştırma |
| 193 | `status_code = 429` | parametre |

### `tests/unit/test_routing_hardening.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 147 | `assert health and "groq" in health and health["groq"] > 0` | karşılaştırma |
| 188 | `err.status_code = 401` | parametre |
| 248 | `assert checked >= 3, "guard hicbir cift-fiyatli rota gormedi — katalog mu degisti?"` | karşılaştırma |
| 274 | `assert "SAĞLIK: groq cooldown=42s" in digest` | parametre |

### `tests/unit/test_routing_shadows.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 49 | `[sys.executable, str(SCRIPT), "--check"], cwd=ROOT, capture_output=True, text=True, timeout=120` | parametre |
| 51 | `assert proc.returncode == 0, f"--check red:\n{proc.stdout}\n{proc.stderr}"` | karşılaştırma |
| 56 | `gen = subprocess.run([sys.executable, str(SCRIPT)], cwd=ROOT, capture_output=True, text=True, timeout=120)` | parametre |
| 57 | `assert gen.returncode == 0, gen.stderr` | karşılaştırma |
| 59 | `[sys.executable, str(SCRIPT), "--check"], cwd=ROOT, capture_output=True, text=True, timeout=120` | parametre |
| 61 | `assert chk.returncode == 0, f"üretim sonrası --check red:\n{chk.stdout}\n{chk.stderr}"` | karşılaştırma |
| 100 | `assert snapshot["schema_version"] == 1` | karşılaştırma |

### `tests/unit/test_rust_runtime_status.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 35 | `assert health.status_code == 200` | karşılaştırma |
| 37 | `assert telemetry.status_code == 200` | karşılaştırma |

### `tests/unit/test_scraper_temporal_detail.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 147 | `assert detail["taken_at"].year == 2024` | karşılaştırma |
| 148 | `assert detail["taken_at"].month == 5` | karşılaştırma |
| 149 | `assert detail["taken_at"].day == 1` | karşılaştırma |
| 150 | `assert detail["like_count"] == 45` | karşılaştırma |
| 151 | `assert detail["comment_count"] == 3` | karşılaştırma |
| 191 | `assert profile.posts[0].taken_at.year == 2024` | karşılaştırma |
| 192 | `assert profile.posts[0].like_count == 45` | karşılaştırma |
| 193 | `assert profile.posts[0].comment_count == 3` | karşılaştırma |
| 256 | `follower_count=1000, posts=posts,` | parametre |
| 268 | `"""Mevcut sozlesmeler: tarihsiz guclu >= 0.6, zayif < 0.6, private <= 0.4."""` | karşılaştırma |
| 272 | `assert undated >= 0.6` | karşılaştırma |

### `tests/unit/test_security_hardening.py` — 8 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 41 | `assert response.status_code == 200` | karşılaştırma |
| 100 | `assert response.status_code == 200` | karşılaştırma |
| 117 | `assert denied.status_code == 401` | karşılaştırma |
| 118 | `assert allowed.status_code == 200` | karşılaştırma |
| 135 | `assert raised.value.code == 1008` | karşılaştırma |
| 182 | `assert response.status_code == 200` | karşılaştırma |
| 282 | `assert first.status_code == 200` | karşılaştırma |
| 283 | `assert second.status_code == 429` | karşılaştırma |

### `tests/unit/test_security_isolation.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 53 | `assert locked.status_code == 423` | karşılaştırma |
| 59 | `assert resp.status_code == 403` | karşılaştırma |

### `tests/unit/test_shadow_evidence_gate.py` — 3 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 22 | `assert result.confidence == 0.0` | karşılaştırma |
| 54 | `lambda profile_data: DarkTriadProfile(narcissism=0.8),` | parametre |
| 79 | `lambda profile_data: DarkTriadProfile(narcissism=0.8),` | parametre |

### `tests/unit/test_spectrum_faz_b.py` — 15 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 29 | `def _sine(period: float, n: int = 32, amplitude: float = 1.0) -> list[float]:` | parametre |
| 33 | `def _spike_train(period_days: int, days: int = 28, spike: int = 5) -> dict:` | parametre |
| 40 | `count = spike if day % period_days == 0 else 1` | karşılaştırma |
| 51 | `analysis = analyze_spectrum(_sine(period), bucket_hours=24)` | parametre |
| 53 | `assert analysis.dominant_period_days == pytest.approx(period, abs=0.05)` | parametre |
| 60 | `assert report.dominant_period_days == pytest.approx(7.0, abs=0.3)` | parametre |
| 68 | `analysis = analyze_spectrum(_sine(1.0) if False else _spike_series_energy(), bucket_hours=24)` | parametre |
| 71 | `assert analysis.dominant_period_days == pytest.approx(7.0, abs=0.3)` | parametre |
| 72 | `assert analysis.dominant_harmonic == 4  # 28 kova / 7 gün` | karşılaştırma |
| 86 | `assert MIN_SAMPLES == 8` | karşılaştırma |
| 100 | `assert analysis.sample_count == 0` | karşılaştırma |
| 132 | `analysis = analyze_spectrum(_sine(8.0, n=32))` | parametre |
| 140 | `analysis = analyze_spectrum(_sine(5.0, n=32), top_k=3)` | parametre |
| 142 | `assert all(0.0 <= p.power_share <= 1.0 for p in analysis.peaks)` | karşılaştırma |
| 150 | `payload = to_payload(analyze_spectrum(_sine(6.0, n=32)))` | parametre |

### `tests/unit/test_speech_faz_c.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 30 | `def _wav(seconds: float = 1.5, rate: int = 8000) -> bytes:` | parametre |
| 107 | `assert payload["duration_ms"] == 1500, "süre WAV başlığından okunmadı"` | karşılaştırma |

### `tests/unit/test_speech_report_faz_c.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 135 | `bytes=2048,` | parametre |
| 136 | `duration_ms=1000,` | parametre |

### `tests/unit/test_spend_cap.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 27 | `gw.max_spend_usd = 0.02` | parametre |
| 33 | `assert gw.total_cost > 0` | karşılaştırma |
| 36 | `assert create.await_count == 1` | karşılaştırma |
| 47 | `gw.total_cost = 99.0` | parametre |

### `tests/unit/test_streaming_settlement.py` — 12 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 18 | `input_per_million_usd=0.20,` | parametre |
| 19 | `output_per_million_usd=1.15,` | parametre |
| 65 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 88 | `assert gateway.budget_status()["active_reservations"] == 1` | karşılaştırma |
| 91 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 93 | `assert gateway.spend_usd > 0.0` | karşılaştırma |
| 96 | `assert records[-1]["cost_usd"] > 0.0` | karşılaştırma |
| 114 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 118 | `assert gateway.spend_usd > 0.0` | karşılaştırma |
| 135 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |
| 138 | `assert gateway.spend_usd > 0.0` | karşılaştırma |
| 163 | `assert gateway.budget_status()["active_reservations"] == 0` | karşılaştırma |

### `tests/unit/test_task_executor_import_purity.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 65 | `timeout=180,` | parametre |
| 72 | `assert result.returncode == 0, (` | karşılaştırma |
| 86 | `assert result.returncode == 0, (` | karşılaştırma |
| 100 | `f"beklenen >=12 ajan, gelen: {len(executor.agents)}"` | karşılaştırma |
| 105 | `assert result.returncode == 0, (` | karşılaştırma |

### `tests/unit/test_task_lifecycle.py` — 10 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 58 | `assert first.envelope.sequence == 1` | karşılaştırma |
| 61 | `assert next_event.envelope.sequence == 2` | karşılaştırma |
| 62 | `assert lifecycle.metrics()["duplicate_events"] == 1` | karşılaştırma |
| 85 | `assert lifecycle.metrics()["rejected_terminal_events"] == 1` | karşılaştırma |
| 86 | `assert lifecycle.metrics()["rejected_terminal_mutations"] == 1` | karşılaştırma |
| 98 | `duration_ms=12,` | parametre |
| 104 | `assert first.envelope.sequence == 1` | karşılaştırma |
| 193 | `assert response["telemetry_delivery"]["dropped_event_count"] == 2` | karşılaştırma |
| 214 | `heartbeat_interval=0.01,` | parametre |
| 236 | `heartbeat_interval=0.01,` | parametre |

### `tests/unit/test_task_ownership.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 107 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 159 | `assert destroyed.status_code == 403, destroyed.text` | karşılaştırma |
| 175 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 191 | `assert r.status_code == 403` | karşılaştırma |
| 225 | `assert r.status_code == 404` | karşılaştırma |
| 329 | `assert r.status_code == 200, r.text` | karşılaştırma |
| 360 | `assert own.status_code == 200` | karşılaştırma |
| 365 | `assert stolen.status_code == 403, stolen.text` | karşılaştırma |
| 373 | `assert _declare_minor(client, ALICE_ROOM, ALICE_TOKEN).status_code == 200` | karşılaştırma |
| 380 | `assert attack.status_code == 403, attack.text` | karşılaştırma |
| 393 | `assert attack.status_code == 403, attack.text` | karşılaştırma |
| 407 | `assert _declare_minor(client, ALICE_ROOM, ALICE_TOKEN).status_code == 200` | karşılaştırma |
| 415 | `assert cleared.status_code == 200 and cleared.json()["cleared"] is True` | karşılaştırma |

### `tests/unit/test_task_routing_step1.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 72 | `assert node.level == 0, "relative import forbidden in resolver"` | karşılaştırma |
| 218 | `assert data["schema_version"] == 1` | karşılaştırma |

### `tests/unit/test_taste_filter_faz_c.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 42 | `assert verdict.generic_score >= 0.70, verdict.signals` | karşılaştırma |
| 50 | `assert verdict.generic_score < 0.30, verdict.signals` | karşılaştırma |
| 117 | `assert summary["total"] == 1` | karşılaştırma |
| 118 | `assert summary["dropped"] == 1` | karşılaştırma |
| 127 | `assert taste_filter.telemetry_summary()["total"] == 0` | karşılaştırma |

### `tests/unit/test_threshold_calibration_faz_b.py` — 15 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 58 | `report = calibrate(_pairs("T90,T80,T70,F40,F30"), required=30)` | parametre |
| 69 | `Observation(observation_id="a", score=0.9, truth=None, scope=SCOPE_QUOTE),` | parametre |
| 70 | `Observation(observation_id="b", score=0.2, truth=False, scope=SCOPE_QUOTE),` | parametre |
| 71 | `Observation(observation_id="c", score=0.8, truth=True, scope=SCOPE_QUOTE),` | parametre |
| 74 | `assert report.samples == 3` | karşılaştırma |
| 75 | `assert report.labeled == 2` | karşılaştırma |
| 76 | `assert report.unlabeled == 1` | karşılaştırma |
| 89 | `assert 0.5 <= report.threshold <= 0.95` | karşılaştırma |
| 90 | `assert 0 < report.shrinkage_weight < 1  # veri azken tam güven yok` | karşılaştırma |
| 94 | `assert report.operating_point.accuracy >= 0.8` | karşılaştırma |
| 95 | `assert report.operating_point.fp == 0  # uydurma alıntı geçmedi` | karşılaştırma |
| 97 | `assert 0.0 <= report.expected_calibration_error <= 1.0` | karşılaştırma |
| 178 | `assert decision.report.labeled == 18` | karşılaştırma |
| 200 | `assert 0.70 < score < 0.80, f"beklenen aralıkta skor yok: {score}"` | karşılaştırma |
| 230 | `assert 0.70 < rows[0].score < 0.80` | karşılaştırma |

### `tests/unit/test_tier2_evidence_adapter.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 25 | `confidence=0.99,` | parametre |
| 26 | `achilles_score=80.0,` | parametre |
| 27 | `resonance_potential=0.8,` | parametre |
| 54 | `assert context.excluded_counts["unprovenanced_observation"] == 1` | karşılaştırma |
| 61 | `compatibility_score=0.62,` | parametre |

### `tests/unit/test_tier_variant_gate.py` — 5 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 216 | `assert nous and nous[0].input_per_million_usd == 0.0` | karşılaştırma |
| 380 | `direct = LLMGateway._tier_variant_sort_key("vision", is_legacy_or=False, price_sum=9.0)` | parametre |
| 381 | `legacy = LLMGateway._tier_variant_sort_key("vision", is_legacy_or=True, price_sum=0.5)` | parametre |
| 389 | `cheap = LLMGateway._tier_variant_sort_key(tier, is_legacy_or=False, price_sum=0.5)` | parametre |
| 390 | `pricy = LLMGateway._tier_variant_sort_key(tier, is_legacy_or=False, price_sum=9.0)` | parametre |

### `tests/unit/test_token_optimizer.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 38 | `assert result.stats.items_seen == 0` | karşılaştırma |
| 61 | `assert result.stats.items_seen == 1` | karşılaştırma |
| 62 | `assert result.stats.items_changed == 1` | karşılaştırma |
| 63 | `assert result.stats.bytes_saved > 0` | karşılaştırma |
| 85 | `assert result.stats.items_seen == 3` | karşılaştırma |
| 86 | `assert result.stats.skipped_error_items == 3` | karşılaştırma |
| 87 | `assert result.stats.items_changed == 0` | karşılaştırma |
| 110 | `assert result.stats.items_seen == result.stats.items_changed == 2` | karşılaştırma |
| 119 | `assert result.stats.items_changed == 0` | karşılaştırma |
| 141 | `assert lossy.stats.items_changed == 1` | karşılaştırma |
| 172 | `assert result.stats.items_changed == 0` | karşılaştırma |
| 207 | `assert result.stats.skipped_total_limit_items == 1` | karşılaştırma |
| 208 | `assert result.stats.skipped_oversize_items == 1` | karşılaştırma |

### `tests/unit/test_translation_local.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 104 | `assert result.source_confidence >= 0.5` | karşılaştırma |

### `tests/unit/test_uncertainty_b2_regressions.py` — 26 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 24 | `sentiment_polarity=0.7,` | parametre |
| 26 | `confidence=0.85,` | parametre |
| 42 | `alignment_score=0.8,` | parametre |
| 44 | `confidence=0.9,` | parametre |
| 53 | `assert report.confidence >= 0.70, report.confidence` | karşılaştırma |
| 65 | `confidence=0.2,` | parametre |
| 69 | `assert report.confidence < 0.70, report.confidence` | karşılaştırma |
| 105 | `alignment_score=0.8,` | parametre |
| 107 | `confidence=0.9,` | parametre |
| 111 | `assert report.confidence >= 0.70, report.confidence` | karşılaştırma |
| 117 | `one_char = engine._score_field_value("a", empty_list_penalty=0.12)` | parametre |
| 118 | `two_hundred = engine._score_field_value("x" * 200, empty_list_penalty=0.12)` | parametre |
| 119 | `whitespace = engine._score_field_value("   ", empty_list_penalty=0.12)` | parametre |
| 120 | `missing = engine._score_field_value("veri bulunamadı", empty_list_penalty=0.12)` | parametre |
| 121 | `assert one_char == two_hundred == 1.0` | karşılaştırma |
| 122 | `assert whitespace == 0.0` | karşılaştırma |
| 123 | `assert missing == 0.0` | karşılaştırma |
| 129 | `short_items = engine._score_field_value(["a"], empty_list_penalty=0.12)` | parametre |
| 130 | `long_items = engine._score_field_value(["x" * 300], empty_list_penalty=0.12)` | parametre |
| 131 | `empty = engine._score_field_value([], empty_list_penalty=0.12)` | parametre |
| 132 | `assert short_items == long_items == 1.0` | karşılaştırma |
| 133 | `assert empty == 0.12` | karşılaştırma |
| 138 | `"""MirrorOfTruth valid LLM sonucunda confidence >= 0.70 ve data_confidence=True donmeli."""` | karşılaştırma |
| 146 | `alignment_score=0.88,` | parametre |
| 160 | `assert res.confidence >= 0.70` | karşılaştırma |
| 167 | `assert report.confidence >= 0.70` | karşılaştırma |

### `tests/unit/test_uncertainty_data_confidence_gate.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 55 | `assert result.confidence == 0.0` | karşılaştırma |

### `tests/unit/test_uncertainty_engine.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 8 | `confidence: float = 0.8` | parametre |
| 12 | `confidence: float = 0.98` | parametre |
| 20 | `assert report.confidence == 0.8` | karşılaştırma |
| 40 | `confidence: float = 0.8` | parametre |
| 56 | `assert report.confidence == 0.1` | karşılaştırma |
| 64 | `assert report.confidence == 0.9` | karşılaştırma |
| 75 | `assert report.confidence == 0.1` | karşılaştırma |

### `tests/unit/test_uncertainty_evidence_quality.py` — 31 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 20 | `confidence: float = 0.8` | parametre |
| 30 | `duration_ms: int = 5` | parametre |
| 31 | `confidence: float = 0.8` | parametre |
| 38 | `confidence: float = 0.8` | parametre |
| 44 | `assert engine._score_field_value(marker, empty_list_penalty=0.12) == 0.0, marker` | parametre |
| 52 | `assert engine._score_field_value(note, empty_list_penalty=0.12) == 0.0, note` | parametre |
| 55 | `"KEY: Sentez tamamlandı · güven=0.80 · 6/6 motor aktif.",` | parametre |
| 56 | `empty_list_penalty=0.12,` | parametre |
| 59 | `assert engine._score_field_value("a", empty_list_penalty=0.12) == 1.0` | parametre |
| 60 | `assert engine._score_field_value("x" * 200, empty_list_penalty=0.12) == 1.0` | parametre |
| 67 | `["veri yok", "bulunamadı"], empty_list_penalty=0.12` | parametre |
| 71 | `["gerçek veri", "veri yok"], empty_list_penalty=0.12` | parametre |
| 74 | `assert engine._score_field_value(["a"], empty_list_penalty=0.12) == 1.0` | parametre |
| 75 | `assert engine._score_field_value(["x" * 300], empty_list_penalty=0.12) == 1.0` | parametre |
| 76 | `assert engine._score_field_value([], empty_list_penalty=0.12) == 0.12` | parametre |
| 82 | `{"type": "unknown", "defense": "unknown"}, empty_list_penalty=0.12` | parametre |
| 85 | `{"type": "agresif", "reason": "yok"}, empty_list_penalty=0.12` | parametre |
| 88 | `{"type": "agresif", "reason": "gerçek"}, empty_list_penalty=0.12` | parametre |
| 93 | `"""[018] düzeltmesi: LLM 'unknown' şablonunu doldurup confidence=0.9` | parametre |
| 96 | `fabricated = CognitiveStyle(confidence=0.9, data_confidence=True)` | parametre |
| 100 | `assert report.confidence == 0.1, report.confidence` | karşılaştırma |
| 101 | `assert report.data_score == 0.0, report.data_score` | karşılaştırma |
| 111 | `confidence=0.9,` | parametre |
| 116 | `assert report.confidence == 0.9, report.confidence` | karşılaştırma |
| 135 | `assert score_plain == score_meta == 1.0` | karşılaştırma |
| 145 | `assert score_fake == 0.0, score_fake` | karşılaştırma |
| 155 | `sentiment_polarity=0.5,` | parametre |
| 157 | `confidence=0.9,` | parametre |
| 162 | `assert report.confidence < 0.70, report.confidence` | karşılaştırma |
| 166 | `assert field_entry["score"] == 0.0` | karşılaştırma |
| 177 | `assert report.confidence == 0.1, report.confidence` | karşılaştırma |

### `tests/unit/test_uncompiled_language_integrity.py` — 2 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 53 | `if depth[_PAIRS[char]] < 0:` | karşılaştırma |
| 55 | `return all(value == 0 for value in depth.values()), depth` | karşılaştırma |

### `tests/unit/test_unified_router.py` — 28 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 44 | `def __init__(self, monotonic: float = 100.0, wall: float = 1_800_000_000.0):` | parametre |
| 57 | `context: int = 32_000,` | parametre |
| 113 | `_provider("cheap", tier=RouteTier.CHEAP, input_price=0.1, output_price=0.2),` | parametre |
| 159 | `assert router.public_snapshot()["active_attempts"] == 0` | karşılaştırma |
| 165 | `plan = router.plan(RouteRequest(strategy=strategy, seed=7, preview=True))` | parametre |
| 169 | `assert all(0 <= candidate.score <= 1 for candidate in plan.candidates)` | karşılaştırma |
| 177 | `assert router.public_snapshot()["active_attempts"] == 0` | karşılaştırma |
| 212 | `request = RouteRequest(strategy=RoutingStrategy.STRICT_RANDOM, seed=17)` | parametre |
| 220 | `_provider("expensive", tier=RouteTier.API_KEY, context=8_000, input_price=10, output_price=20),` | parametre |
| 221 | `_provider("cheap", tier=RouteTier.API_KEY, context=128_000, input_price=0.1, output_price=0.2),` | parametre |
| 226 | `QuotaSnapshot(status=QuotaStatus.HEALTHY, remaining_fraction=0.9),` | parametre |
| 230 | `QuotaSnapshot(status=QuotaStatus.APPROACHING_LIMIT, remaining_fraction=0.1),` | parametre |
| 249 | `_provider("high-quality", tier=RouteTier.API_KEY, input_price=20, output_price=40),` | parametre |
| 267 | `minimum_quality=0.8,` | parametre |
| 330 | `FailureSignal(status_code=429, headers={"Retry-After": "30"}),` | parametre |
| 335 | `assert decision.retry_after_seconds == 30` | karşılaştırma |
| 355 | `decision = router.finish_failure(lease, FailureSignal(status_code=401))` | parametre |
| 375 | `decision = router.finish_failure(lease, FailureSignal(status_code=404, message="model_not_found"))` | parametre |
| 382 | `assert router.public_snapshot()["model_lock_count"] == 1` | karşılaştırma |
| 389 | `provider_open_seconds=20,` | parametre |
| 397 | `decision = router.finish_failure(lease, FailureSignal(status_code=503))` | parametre |
| 417 | `assert router.public_snapshot()["active_attempts"] == 0` | karşılaştırma |
| 479 | `assert router.public_snapshot()["target_state_entries"] == 100` | karşılaştırma |
| 483 | `assert classify_failure(FailureSignal(status_code=401)) is FailureKind.AUTHENTICATION` | parametre |
| 484 | `assert classify_failure(FailureSignal(status_code=429, message="insufficient_quota")) is FailureKind.QUOTA_EXHAUSTED` | parametre |
| 485 | `assert classify_failure(FailureSignal(status_code=429)) is FailureKind.RATE_LIMIT` | parametre |
| 486 | `assert classify_failure(FailureSignal(status_code=500)) is FailureKind.SERVER` | parametre |
| 493 | `assert parse_retry_after({"Retry-After": "9999"}, wall_clock=wall, maximum=120) == 120` | parametre |

### `tests/unit/test_usage_settlement.py` — 11 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 56 | `def _settle(gateway, usage, *, pricing=None, amount=0.5):` | parametre |
| 67 | `pytest.param(_Usage(prompt_tokens=-5, completion_tokens=10), id="negative-prompt"),` | parametre |
| 69 | `pytest.param(_Usage(prompt_tokens=1.5, completion_tokens=2.0), id="fractional"),` | parametre |
| 72 | `pytest.param(_Usage(prompt_tokens=1000, completion_tokens=500, total_tokens=0), id="explicit-zero-total"),` | parametre |
| 73 | `pytest.param(_Usage(prompt_tokens=1000, completion_tokens=500, total_tokens=-1), id="negative-total"),` | parametre |
| 81 | `amount = 0.5` | parametre |
| 94 | `usage = _Usage(prompt_tokens=1000, completion_tokens=500)` | parametre |
| 95 | `pricing = {"in": 2.0, "out": 10.0}  # (1000*2 + 500*10)/1e6 = 0.007` | parametre |
| 97 | `settled = _settle(gateway, usage, pricing=pricing, amount=0.5)` | parametre |
| 113 | `assert gateway.spend_usd > 0.0  # 0'a sıfırlanmadı` | karşılaştırma |
| 116 | `assert gateway.call_log[-1]["cost_usd"] > 0.0` | karşılaştırma |

### `tests/unit/test_vault_egress_lock.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 167 | `assert r.status_code == 423, f"{path} kasa kilitliken {r.status_code} döndü: {r.text[:200]}"` | karşılaştırma |
| 208 | `assert r.status_code == 423, f"{path}: {r.status_code} {r.text[:200]}"` | karşılaştırma |
| 219 | `assert r.status_code == 200, r.text[:200]` | karşılaştırma |
| 232 | `assert egress.status_code == 423` | karşılaştırma |
| 248 | `assert r.status_code != 423, r.text[:300]` | karşılaştırma |
| 265 | `assert r.status_code == 423` | karşılaştırma |

### `tests/unit/test_verifier_dual_mode.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 31 | `intensity=4.0,` | parametre |
| 91 | `assert rejected == 0` | karşılaştırma |
| 112 | `assert rejected == 0` | karşılaştırma |
| 125 | `assert rejected == 1` | karşılaştırma |

### `tests/unit/test_verifier_entailment_gate.py` — 13 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 10 | ``status=VERIFIED, confidence=0.70` (güven tabanı `max(conclusive/total, 0.70)`).` | parametre |
| 11 | `* Hiçbir iddia kesinleşmedi → `status=UNVERIFIED, confidence=0.70,` | parametre |
| 110 | `assert report.confidence == 0.0` | karşılaştırma |
| 159 | `assert report.confidence == 0.0` | karşılaştırma |
| 180 | `assert report.confidence == 1.0` | karşılaştırma |
| 220 | `assert report.unknown_claims == 9` | karşılaştırma |
| 221 | `assert report.confidence == 0.1, "güven tabanı (0.70) geri geldi"` | karşılaştırma |
| 222 | `assert report.overall_authenticity_score == 0.1` | karşılaştırma |
| 231 | `assert report.confidence == 0.0, "kanıt yokken güven 0.70 tabanına sabitlenemez"` | karşılaştırma |
| 238 | `assert check.confidence < 0.65, "eşik altı güven tamponlanamaz"` | karşılaştırma |
| 284 | `assert report.confidence == 0.0` | karşılaştırma |
| 285 | `assert report.vote_accounting["invalid"] == 2` | karşılaştırma |
| 347 | `assert report.overall_authenticity_score == 0.0` | karşılaştırma |

### `tests/unit/test_verifier_prompt_injection.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 62 | `if claim_list_calls["n"] == 1:` | karşılaştırma |

### `tests/unit/test_verifier_unverified.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 3 | `KIZIL TEST: tavily_key yoksa score == 0.0, status == "UNVERIFIED" olmalı.` | karşılaştırma |
| 24 | `assert report.overall_authenticity_score == 0.0, (` | karşılaştırma |
| 43 | `assert report.overall_authenticity_score == 0.0, (` | karşılaştırma |
| 62 | `assert report.overall_authenticity_score == 0.0, (` | karşılaştırma |
| 69 | `"""Hiçbir arama yapılmadan score == 1.0 olamaz (P0.2 sahte başarı yasağı)."""` | karşılaştırma |
| 80 | `assert report.overall_authenticity_score != 1.0, (` | karşılaştırma |

### `tests/unit/test_version_identity.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 60 | `çalışması için ek bağımlılık (tomli) veya Python >= 3.11 (tomllib)` | karşılaştırma |

### `tests/unit/test_vision_analyzer_gate.py` — 7 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 54 | `"""Provider confidence=0.9 beyan etse bile final confidence yerel` | parametre |
| 59 | `confidence=0.99, data_confidence=True,  # provider'in beyani` | parametre |
| 77 | `assert kwargs["temperature"] == 0.2` | karşılaştırma |
| 103 | `assert outbound["count"] == 0, "LIVE_LLM_E2E=0 iken outbound cagri olustu"` | karşılaştırma |
| 106 | `assert res.confidence == 0.0` | karşılaştırma |
| 115 | `VisualEvidence(detected_objects=[], confidence=0.7, data_confidence=True)` | parametre |
| 136 | `assert res.confidence == 0.0` | karşılaştırma |

### `tests/unit/test_wave3_honesty_contracts.py` — 6 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 31 | `assert ev.confidence == 0.0` | karşılaştırma |
| 96 | `rec = await _download(JPG, "image/jpeg", status=403)` | parametre |
| 138 | `msg = GeneratedMessage(message="x", strategy="y", confidence=0.5, compliance_score=100.0, dialogue_tree=[])` | parametre |
| 149 | `confidence=0.8, compliance_score=100.0, dialogue_tree=[],` | parametre |
| 227 | `assert stored["confidence"] == 0.9, "[036] doğrulama notu güveni düşürmemeli"` | karşılaştırma |
| 236 | `assert mem.get_task_memory("fxmem2")["confidence"] == 0.0` | karşılaştırma |

### `tests/unit/test_wiring_api.py` — 4 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 26 | `task_id="fx_w4", agent_name="mirror_truth", status="completed", confidence=0.9` | parametre |
| 40 | `assert payload["runs"]["mirror_truth"]["confidence"] == 0.9` | karşılaştırma |
| 46 | `assert r.status_code == 200` | karşılaştırma |
| 82 | `assert r.status_code == 200` | karşılaştırma |

### `tests/unit/test_wiring_timing.py` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 25 | `"""night_share=0.8 -> log '%80' demeli; '%0' degil."""` | parametre |

### `worker.ts` — 1 eşik/sabit

| satır | kod | tip |
|---|---|---|
| 36 | `.filter((part) => part.length > 0);` | karşılaştırma |