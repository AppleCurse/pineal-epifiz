# TEST ENVANTERİ — her dosya NEYİ GÜVENCE ALTINA ALIYOR

Toplam **234** test dosyası.

| # | Dosya | Test | Güvence altına aldığı davranış | Grup |
|---|---|---|---|---|
| 1 | `tests/audit/test_auditor_round2_findings.py` | 15 | 3. Göz denetimi (2026-09-06) — kapatılan bulguların REGRESYON KORUMASI. | denetim |
| 2 | `tests/audit/test_boss11_frame_contract.py` | 5 | [BOSS-11] WS çerçeve sözleşmesi — tek serileştirme + görünür çerçeve hatası. | denetim |
| 3 | `tests/audit/test_boss2_ghost_task_lock.py` | 9 | BOSS-2 — Hayalet görev / kalıcı 503 kilidi REGRESYON KORUMASI. | denetim |
| 4 | `tests/audit/test_boss6_authentic_vector_telemetry.py` | 2 | BOSS-6 — Authentic-vector LLM harcamasının telemetriye bağlanması. | denetim |
| 5 | `tests/audit/test_boss7_b9_wiring.py` | 5 | [BOSS-7 + BOSS-9] Kör ajanlar ve çift pattern çağrısı — sözleşme testleri. | denetim |
| 6 | `tests/audit/test_boss8_agent_timeout.py` | 6 | [BOSS-8] Ajan başına zaman sınırı ve timeout'un terminal raporlanması. | denetim |
| 7 | `tests/audit/test_production_audit_findings.py` | 35 | Üretim denetimi (2026-09-04) — kapatılan kusurların REGRESYON KORUMASI. | denetim |
| 8 | `tests/audit/test_responsibility_rules.py` | 22 | Sorumluluk Zinciri — A-yolu kural testleri (makine bekçisi). | denetim |
| 9 | `tests/audit/test_round3_residue_findings.py` | 10 | 4. Göz — Round 3 (N1-N6 artık maddelerinin) REGRESYON KORUMASI. | denetim |
| 10 | `tests/audit/test_support_flow_acceptance.py` | 10 | Kabul denetimi — “destekle devam etme” davranış testleri (A–I). | denetim |
| 11 | `tests/conftest.py` | 0 | Test ortamı için ortak ayarlar. | kök |
| 12 | `tests/e2e/test_cross_stack_runtime.py` | 2 | Critical API→executor→LLM→evidence→memory→telemetry→UI protocol E2E. | e2e |
| 13 | `tests/e2e/test_llm_protocol.py` | 4 | FAZ 5 / G5.1 — LLM protokol E2E: GERÇEK LLMGateway kod yolu, sahte HTTP katmanı. | e2e |
| 14 | `tests/e2e/test_openai_compatibility.py` | 12 | OpenAI client surface through the real gateway and a hermetic HTTP transport. | e2e |
| 15 | `tests/e2e/test_smoke.py` | 4 | ADIM 4 — Uçtan uca smoke testleri (gerçek ASGI uygulaması, mock'suz yüzey). | e2e |
| 16 | `tests/integration/test_agent_rack_wiring.py` | 7 | Adım 3 kilidi: 12 ajan GERÇEKTEN koşuyor mu ve Agent Rack'e 1:1 mi bağlı? | entegrasyon |
| 17 | `tests/integration/test_aspasia_chat_api.py` | 3 | ADIM 1 / G0.2 — /api/aspasia/chat HTTP regresyon testi. | entegrasyon |
| 18 | `tests/integration/test_aspasia_chief.py` | 3 | Test adları:  test_build_telemetry_summary_empty, test_build_telemetry_summary, test_chat_updates_session_and_calls_llm | entegrasyon |
| 19 | `tests/integration/test_badhost_auth_bypass.py` | 6 | AUDIT 2026-09-11 P0-1 — CVE-2026-48710 / GHSA-86qp-5c8j-p5mr ("BadHost") | entegrasyon |
| 20 | `tests/integration/test_calibration_api_faz_b.py` | 5 | FAZ B · B5 — EŞİK KALİBRASYONU uçtan uca (API + ledger + karar). | entegrasyon |
| 21 | `tests/integration/test_canonical_memory.py` | 4 | Test adları:  test_canonical_memory_write_read, test_canonical_memory_overwrite, test_canonical_memory_missing_file, test_canonical_memory_corrupted_json | entegrasyon |
| 22 | `tests/integration/test_claim_gate_executor.py` | 3 | Test adları:  test_executor_traces_gate_and_filters_same_claim_from_messages, test_executor_preserves_unverified_verifier_checks_for_depth_analyst, test_executor_adds_internal_checks_for_separately_stored_tier2_ob | entegrasyon |
| 23 | `tests/integration/test_company_api_faz_d.py` | 9 | FAZ D · D6 — kurum hedefi uçları: kapılar, dürüst ret, kanıt zinciri. | entegrasyon |
| 24 | `tests/integration/test_critical_paths.py` | 1 | Test adları:  test_critical_path_task_execution | entegrasyon |
| 25 | `tests/integration/test_depth_verification_trace_executor.py` | 2 | [A-KAPANIŞ / A4] Executor içinde uçtan uca iz: WRITE → READ → USE → ALTER DECISION → FINAL. | entegrasyon |
| 26 | `tests/integration/test_faz3_security.py` | 7 | FAZ 3 / G3.1+G3.2 — güvenlik sözleşmeleri (auth, rate limit, deneysel yollar). | entegrasyon |
| 27 | `tests/integration/test_holistic_e2e.py` | 1 | Test adları:  test_holistic_360_e2e_pipeline | entegrasyon |
| 28 | `tests/integration/test_jury_api_faz_d.py` | 10 | FAZ D · D2 — yerel jüri uçları: kapılar, dürüst kural, veri makineden çıkmaz. | entegrasyon |
| 29 | `tests/integration/test_language_api_faz_d.py` | 9 | FAZ D · D4 — dil uçları uçtan uca: omurga + kasa + dürüst sonuçlar. | entegrasyon |
| 30 | `tests/integration/test_live_fixes_2026_09.py` | 22 | CANLI-FİKİR REVİZYONU 2026-09 — 11 maddelik düzeltme listesinin kanıt testleri. | entegrasyon |
| 31 | `tests/integration/test_llm_gateway_integration.py` | 3 | Test adları:  test_llm_gateway_no_flag_raises_error, test_llm_gateway_rate_limit_retry, test_llm_gateway_auth_error | entegrasyon |
| 32 | `tests/integration/test_mcp_api_status_faz_d.py` | 6 | FAZ D · D1 — ``/api/mcp/status`` uçtan uca (kokpit + dış istemci bilgisi). | entegrasyon |
| 33 | `tests/integration/test_mcp_server_stdio.py` | 6 | FAZ D · D1 — MCP sunucusu UÇTAN UCA: gerçek süreç, gerçek stdio, gerçek kapılar. | entegrasyon |
| 34 | `tests/integration/test_media_api_faz_d.py` | 12 | FAZ D · D3 — medya uçları: kapılar, dürüst araç durumu, ölçüm kanıtı. | entegrasyon |
| 35 | `tests/integration/test_memory_crystal_api_faz_b.py` | 5 | FAZ B · B2/B3 — HAFIZA KRİSTALİ uçtan uca: API + görev yürütücü + kristal. | entegrasyon |
| 36 | `tests/integration/test_p2_release_gate.py` | 1 | Test adları:  test_p2_release_gate_e2e_integration | entegrasyon |
| 37 | `tests/integration/test_report_capabilities.py` | 13 | FAZ D · D5 — rapor yetenekleri + uçlar: kapılar, mühür, dürüst eksik format. | entegrasyon |
| 38 | `tests/integration/test_resonance_executor_signature.py` | 1 | Test adları:  test_real_resonance_calculator_execution_in_executor | entegrasyon |
| 39 | `tests/integration/test_run_task_cli.py` | 5 | [W4.2] scripts/run_task.py — Rust TaskManager'ın standart girişi. | entegrasyon |
| 40 | `tests/integration/test_scraper_error_handling.py` | 3 | Test adları:  test_scraper_retry_success, test_scraper_retry_failure, test_scraper_permanent_failure | entegrasyon |
| 41 | `tests/integration/test_speech_api_faz_c.py` | 19 | FAZ C · C2 — Ses uçtan uca: gerçek YEREL motor + WS konuşma durumu. | entegrasyon |
| 42 | `tests/integration/test_support_cockpit.py` | 10 | [B0] Kokpit.destek & güvenli devam döngüsü — uçtan uca ve negatif testler. | entegrasyon |
| 43 | `tests/integration/test_task_executor_flow.py` | 8 | Test adları:  test_execute_task_full_flow, test_execute_task_halt_low_confidence, test_execute_task_suspicious_research, test_execute_task_frequency_mismatch, test_executor_carries_typed_pillar_evidence_before_rou | entegrasyon |
| 44 | `tests/integration/test_task_retention.py` | 2 | FAZ 3 / etik çerçeve — görev geçmişi ve KALICI veri silme (retention) sözleşmesi. | entegrasyon |
| 45 | `tests/integration/test_taste_filter_api_faz_c.py` | 5 | FAZ C · C1 — Jenerik yanıt filtresi uçtan uca: Aspasia + telemetri + API. | entegrasyon |
| 46 | `tests/integration/test_vault_unlock_and_routing.py` | 4 | Test adları:  test_effective_scraper_type_url_aware, test_vault_key_unlocks_live_llm_gate, test_unlocked_gateway_passes_gate_without_env_flag, test_locked_gateway_still_blocks_without_key_or_flag | entegrasyon |
| 47 | `tests/integration/test_ws_ordering.py` | 2 | ADIM 3 — Telemetri FIFO sıra garantisı (WebSocket). | entegrasyon |
| 48 | `tests/test_instagram_ghost.py` | 7 | PINEAL-HERETIC - Instagram Ghost Scraper Testleri | kök |
| 49 | `tests/test_interpreter_agent.py` | 2 | Test adları:  test_interpreter_agent_initialization, test_interpreter_agent_fallback_or_execute | kök |
| 50 | `tests/test_llm_json_repair.py` | 4 | Test adları:  test_llm_gateway_json_repair, test_json_repair_does_not_run_on_transport_errors, test_json_repair_does_not_run_on_runtime_errors, test_json_repair_runs_on_schema_validation_error | kök |
| 51 | `tests/test_pillar_engines.py` | 12 | Test adları:  test_timestamp, test_strict_models, test_frequency, test_seismos, test_void, test_strata, test_gravity, test_pulse, test_orchestrator_and_json, test_graceful_empty | kök |
| 52 | `tests/test_router.py` | 1 | Test adları:  test_cognitive_router_halt | kök |
| 53 | `tests/test_scrape.py` | 1 | Test adları:  test_scrape | kök |
| 54 | `tests/test_scraper_fallback.py` | 4 | scraper.py (X kazima) B4 sözleşmesi. | kök |
| 55 | `tests/test_six_stamps_integration.py` | 2 | Test adları:  test_snapshot_and_result_six_stamps_serialization, test_searchengine_none_vs_empty_string | kök |
| 56 | `tests/test_system_modules.py` | 4 | Test adları:  test_dark_triad_analyzer_deterministic, test_dark_triad_strategy_vector, test_dialogue_manager_generate_response_roundtrip, test_dialogue_manager_unknown_session_raises | kök |
| 57 | `tests/unit/test_9router_config_contract.py` | 6 | BOSS-1 — 9Router yapılandırma sözleşmesi. | birim |
| 58 | `tests/unit/test_agent_model_policy.py` | 5 | Test adları:  test_specialist_agent_chains_are_explicit, test_verifier_extract_and_judgment_use_distinct_chains, test_retired_slugs_are_not_in_any_default_chain, test_task_and_agent_capabilities_are_explicit, test | birim |
| 59 | `tests/unit/test_agent_worker.py` | 14 | Ajan canlılık işaretçisi (liveness beacon) sözleşmesi. | birim |
| 60 | `tests/unit/test_alternative_web_research.py` | 6 | X yetki sonrası alternatif public-web araştırma sözleşmesi. | birim |
| 61 | `tests/unit/test_android_parity_labels.py` | 6 | Android ↔ Python eşdeğerlik (parity) DÜRÜSTLÜK sözleşmesi. | birim |
| 62 | `tests/unit/test_api_monolith_ratchet.py` | 10 | `backend/api.py` tek-modül TAVANI (ratchet). | birim |
| 63 | `tests/unit/test_aspasia_chief_layer.py` | 19 | ASPASIA TRUE CHIEF LAYER — goal transport, kanonik sonuc dongusu, mismatch. | birim |
| 64 | `tests/unit/test_aspasia_depth_hukmu.py` | 12 | ASPASIA + ROUTING HÜKMÜ — derinlik metriklerinin diskten okunmasi. | birim |
| 65 | `tests/unit/test_aspasia_promotion.py` | 16 | ASPASIA PROMOTION — merkezi doğal-dil arayüzü sözleşme testleri. | birim |
| 66 | `tests/unit/test_aspasia_state_consistency.py` | 22 | FAZ 2 — Aspasia durum/telemetri tutarlilik sozlesmeleri. | birim |
| 67 | `tests/unit/test_audit_regression.py` | 41 | E0 · DENETİM REGRESYON BEKÇİSİNİN KENDİSİ DENETLENİYOR. | birim |
| 68 | `tests/unit/test_authentic_vector_unavailable.py` | 5 | Test adları:  test_vector_failure_returns_unavailable_not_neutral_defaults, test_unavailable_vector_is_explicit_metadata_not_numeric_evidence, test_available_vector_carries_epistemic_marker, test_resonance_rejects | birim |
| 69 | `tests/unit/test_authenticity_auditor.py` | 4 | Test adları:  test_auditor_empty_visual_evidence_early_return, test_auditor_empty_bio_and_posts_early_return, test_auditor_normal_path_calls_llm_chain, test_auditor_llm_exception_fallback_and_logging | birim |
| 70 | `tests/unit/test_body_size_limit.py` | 14 | P0-BOOT-FIX — İstek gövdesi tavanı sözleşme testleri. | birim |
| 71 | `tests/unit/test_canonical_memory_conflicts.py` | 1 | Test adları:  test_conflicting_claims_are_preserved_and_marked_not_silently_sorted | birim |
| 72 | `tests/unit/test_canonical_memory_recovery.py` | 6 | Test adları:  test_missing_memory_is_explicitly_empty, test_existing_invalid_memory_is_never_reported_as_empty, test_normal_merge_refuses_corrupt_memory_and_preserves_exact_bytes, test_explicit_recovery_quarantine | birim |
| 73 | `tests/unit/test_capability_spine_faz0.py` | 32 | Capability Spine (Faz 0) kabul testleri. | birim |
| 74 | `tests/unit/test_change_tracker_faz_b.py` | 11 | FAZ B · B7 — DEĞİŞİM İZLEME sözleşme testleri. | birim |
| 75 | `tests/unit/test_claim_decision_gate.py` | 5 | Test adları:  test_gate_blocks_only_the_same_audited_bio_claim_phrase, test_gate_does_not_block_partial_words_topics_or_related_claims, test_contradiction_unknown_and_unprovenanced_yalan_are_not_vetoes, test_gate_ | birim |
| 76 | `tests/unit/test_cognitive_profiler.py` | 2 | Test adları:  test_cognitive_profiler_empty_data, test_cognitive_profiler_with_data | birim |
| 77 | `tests/unit/test_company_capabilities.py` | 13 | FAZ D · D6 — kurum hedefi yetenekleri: kapılar, kanıt, dürüst yokluk. | birim |
| 78 | `tests/unit/test_company_recon.py` | 13 | FAZ D · D6 — kurum hedefi servisi: dürüst ölçüm, uydurma metrik yok. | birim |
| 79 | `tests/unit/test_compose_env_contract.py` | 3 | [AUDIT R2] Compose + .env PINEAL_ENV akışının FAIL-CLOSED sözleşmesi. | birim |
| 80 | `tests/unit/test_concurrent_spend_cap.py` | 6 | P0 regression coverage for atomic concurrent spend reservations. | birim |
| 81 | `tests/unit/test_config_contract.py` | 9 | P1-B1: config -> Pydantic sözleşme kilidi. | birim |
| 82 | `tests/unit/test_consolidation_faz1_5.py` | 5 | FAZ 1-5 sağlamlaştırma sözleşmeleri. | birim |
| 83 | `tests/unit/test_crawl_enricher.py` | 21 | Crawl4AI entegrasyon sözleşme testleri (FAZ 4). Bu dosyayı kullanan dosyalar (1): tests/unit/test_retina_faz_a_wiring.py. | birim |
| 84 | `tests/unit/test_dark_nlp_and_shadow.py` | 5 | Test adları:  test_embedded_command_engine_visual_detection, test_embedded_command_engine_auditory_and_kinesthetic_defaults, test_presupposition_engine_chain_generation, test_presupposition_engine_empty_beliefs, t | birim |
| 85 | `tests/unit/test_decision_engine.py` | 7 | DecisionEngine ve 5./6. damga (shadow/osint) durum muhasebesi testleri. | birim |
| 86 | `tests/unit/test_decision_engine_degraded.py` | 2 | Test adları:  test_unavailable_warning_with_real_evidence_is_partial, test_unavailable_without_evidence_is_insufficient | birim |
| 87 | `tests/unit/test_deferred_agent_evidence_gate.py` | 2 | Test adları:  test_deferred_agent_low_confidence_is_not_written_as_evidence, test_deferred_agent_invalid_output_is_not_written_as_evidence | birim |
| 88 | `tests/unit/test_dependency_health.py` | 9 | Test adları:  test_required_missing_dependency_has_machine_readable_startup_failure, test_installed_but_broken_dependency_is_not_classified_as_missing, test_disabled_experimental_dependency_is_not_imported, test_e | birim |
| 89 | `tests/unit/test_depth_analyst_verification_context.py` | 1 | Test adları:  test_depth_analyst_receives_only_structured_verification_summary | birim |
| 90 | `tests/unit/test_depth_and_forensics.py` | 4 | Test adları:  test_timing_forensics_arithmetic, test_follower_audit_inflated, test_quote_guard_drops_unanchored_findings, test_search_engine_fallback_duckduckgo | birim |
| 91 | `tests/unit/test_depth_failure_wiring.py` | 2 | depth_analyst failures must be visible on agent_runs + evidence_chain. | birim |
| 92 | `tests/unit/test_depth_verification_trace.py` | 15 | [A-KAPANIŞ] Verifier → DepthAnalyst → DepthReport izlenebilirlik kilidi. | birim |
| 93 | `tests/unit/test_dockerfile_contract.py` | 3 | Production container security and runtime-content contract. | birim |
| 94 | `tests/unit/test_egress_single_spine.py` | 9 | E-GÖZ1-3 — tek sırt (egress) omurgası: davranış + statik ölçümler. | birim |
| 95 | `tests/unit/test_engine_determinism.py` | 6 | Yedi motor determinizmi — gerçek çıktı karşılaştırmasıyla kilitlenir. | birim |
| 96 | `tests/unit/test_evidence_hash_and_fallback_gate.py` | 6 | Test adları:  test_step_hash_is_result_sensitive_and_not_placeholder, test_unavailable_data_is_never_safe_uncertainty, test_evidence_seal_is_reproducible_across_wall_clock, test_evidence_seal_still_separates_diffe | birim |
| 97 | `tests/unit/test_evidence_timeline.py` | 3 | Test adları:  test_timeline_is_sorted_typed_sourced_and_excludes_strategy, test_timeline_uses_observed_at_before_window_and_accepts_json_items, test_empty_timeline_has_no_synthetic_entries | birim |
| 98 | `tests/unit/test_execute_with_timeout.py` | 11 | ``PinealExecutor._execute_with_timeout`` — imza pazarlığı sözleşmesi. | birim |
| 99 | `tests/unit/test_executor_confidence_semantics.py` | 2 | Test adları:  test_holistic_confidence_uses_measured_completed_profile_confidences_only, test_holistic_confidence_is_zero_when_no_profile_confidence_is_measured | birim |
| 100 | `tests/unit/test_experimental_engine_contract.py` | 17 | E5 · DENEYSEL MOTOR YOKKEN "ÇALIŞIYOR" GÖRÜNTÜSÜ YOK (Md.1 uydurma yasağı). | birim |
| 101 | `tests/unit/test_export_skills.py` | 13 | FAZ D · D1 — Agent Skills ihracı: defterden üretim, bayatlık yakalama. | birim |
| 102 | `tests/unit/test_final_routing_policy.py` | 30 | FINAL-KARAR-MATRIX policy contracts: free-first firewall, pricing, quotas. | birim |
| 103 | `tests/unit/test_final_spec_compliance.py` | 24 | FINAL-SPEC compliance — F-1/F-2/F-3/F-4 + transport-level provider proof. | birim |
| 104 | `tests/unit/test_final_sweep_honesty.py` | 9 | Son tarama turu: kalan sahte şablon/default/confidence bulgularının | birim |
| 105 | `tests/unit/test_forensic_closers_vault_rack_gravity_carrier.py` | 17 | Adli kapatıcılar (kalan 4 madde): kasa interlock, raf kablolama, gravity determinizmi, taşıyıcı dürüstlüğü. | birim |
| 106 | `tests/unit/test_friction_detector.py` | 2 | Test adları:  test_friction_detector_empty_data, test_friction_detector_with_data | birim |
| 107 | `tests/unit/test_frontend_agent_model_contract.py` | 2 | F3 kontrat testi: UI agent kartlarindaki model etiketleri gateway SoT'sine kilitlenir. | birim |
| 108 | `tests/unit/test_gateway_cost_and_retry.py` | 9 | Dalga 3.5: LLM Gateway maliyet dürüstlüğü + retry sınıflandırması. | birim |
| 109 | `tests/unit/test_gateway_vision.py` | 5 | FAZ 3 / G3.5 — LLMGateway vision (multimodal) sözleşmesi. | birim |
| 110 | `tests/unit/test_gather_contract.py` | 8 | E7 · `asyncio.gather` SÖZLEŞMESİ — tek hata tüm turu düşürmez. | birim |
| 111 | `tests/unit/test_glue_forensics_wiring.py` | 18 | Dalga 1 + Dalga 2 düzeltmelerinin regresyon sözleşmeleri. | birim |
| 112 | `tests/unit/test_google_gemini_direct.py` | 4 | FAZ-2-P4 — Google Gemini direkt transport + 429→backup rotasyonu. | birim |
| 113 | `tests/unit/test_gorev1_reel_video_chrono.py` | 12 | GÖREV 1 — tamamlayici kazima sozlesmeleri. | birim |
| 114 | `tests/unit/test_gorev2_artiklar.py` | 16 | GÖREV 2 ARTIKLARI — shadow strateji eslemesi + PIL doygunlugu. | birim |
| 115 | `tests/unit/test_gorev2_depth_engine.py` | 20 | GÖREV 2 — psikodinamik motor sozlesmeleri (2.1 - 2.4). | birim |
| 116 | `tests/unit/test_graph_faz_b.py` | 12 | FAZ B · B4 — GERÇEK İLİŞKİ GRAFI sözleşme testleri. | birim |
| 117 | `tests/unit/test_health_degraded.py` | 7 | Health endpoint DEGRADED durum testleri. | birim |
| 118 | `tests/unit/test_hindsight_memory.py` | 10 | HindsightMemory birim testleri. | birim |
| 119 | `tests/unit/test_holehe_scanner.py` | 21 | Holehe entegrasyon sözleşme testleri (FAZ 3). | birim |
| 120 | `tests/unit/test_human_behavior.py` | 10 | Test adları:  test_linguistic_forensics, test_temporal_forensics, test_mine_contradictions, test_calculate_achilles, test_identify_wound_as_bridge, test_calculate_resonance_potential, test_analyze_visual_micro, te | birim |
| 121 | `tests/unit/test_human_behavior_evidence_contract.py` | 3 | [022] HumanBehavior model-level evidence contract. | birim |
| 122 | `tests/unit/test_instagram_ghost_captions.py` | 4 | [196 canli-kosu duzeltmesi] Regresyon kilidi. | birim |
| 123 | `tests/unit/test_intervention_safety.py` | 2 | Test adları:  test_confidence_override_is_audited_but_never_mutates_executor, test_skip_agent_does_not_delete_shared_agent_registry | birim |
| 124 | `tests/unit/test_inventory_page.py` | 7 | Envanter sayfası sözleşmeleri — ``docs/envanter.html`` kaynaktan sapamaz. | birim |
| 125 | `tests/unit/test_jury_consensus_faz_b.py` | 15 | FAZ B · B1 — BAĞIMSIZ JÜRİ KONSENSÜS DENETÇİSİ sözleşme testleri. | birim |
| 126 | `tests/unit/test_language_capabilities.py` | 12 | FAZ D · D4 — dil yetenekleri omurgada: tespit + yerel çeviri + kanıt damgası. | birim |
| 127 | `tests/unit/test_language_detect.py` | 14 | FAZ D · D4 — dil tespiti: deterministik, modelsiz, ağsız. | birim |
| 128 | `tests/unit/test_lilith_growth.py` | 15 | Test adları:  test_lilith_growth_agent_execution, test_lilith_growth_agent_fallback_resilience, test_lilith_growth_agent_partial_malformed_llm_fields_do_not_crash, test_render_console_report_contains_key_sections, | birim |
| 129 | `tests/unit/test_llm_call_observability.py` | 3 | Gözlemlenebilirlik: LLM çağrı metadata'sı evidence chain'e yazılır. | birim |
| 130 | `tests/unit/test_llm_gateway.py` | 12 | Gateway-level regression contracts: telemetry, pricing guard, retry, cap. | birim |
| 131 | `tests/unit/test_llm_gateway_rtk_integration.py` | 10 | Test adları:  test_policy_loads_and_caches, test_missing_policy_file_fails_open, test_should_bypass_when_disabled, test_should_bypass_depth_task, test_apply_rtk_compression_respects_bypass, test_apply_rtk_compress | birim |
| 132 | `tests/unit/test_local_jury.py` | 23 | FAZ D · D2 — YEREL JÜRİ: bağımsız koltuklar, açık kural, uydurma yok. | birim |
| 133 | `tests/unit/test_local_jury_capability.py` | 10 | FAZ D · D2 — yerel jüri YETENEĞİ: kapılar, kanıt türü, konsensüs sözleşmesi. | birim |
| 134 | `tests/unit/test_maigret_db_env.py` | 8 | FAZ A · A8 — tarayıcı tazelenmiş DB'yi GERÇEKTEN kullanır ve raporlar. | birim |
| 135 | `tests/unit/test_maigret_db_refresh.py` | 24 | FAZ A · A8 — maigret DB tazeleme çekirdeği (WhatsMyName/sherlock birleştirme). | birim |
| 136 | `tests/unit/test_maigret_scanner.py` | 17 | Maigret entegrasyon sözleşme testleri (FAZ 2). | birim |
| 137 | `tests/unit/test_mcp_protocol.py` | 16 | FAZ D · D1 — MCP tel katmanı testleri (I/O yok, saf zarf mantığı). | birim |
| 138 | `tests/unit/test_mcp_results.py` | 10 | FAZ D · D1 — CapabilityResult → MCP sonucu çevirisi (dürüstlük testleri). | birim |
| 139 | `tests/unit/test_mcp_server.py` | 30 | FAZ D · D1 — MCP sunucusu: protokol + mandal testleri. | birim |
| 140 | `tests/unit/test_mcp_state_bridge.py` | 25 | FAZ D · D1 — kasa köprüsü: tek kaynak + fail-closed + yerellik. | birim |
| 141 | `tests/unit/test_mcp_tools.py` | 19 | FAZ D · D1 — yetenek → MCP aracı türetimi (tek kaynak kuralı). | birim |
| 142 | `tests/unit/test_media_forensics.py` | 17 | FAZ D · D3 — medya adli hattı servisi: ölçüm, yerellik, dürüst araç yokluğu. | birim |
| 143 | `tests/unit/test_memory_crystal_faz_b.py` | 19 | FAZ B · B2/B3 — HAFIZA KRİSTALİ sözleşme testleri. | birim |
| 144 | `tests/unit/test_memory_injector.py` | 6 | Test adları:  test_fetch_active_rules_no_file, test_fetch_active_rules_empty_file, test_fetch_active_rules_with_rules, test_injection_patterns_are_rejected, test_sanitize_strips_fence_breakers_and_controls, test_f | birim |
| 145 | `tests/unit/test_message_decision_context.py` | 3 | Test adları:  test_message_context_is_stable_typed_and_provenance_gated, test_message_context_limits_and_invalid_timeline_fail_closed, test_pattern_interrupt_requires_valid_context_evidence_ids | birim |
| 146 | `tests/unit/test_minor_gate_api.py` | 28 | ÇOCUK KIRMIZI ÇİZGİSİ — API SINIRI (Faz E / E2). | birim |
| 147 | `tests/unit/test_minor_gate_faz0.py` | 14 | ÇOCUK KIRMIZI ÇİZGİSİ — kabul testleri (Faz 0). | birim |
| 148 | `tests/unit/test_model_chains.py` | 7 | Test adları:  test_default_chains_and_env_overrides, test_query_chain_fallback_on_server_error, test_query_chain_auth_error_does_not_fallback, test_query_json_chain_fallback_on_schema_error, test_depth_analyst_wir | birim |
| 149 | `tests/unit/test_multi_provider_routing.py` | 25 | FAZ 3 — cok-saglayici havuzu sozlesmeleri. | birim |
| 150 | `tests/unit/test_no_decision_run_status.py` | 8 | GÖREV TAMAMLANDI ≠ KARAR ÜRETİLDİ — `completed_no_decision` sözleşmesi. | birim |
| 151 | `tests/unit/test_no_mock_in_production.py` | 7 | Sahte-veri/mock YASAĞI koruma testi (production yolları). | birim |
| 152 | `tests/unit/test_no_placeholder_user_and_verifier_contract.py` | 6 | [009]/[015]/[028]/[014] regression: kullanıcı verisi uydurma + verifier | birim |
| 153 | `tests/unit/test_no_secret_leak.py` | 2 | FAZ 3 / G3.2 — sır sızma kilidi (log redaction). | birim |
| 154 | `tests/unit/test_osint_execution_ownership.py` | 1 | Test adları:  test_router_does_not_schedule_osint_forensic_stamp_twice | birim |
| 155 | `tests/unit/test_osint_investigator.py` | 4 | Test adları:  test_osint_empty_username, test_osint_no_api_key_calls_llm_chain, test_osint_llm_failure_graceful_fallback, test_osint_with_api_key_simulation | birim |
| 156 | `tests/unit/test_p0_repairs.py` | 3 | Test adları:  test_real_executor_uses_real_resonance_calculator, test_resonance_failure_marks_task_failed, test_verifier_without_bio_or_key_is_unverified | birim |
| 157 | `tests/unit/test_p1_1_unavailable_contract.py` | 4 | Test adları:  test_friction_detector_unavailable_contract, test_cognitive_profiler_unavailable_contract, test_authenticity_auditor_unavailable_contract, test_depth_analyst_unavailable_contract | birim |
| 158 | `tests/unit/test_p1_4_url_injection.py` | 3 | P1.4 — URL / argv injection güvenlik testi (köprü bağımsız sürüm). | birim |
| 159 | `tests/unit/test_p1_5_scraper_errors.py` | 11 | P1.5 — Scraper hata zinciri testleri. | birim |
| 160 | `tests/unit/test_p1_6_interpreter_registry.py` | 4 | P1.6 — Interpreter Registry ve Agent KeyError testi. | birim |
| 161 | `tests/unit/test_p1_7_pydantic_v2.py` | 1 | P1.7 — Pydantic V2 Migration | birim |
| 162 | `tests/unit/test_parallel_llm_provenance.py` | 2 | P0 regression tests for call-id based LLM provenance. | birim |
| 163 | `tests/unit/test_passion_mapper.py` | 2 | Test adları:  test_passion_mapper_empty_data, test_passion_mapper_with_data | birim |
| 164 | `tests/unit/test_pattern_interrupt_grounding.py` | 1 | Test adları:  test_pattern_interrupt_returns_unavailable_without_grounded_evidence | birim |
| 165 | `tests/unit/test_pillar_component_failure.py` | 1 | Test adları:  test_component_failure_is_not_converted_to_success_like_bundle | birim |
| 166 | `tests/unit/test_pillar_evidence_adapter.py` | 9 | Test adları:  test_frequency_gravity_and_pulse_keep_source_metrics_uninterpreted, test_seismos_observation_and_hypothesis_are_separate_types, test_void_is_corpus_scoped_and_not_personal_baseline, test_void_scope_d | birim |
| 167 | `tests/unit/test_pillar_failure_policy.py` | 1 | Test adları:  test_pillar_failure_is_evidence_and_halts_by_explicit_policy | birim |
| 168 | `tests/unit/test_pillar_transport_contract.py` | 4 | BOSS-5 — deterministik motor çıktılarının taşınması (sözleşme testi). | birim |
| 169 | `tests/unit/test_provider_aware_agent_chains.py` | 12 | MP-ROUTING: provider-aware agent chains — cost ladder, fail-closed gates. | birim |
| 170 | `tests/unit/test_provider_manager.py` | 9 | Provider registry foundation: scale, isolation, honesty, and SSRF boundaries. | birim |
| 171 | `tests/unit/test_quota_governor.py` | 9 | Quota governor: header-aware rate/token accounting, unknown-as-unknown. | birim |
| 172 | `tests/unit/test_release_gates_workflow.py` | 7 | G7 release-gates workflow yerlesim ve govde sozlesmesi. | birim |
| 173 | `tests/unit/test_report_factory.py` | 10 | FAZ D · D5 — rapor fabrikası servisi: kanıt bağlantısı, mühür, dürüst eksik. | birim |
| 174 | `tests/unit/test_resonance.py` | 11 | Test adları:  test_resonance_calculator_normal, test_resonance_calculator_disjoint, test_resonance_calculator_zero_magnitude, test_resonance_calculator_malformed, test_no_dramatic_verdict_labels_anywhere_in_output | birim |
| 175 | `tests/unit/test_resonance_synthesizer.py` | 6 | ResonanceSynthesizer — kullanıcı bağlamı sözleşmesi. | birim |
| 176 | `tests/unit/test_resonance_vector_provenance.py` | 1 | Test adları:  test_achilles_score_cannot_be_converted_into_target_vector | birim |
| 177 | `tests/unit/test_response_cache.py` | 10 | agent_core.services.response_cache ve LLMGateway cache entegrasyonu testleri. | birim |
| 178 | `tests/unit/test_retina_faz_a.py` | 20 | FAZ A · RETİNA — kabul testleri. | birim |
| 179 | `tests/unit/test_retina_faz_a_wiring.py` | 17 | FAZ A · RETİNA (wiring) — omurganın ÜRETİM yoluna bağlandığının kanıtı. | birim |
| 180 | `tests/unit/test_room_ownership_idor.py` | 16 | [PROD AUDIT 2026-10-11 · P0] IDOR kapatmasını KİLİTLEYEN regresyon testleri. | birim |
| 181 | `tests/unit/test_routed_chat.py` | 20 | Unit contract tests for RoutedChatExecutor (agent_core/services/routed_chat.py). | birim |
| 182 | `tests/unit/test_router_readiness.py` | 2 | Test adları:  test_empty_profile_objects_do_not_schedule_analysis_agents, test_target_text_schedules_target_analysis_but_not_resonance_without_user_evidence | birim |
| 183 | `tests/unit/test_routing_cost_firewall.py` | 8 | FINAL routing firewall over the real RoutedChatExecutor code path. | birim |
| 184 | `tests/unit/test_routing_hardening.py` | 9 | ROUTING-HARDENING — O-gaps kapanislarinin kilit testleri. | birim |
| 185 | `tests/unit/test_routing_shadows.py` | 8 | Routing-shadow contract locks (snapshot + generator + tiers). | birim |
| 186 | `tests/unit/test_run_display_contract.py` | 7 | F2 şeffaflık kontratı — AgentRun serileştirmesi canlı model/via üretir. | birim |
| 187 | `tests/unit/test_rust_runtime_status.py` | 5 | Phase 9 decision B: Rust is CI-validated, not product-integrated. | birim |
| 188 | `tests/unit/test_scraper_temporal_detail.py` | 14 | FAZ 1 — kaziyici zaman boyutu sozlesmeleri. | birim |
| 189 | `tests/unit/test_security_hardening.py` | 16 | Test adları:  test_development_open_auth_is_explicit_in_startup_health, test_production_without_token_cannot_start, test_production_without_spend_cap_cannot_start, test_production_missing_spend_cap_env_cannot_star | birim |
| 190 | `tests/unit/test_security_isolation.py` | 4 | Test adları:  test_canonical_memory_path_traversal, test_hindsight_memory_path_traversal, test_is_safe_url, test_interpreter_endpoint_secure_by_default | birim |
| 191 | `tests/unit/test_shadow_evidence_gate.py` | 5 | [019] ShadowExecutor kanıt kapısı: boş hedefte sahte shadow profili üretilmez. | birim |
| 192 | `tests/unit/test_socid_enricher.py` | 12 | socid-extractor entegrasyon sözleşme testleri. | birim |
| 193 | `tests/unit/test_spectrum_faz_b.py` | 12 | FAZ B · B6 — GERÇEK SPEKTRAL ANALİZ (FFT) sözleşme testleri. | birim |
| 194 | `tests/unit/test_speech_faz_c.py` | 26 | FAZ C · C2 — YEREL SES (TTS) sözleşme testleri. | birim |
| 195 | `tests/unit/test_speech_report_faz_c.py` | 12 | FAZ C · C4 — SESLİ RAPOR: metin kurucu dürüstlüğü. | birim |
| 196 | `tests/unit/test_spend_cap.py` | 2 | OPENROUTER_MAX_SPEND_USD sert tavanı. | birim |
| 197 | `tests/unit/test_status_source_honesty.py` | 20 | Durum/telemetri DÜRÜSTLÜĞÜ — ekrandaki her operasyonel iddianın gerçek bir | birim |
| 198 | `tests/unit/test_stealth_provider.py` | 15 | Stealth sağlayıcı seçici sözleşme testleri (FAZ 5). | birim |
| 199 | `tests/unit/test_streaming_settlement.py` | 5 | Streaming spend settlement: exactly-once, reservation retention, degradation. | birim |
| 200 | `tests/unit/test_task_executor_import_purity.py` | 5 | ``agent_core.task_executor`` İÇE AKTARIM SAFLIĞI sözleşmesi. | birim |
| 201 | `tests/unit/test_task_lifecycle.py` | 10 | Test adları:  test_event_envelope_has_immutable_run_id_and_monotonic_sequence, test_duplicate_event_is_rejected_without_consuming_sequence, test_terminal_event_blocks_later_event_and_state_mutation, test_terminal_ | birim |
| 202 | `tests/unit/test_task_ownership.py` | 18 | [PROD AUDIT 2026-10-12 · P0] GÖREV SAHİPLİĞİ kapatmasını KİLİTLEYEN testler. | birim |
| 203 | `tests/unit/test_task_routing_step1.py` | 11 | Step 1 task-routing locks (config + resolver + gateway precedence). | birim |
| 204 | `tests/unit/test_taste_filter_faz_c.py` | 14 | FAZ C · C1 — JENERİK YANIT FİLTRESİ sözleşme testleri. | birim |
| 205 | `tests/unit/test_threshold_calibration_faz_b.py` | 15 | FAZ B · B5 — EŞİK KALİBRASYONU sözleşme testleri. | birim |
| 206 | `tests/unit/test_tier2_evidence_adapter.py` | 3 | Test adları:  test_allowlisted_human_fields_keep_type_but_not_invented_provenance, test_recommendation_is_strategy_and_ambiguous_outputs_remain_untyped, test_tier2_item_has_source_status_none_without_breaking_nati | birim |
| 207 | `tests/unit/test_tier_variant_gate.py` | 17 | Tier-gate kilitleri (FAZ-1 DENETİM + FAZ-2 ENFORCE) — mechanism-only + audit. | birim |
| 208 | `tests/unit/test_token_compressor_fixture_parity.py` | 3 | Rust ve Python token_compressor implementasyonlarının ORTAK | birim |
| 209 | `tests/unit/test_token_compressor_purity.py` | 2 | token_compressor.py'nin yasaklı bağımlılıklara dokunmadığını | birim |
| 210 | `tests/unit/test_token_optimizer.py` | 11 | Tool-output optimizer safety and protocol-shape regressions. | birim |
| 211 | `tests/unit/test_translation_local.py` | 14 | FAZ D · D4 — çeviri: ses/dinlemeyle AYNI yerellik kuralı. | birim |
| 212 | `tests/unit/test_ui_honesty_contract.py` | 16 | [BOSS-10 + BOSS-12] Arayüz dürüstlüğü sözleşmesi. | birim |
| 213 | `tests/unit/test_uncertainty_b2_regressions.py` | 8 | P1-B2: uncertainty_engine uzunluk-bağımsızlık regresyonları. | birim |
| 214 | `tests/unit/test_uncertainty_data_confidence_gate.py` | 3 | `data_confidence=False` kapısının dürüstlüğü (adım 1: nihai rapor bacağı). | birim |
| 215 | `tests/unit/test_uncertainty_engine.py` | 6 | Test adları:  test_uncertainty_evaluate_safe, test_uncertainty_evaluate_empty_list, test_uncertainty_evaluate_missing_str, test_uncertainty_evaluate_all_empty, test_uncertainty_evaluate_has_absolutes, test_uncerta | birim |
| 216 | `tests/unit/test_uncertainty_evidence_quality.py` | 8 | Forensic [017]/[018]: data_score kanıt kalitesini yansıtmalı. | birim |
| 217 | `tests/unit/test_uncompiled_language_integrity.py` | 2 | Derleyicisi BU ORTAMDA bulunmayan diller için yapısal bütünlük kilidi. | birim |
| 218 | `tests/unit/test_unified_router.py` | 20 | Pure planning, strategy, stickiness, cooldown, and circuit contracts. | birim |
| 219 | `tests/unit/test_usage_settlement.py` | 3 | Fail-closed usage settlement regressions (audit finding: spend-cap bypass). | birim |
| 220 | `tests/unit/test_vault_egress_lock.py` | 19 | KASA MANDALI (Tüzük Md.4) — "kasa kilitli" bir İDDİA değil, çalışan bir kilittir. | birim |
| 221 | `tests/unit/test_vault_providers_schema.py` | 11 | Kasa semasi sozlesmeleri: providers.{ad}.api_key (gercek yerel sema). | birim |
| 222 | `tests/unit/test_verifier_dual_mode.py` | 4 | Test adları:  test_internal_observation_checks_run_without_bio_or_external_search, test_canonical_integrity_mismatch_is_not_a_factual_yalan_verdict, test_without_source_bundle_provenance_is_reported_unverified_not | birim |
| 223 | `tests/unit/test_verifier_entailment_gate.py` | 15 | [RÖNTGEN 2026-09-23] Kanıt kapısı (entailment/provenance) — jüri beyanı yetmez. | birim |
| 224 | `tests/unit/test_verifier_jury_panel.py` | 10 | [BOSS-4] Çapraz jüri paneli — kural artık kodda. | birim |
| 225 | `tests/unit/test_verifier_prompt_injection.py` | 2 | AutonomousVerifier must fence untrusted bio/search text against injection. | birim |
| 226 | `tests/unit/test_verifier_unverified.py` | 4 | P0.2 — AutonomousVerifier: Yetersiz kanıt varsa 1.0 yasak. | birim |
| 227 | `tests/unit/test_version_identity.py` | 14 | Sürüm kimliği sözleşmesi: ``VERSION`` dosyası TEK otoritedir. | birim |
| 228 | `tests/unit/test_vision_analyzer.py` | 1 | Test adları:  test_download_and_encode_image_exception_handling | birim |
| 229 | `tests/unit/test_vision_analyzer_gate.py` | 5 | S2: vision_analyzer, LLMGateway uzerinden cagri yapar. | birim |
| 230 | `tests/unit/test_wave3_honesty_contracts.py` | 19 | Dalga 3 düzeltmelerinin regresyon sözleşmeleri. | birim |
| 231 | `tests/unit/test_wiring_api.py` | 3 | Wiring W4+W5 (backend/api.py): result payload korunmasi + telemetry | birim |
| 232 | `tests/unit/test_wiring_follower.py` | 1 | Wiring W2: follower audit makine-okunur sozlesmesi. | birim |
| 233 | `tests/unit/test_wiring_frontend.py` | 4 | Wiring W1/W2/W3 (frontend): UI yalniz gercek model alanlarini okur. | birim |
| 234 | `tests/unit/test_wiring_timing.py` | 2 | Wiring W1: timing forensics alan sozlesmesi (backend). | birim |

## Grup dağılımı

| Grup | Dosya |
|---|---|
| denetim | 10 |
| kök | 10 |
| e2e | 4 |
| entegrasyon | 32 |
| birim | 178 |

> Test dosyalarının çoğunda modül docstring'i YOKTUR; 'güvence' sütunu test FONKSİYON adlarından üretilmiştir (bu depoda test adları davranış cümlesidir).