# ORTAM DEĞİŞKENLERİ — .env.example'ın TAM çözümlemesi

Toplam **98** değişken.

| # | Değişken | Grup | Varsayılan | Zorunlu | Ne işe yarar | Okuyan dosyalar |
|---|---|---|---|---|---|---|
| 1 | `NINEROUTER_BASE_URL` | 9Router yerel hub (ÖNERİLEN: tüm LLM t | `http://127.0.0.1:20128/v1` | varsayılanlı (zorunlu değil) | 9Router, makinede çalışan OpenAI-uyumlu yerel bir yönlendiricidir (varsayılan uç: http://127.0.0.1:20128/v1). Tanımlıysa gateway trafiği buraya gider ve kanıt zincirine "provider": "9router" yazılır (yerel hub). UYUMLULUK: README'nin tarihs | llm_gateway.py, preflight_9router.py, conftest.py (+2) |
| 2 | `NINEROUTER_API_KEY` | 9Router yerel hub (ÖNERİLEN: tüm LLM t | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, api.py, preflight_9router.py (+4) |
| 3 | `OPENROUTER_API_KEY` | LLM sağlayıcıları | `(boş)` | opsiyonel (kanal açılırsa gerekir) | HİÇBİR anahtar zorunlu/hayati değildir. Her taşıma opsiyoneldir ve yedeklidir: vault (oda anahtarı) > env; hangi sağlayıcı anahtarı doluysa merdiven o kanalı teklif eder; OPENROUTER_API_KEY yalnız OpenRouter havuzu ÜYELİĞİDİR (santrali deği | interpreter_agent.py, llm_gateway.py, routed_chat.py (+25) |
| 4 | `OPENROUTER_TIER_1_MODEL` | Model secimi (2026-09-02 karar matrisi | `anthropic/claude-sonnet-5` | varsayılanlı (zorunlu değil) | Emekli/promo slug'lar (solar-pro4, ling-3.0-flash, glm-5.2) varsayilan DEGIL — yalnizca bilincli override icin kullanin. Kod: agent_core/services/llm_gateway.py | llm_gateway.py, live_llm_gate.py, run_lilith.py (+1) |
| 5 | `OPENROUTER_TIER_2_MODEL` | Model secimi (2026-09-02 karar matrisi | `deepseek/deepseek-v4-flash` | varsayılanlı (zorunlu değil) | (yorum yok) | llm_gateway.py, conftest.py |
| 6 | `OPENROUTER_MAX_SPEND_USD` | Model secimi (2026-09-02 karar matrisi | `0` | varsayılanlı (zorunlu değil) | 0 = sınırsız. >0 ise toplam tahmini USD bu eşiğe ulaşınca SpendCapExceeded. Örnek: OPENROUTER_MAX_SPEND_USD=5.00 → oturum başına max $5 harcama limiti. Aşılırsa SpendCapExceeded fırlatılır ve yeni LLM çağrıları reddedilir. [AUDIT S1] PRODUC | llm_gateway.py, security.py, api.py (+19) |
| 7 | `OPENROUTER_BASE_URL` | Model secimi (2026-09-02 karar matrisi | `https://openrouter.ai/api/v1` | varsayılanlı (zorunlu değil) | OpenAI-uyumlu gateway ve tek istek timeout'u (gateway retry siniri 3'tur). | llm_gateway.py, api.py, run_lilith.py (+3) |
| 8 | `LLM_REQUEST_TIMEOUT_SECONDS` | Model secimi (2026-09-02 karar matrisi | `45` | varsayılanlı (zorunlu değil) | (yorum yok) | llm_gateway.py |
| 9 | `LIVE_LLM_E2E` | Model secimi (2026-09-02 karar matrisi | `0` | varsayılanlı (zorunlu değil) | Guvenlik kapisi: 1 degilken dis LLM cagrileri kod tarafindan reddedilir. Canli LLM kullanmak icin: anahtar girin ve asagiyi 1 yapin. | llm_gateway.py, routed_chat.py, api.py (+26) |
| 10 | `USE_LOCAL_LLM` | Yerel LLM (opsiyonel: Ollama / LM Stud | `false` | varsayılanlı (zorunlu değil) | Not: API sunucusunda Kasa (Vault) "yerel model" seçimi bu değeri ezer; env varsayılanı yalnız Kasa'dan use_local seçilmemişse kullanılır. | llm_gateway.py, routed_chat.py, api.py (+11) |
| 11 | `LOCAL_LLM_URL` | Yerel LLM (opsiyonel: Ollama / LM Stud | `http://localhost:11434/v1` | varsayılanlı (zorunlu değil) | (yorum yok) | llm_gateway.py, local_jury.py, test_jury_api_faz_d.py (+2) |
| 12 | `LOCAL_LLM_MODEL` | Yerel LLM (opsiyonel: Ollama / LM Stud | `dolphin-llama3:latest` | varsayılanlı (zorunlu değil) | (yorum yok) | llm_gateway.py, local_jury.py, routed_chat.py (+3) |
| 13 | `PINEAL_LLM_BACKEND` | Native LLM yönlendirici | `unified` | varsayılanlı (zorunlu değil) | PINEAL_LLM_BACKEND=unified -> /v1/chat/completions UnifiedRouter üzerinden çalışır (varsayılan). Config dosyası yoksa katalog + env anahtarlarından otomatik runtime kurulur (OpenRouter her zaman; Ollama USE_LOCAL_LLM=true ise; Groq/DeepSeek | routed_chat.py, api.py, test_openai_compatibility.py (+2) |
| 14 | `PINEAL_ROUTER_CONFIG` | Native LLM yönlendirici | `(boş)` | belirsiz (boş bırakılmış) | İsteğe bağlı dosya override: config/router.example.json. Boş bırakılırsa katalogdan otomatik config kullanılır. Dosyadaki credential_env ile işaret edilen anahtarlar (örn. OPENROUTER_API_KEY) ayrıca tanımlanmalıdır. | routed_chat.py, api.py, generate_inventory_page.py (+1) |
| 15 | `PINEAL_ALLOW_PAID_ESCALATION` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `0` | varsayılan KAPALI kapı | Tier kuralları (agent_tiers.json -> _tier_route_decision; FAZ-2/FAZ-2.1 kilitli): simple : paid rota (direct veya OR-legacy) HARD DENY — yalnız free teklif edilir. heavy/vision/verify: indirimli direct (ör. claude-sonnet-5@nous $1.6/$8) esc | final_routing_policy.py, llm_gateway.py, routed_chat.py (+11) |
| 16 | `PINEAL_ALLOW_UNPRICED_MODELS` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `0` | varsayılan KAPALI kapı | Fiyatı katalogda/ROUTES'ta olmayan modele çağrı yalnız açık izinle: | llm_gateway.py, live_llm_gate.py, generate_inventory_page.py (+8) |
| 17 | `GROQ_API_KEY` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `# openai/gpt-oss-120b (30 RPM / 14,400 RPD)` | opsiyonel (kanal açılırsa gerekir) | FINAL matrix sağlayıcıları (anahtar doluysa ilgili rota kullanılabilir): | llm_gateway.py, routed_chat.py, live_provider_probe.py (+9) |
| 18 | `DEEPSEEK_API_KEY` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `# deepseek-v4-* doğrudan API (agent yolunun maliyet merdiveni;` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, routed_chat.py, live_provider_probe.py (+8) |
| 19 | `CEREBRAS_API_KEY` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `# gpt-oss-120b (5 RPM / 30K TPM / 1M TPD) — paid rota` | opsiyonel (kanal açılırsa gerekir) | Cerebras açık free katmanı 2026-07-21'de KAPANDI (araştırma 2026-09-08): gpt-oss-120b@cerebras artık PAID ($0.35/$0.75) — yalnız PINEAL_ALLOW_PAID_ESCALATION=1 ile kullanılır; ücretsiz kanal Groq'tur. | llm_gateway.py, routed_chat.py, live_provider_probe.py (+7) |
| 20 | `NOUS_API_KEY` | FINAL-KARAR-MATRIX: FREE-FIRST cost fi | `# nous-research free/paid rotaları (policy-gated)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, routed_chat.py, run_lilith.py (+11) |
| 21 | `MISTRAL_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | Asagidaki anahtarlar DOLDURULMADIKCA havuzda gorunmez (diagnostics: no_key). Anahtar + model eslesmesi + policy kapisi (paid -> PINEAL_ALLOW_PAID_ESCALATION=1) birlikte saglanmadan trafik yayilmaz; sessiz harcama uretilmez. | llm_gateway.py, routed_chat.py, conftest.py (+1) |
| 22 | `TOGETHER_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, routed_chat.py, live_provider_probe.py (+2) |
| 23 | `FIREWORKS_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, routed_chat.py, conftest.py (+1) |
| 24 | `DASHSCOPE_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `# alibaba-dashscope (OpenAI-uyumlu endpoint)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, routed_chat.py, conftest.py |
| 25 | `SAMBANOVA_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, conftest.py |
| 26 | `NVIDIA_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `# nvidia-nim (nvapi-... anahtarlari; standart ad)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, live_provider_probe.py, conftest.py (+2) |
| 27 | `HUGGINGFACE_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, conftest.py |
| 28 | `DEEPINFRA_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, live_provider_probe.py, conftest.py |
| 29 | `PERPLEXITY_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, conftest.py |
| 30 | `GEMINI_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `# google-gemini — Google'in RESMI OpenAI-uyumlu` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, api.py, live_provider_probe.py (+6) |
| 31 | `IFLOW_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `# tasiyici bilinmiyor -> tani-only (baz URL gerekli, bkz. asagi)` | opsiyonel (kanal açılırsa gerekir) | Katalogda `models` bos olan saglayiciya operator beyaniyla model acilir (ornek: PINEAL_PROVIDER_MODELS_TOGETHER="acme/m7"). Beyan, firewall/cap/ kota kapilarini ATLAMAZ; uydurma katalog girdisi yazilmaz. PINEAL_PROVIDER_MODELS_MISTRAL= PINE | llm_gateway.py, test_multi_provider_routing.py |
| 32 | `GEMINI_BACKUP_API_KEY` | FAZ 3: cok-saglayici havuzu (ajan yolu | `(boş)` | opsiyonel (kanal açılırsa gerekir) | FAZ-2-P4 (2026-09-08): GEMINI_BACKUP_API_KEY artik DIRECT — ayni Google endpoint'inin 2. anahtari; birincil 429/limit verince merdiven otomatik backup'a duser (google-gemini-backup, ROUTES paid $0.75/$3.75). | llm_gateway.py, api.py, conftest.py (+2) |
| 33 | `GEMINI_VERTEX_TOKEN` | FAZ 3: cok-saglayici havuzu (ajan yolu | `# vertex farkli base/protokol ister -> tani-only (canli dogrulama sonrasi)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | llm_gateway.py, conftest.py, test_google_gemini_direct.py (+1) |
| 34 | `TAVILY_API_KEY` | Arama (AutonomousVerifier; Tavily / Se | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | search_engine.py, api.py, test_six_stamps_integration.py (+4) |
| 35 | `SERPAPI_API_KEY` | Arama (AutonomousVerifier; Tavily / Se | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | search_engine.py, api.py, test_six_stamps_integration.py (+3) |
| 36 | `EXA_API_KEY` | Arama (AutonomousVerifier; Tavily / Se | `(boş)` | opsiyonel (kanal açılırsa gerekir) | (yorum yok) | search_engine.py, api.py, test_six_stamps_integration.py (+3) |
| 37 | `PINEAL_REQUIRE_AUTH` | Guvenlik (FAZ 8) | `false` | varsayılanlı (zorunlu değil) | [AUDIT P2-10] Varsayilan artik FAIL-CLOSED: PINEAL_ENV yalnizca asagidaki ACIK degerlerden biriyse gelistirme sayilir -> development / dev / local / localhost / test / testing / ci Bos, yazim-hatali veya taninmayan HER deger (production, pr | security.py, test_production_audit_findings.py, conftest.py (+1) |
| 38 | `PINEAL_TOKEN` | Guvenlik (FAZ 8) | `(boş)` | opsiyonel (kanal açılırsa gerekir) | Tanimlanirsa tum /api/* X-API-Key ister. WS anahtari URL'ye degil ilk mesaja yazilir. | security.py, api.py, principal.py (+17) |
| 39 | `PINEAL_ALLOWED_ORIGINS` | Guvenlik (FAZ 8) | `(boş)` | belirsiz (boş bırakılmış) | [AUDIT N7] Hiz siniri KIMLIGI: token sunulan istekte = token; token'siz istekte (yalniz development modunda mumkun) = istemci IP. Reverse proxy arkasinda (tum trafik tek IP) token'siz kullanicilar AYNI rate kovasini paylasir ve birbirini bl | api.py |
| 40 | `PINEAL_OPERATOR_TOKENS` | Cok-operator kimligi (oda sahipligi) | `(boş)` | belirsiz (boş bırakılmış) | Her operator KENDI token'ini alir; token bir kimlige (principal) cozulur ve oda o kimlige baglanir. Baska bir operatorin odasina erisim 403 doner. ONEMLI: PINEAL_OPERATOR_TOKENS TANIMLI DEGILSE tum operatorler ayni PINEAL_TOKEN'i paylasir - | security.py, principal.py, task_ownership.py (+3) |
| 41 | `REDIS_URL` | Cok-operator kimligi (oda sahipligi) | `(boş)` | belirsiz (boş bırakılmış) | Redis (Agent Rack canli koprusu / Pub-Sub). docker-compose icinde `redis://redis:6379/0` olarak SABITTIR; compose DISI kurulumda (Railway vb.) buradan verilmelidir. Bos/erisilemezse sistem COPMEZ: surec-ici bellege duser ve /api/telemetry ` | redis_bus.py, agent_worker.py, api.py |
| 42 | `PINEAL_MAX_ROOMS` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `512` | varsayılanlı (zorunlu değil) | client_id istemcinin sectigi bir string oldugu icin bu tavanlar olmadan tek bir istemci sinirsiz oda (her biri tam bir executor) ve sinirsiz hiz-siniri kovasi uretebilirdi. Asagidaki degerler olculen sizintiyi sinirlar. | api.py |
| 43 | `PINEAL_ROOM_TTL_SECONDS` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `1800` | varsayılanlı (zorunlu değil) | (yorum yok) | api.py |
| 44 | `PINEAL_MAX_CLIENT_ID_LENGTH` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `64` | varsayılanlı (zorunlu değil) | (yorum yok) | api.py |
| 45 | `PINEAL_MAX_RATE_BUCKETS` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `100000` | varsayılanlı (zorunlu değil) | (yorum yok) | api.py |
| 46 | `PINEAL_RATE_SWEEP_INTERVAL_SECONDS` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `60` | varsayılanlı (zorunlu değil) | Gorev kimligi tavani (8..4096'ya kirpilir; bozuk deger acilisi patlatmaz). TEK sozlesme: backend/security/task_access.py::MAX_TASK_ID_LENGTH. PINEAL_MAX_TASK_ID_LENGTH=128 [AUDIT P0-5 v3] Süresi dolmuş hız-kovası girdileri YALNIZCA tavanda  | api.py |
| 47 | `PINEAL_CACHE_MAX_ROWS` | Kaynak tavani (AUDIT P0-2 / P0-4 / P0- | `50000` | varsayılanlı (zorunlu değil) | Yanit onbellegi satir tavani (TTL'den bagimsiz ikinci emniyet kemeri) | response_cache.py |
| 48 | `OPENROUTER_VISION_MODEL` | Vision (FAZ 3) | `google/gemini-3.7-flash` | varsayılanlı (zorunlu değil) | Gorselli isteklerde kullanilacak OpenRouter modeli | llm_gateway.py, conftest.py |
| 49 | `PINEAL_RESPONSE_CACHE` | Cache / Hafiza (opsiyonel) | `1` | varsayılanlı (zorunlu değil) | LLM yanit onbellegi (1=acik, 0=kapali); varsayilan acik | response_cache.py, conftest.py, test_gateway_cost_and_retry.py (+1) |
| 50 | `PINEAL_MEMORY_ENGINE` | Cache / Hafiza (opsiyonel) | `canonical` | varsayılanlı (zorunlu değil) | Bellek motoru: canonical (varsayilan) / hindsight (anlamsal arama, sentence-transformers gerekir) | dependency_health.py, hindsight_memory.py, test_dependency_health.py (+1) |
| 51 | `ENABLE_MAIGRET` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `false            # kullanici-adi varlik taramasi (POST /api/experimental/maigret/scan)` | varsayılan KAPALI kapı | Her kapisi acmak yeni ag cagrilari acar; kapaliyken pipeline davranisi degismez. | osint_investigator.py, __init__.py, adapters_osint.py (+15) |
| 52 | `MAIGRET_SITES_LIMIT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `100         # 1..500` | varsayılanlı (zorunlu değil) | (yorum yok) | maigret_scanner.py |
| 53 | `MAIGRET_TIMEOUT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `15              # s/site (max 60)` | varsayılanlı (zorunlu değil) | (yorum yok) | maigret_scanner.py |
| 54 | `MAIGRET_TOTAL_TIMEOUT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `45        # s (max 180)` | varsayılanlı (zorunlu değil) | (yorum yok) | maigret_scanner.py, test_maigret_scanner.py |
| 55 | `PINEAL_MAIGRET_DB` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `# ornek: memory/maigret_db_refreshed.json` | varsayılanlı (zorunlu değil) | [A8] Tazelenmis site listesi: python -m agent_core.services.maigret_db_refresh ile uretilir (WhatsMyName/sherlock verisi). Doluysa tarama bu dosyadan kosar ve sonuc db_source + db_sites olarak raporlanir; bos = paketlenmis DB. Bozuk dosyada | adapters_osint.py, maigret_db_refresh.py, maigret_scanner.py (+2) |
| 56 | `ENABLE_HOLEHE` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `false             # e-posta kayit taramasi (POST /api/experimental/holehe/scan)` | varsayılan KAPALI kapı | (yorum yok) | osint_investigator.py, adapters_osint.py, state.py (+9) |
| 57 | `HOLEHE_MODULES_LIMIT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `100        # 1..300 (deterministik isim-sirali ilk N)` | varsayılanlı (zorunlu değil) | (yorum yok) | holehe_scanner.py, test_holehe_scanner.py |
| 58 | `HOLEHE_TIMEOUT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `10               # s (max 60)` | varsayılanlı (zorunlu değil) | (yorum yok) | holehe_scanner.py |
| 59 | `HOLEHE_TOTAL_TIMEOUT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `120        # s (max 600)` | varsayılanlı (zorunlu değil) | (yorum yok) | holehe_scanner.py |
| 60 | `HOLEHE_CONCURRENCY` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `20           # eszamanli modul (max 50)` | varsayılanlı (zorunlu değil) | (yorum yok) | holehe_scanner.py |
| 61 | `ENABLE_CRAWL4AI` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `false           # sayfa -> LLM-dostu metin (POST /api/experimental/crawl/fetch)` | varsayılan KAPALI kapı | (yorum yok) | adapters_web.py, state.py, crawl_enricher.py (+7) |
| 62 | `CRAWL4AI_RENDERER` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `http          # http (binary gerektirmez) | browser (Playwright; binary yoksa browser_missing)` | varsayılanlı (zorunlu değil) | (yorum yok) | crawl_enricher.py, test_crawl_enricher.py |
| 63 | `CRAWL4AI_MAX_CHARS` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `8000         # metin kirpma (max 50000)` | varsayılanlı (zorunlu değil) | (yorum yok) | crawl_enricher.py, test_crawl_enricher.py |
| 64 | `CRAWL4AI_TIMEOUT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `20             # s (max 120)` | varsayılanlı (zorunlu değil) | (yorum yok) | crawl_enricher.py |
| 65 | `CRAWL4AI_RESEARCH_LIMIT` | OSINT entegrasyonlari (FAZ 1-5; hepsi  | `2       # public-web arastirmada kac sonuca crawl (max 5)` | varsayılanlı (zorunlu değil) | (yorum yok) | crawl_enricher.py, test_crawl_enricher.py |
| 66 | `ENABLE_SCRAPLING` | FAZ A · RETINA yetenek kapilari (hepsi | `false          # 3. kademe adaptif kazima (site degisse de kirilmaz)` | varsayılan KAPALI kapı | Kapaliyetenek: available=false + makine-okunur sebep; sistemin geri kalani birebir ayni calisir (uydurma veri yok). Kutuphaneler Ucuncu adim dosyasi: pip install -r requirements-retina.txt (ISTEGE BAGLI) | adapters_web.py, state.py, test_language_capabilities.py (+1) |
| 67 | `ENABLE_X_SENSOR` | FAZ A · RETINA yetenek kapilari (hepsi | `false           # X/Twitter gercek sensoru (twscrape; operatörün kendi hesabi)` | varsayılan KAPALI kapı | (yorum yok) | adapters_sensors.py, state.py, test_retina_faz_a.py (+1) |
| 68 | `ENABLE_IG_SECONDARY` | FAZ A · RETINA yetenek kapilari (hepsi | `false       # Instagram IKINCI kaynak (instagrapi; birincil Playwright)` | varsayılan KAPALI kapı | (yorum yok) | adapters_sensors.py, state.py, test_retina_faz_a.py |
| 69 | `IG_USERNAME` | FAZ A · RETINA yetenek kapilari (hepsi | `# ENABLE_IG_SECONDARY icin` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_sensors.py, platform_registry.py, test_retina_faz_a.py |
| 70 | `IG_PASSWORD` | FAZ A · RETINA yetenek kapilari (hepsi | `# ENABLE_IG_SECONDARY icin (log/kanit/telemetriye yazilmaz)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_sensors.py, test_retina_faz_a.py |
| 71 | `ENABLE_AGENT_REACH` | FAZ A · RETINA yetenek kapilari (hepsi | `false        # harici CLI: agent-reach read (X/Reddit/YouTube/GitHub)` | varsayılan KAPALI kapı | (yorum yok) | adapters_sensors.py, adapters_web.py, state.py (+2) |
| 72 | `ENABLE_SEARXNG` | FAZ A · RETINA yetenek kapilari (hepsi | `false            # anahtarsiz metasearch (AYRI SERVIS, AGPL-3.0)` | varsayılan KAPALI kapı | (yorum yok) | adapters_sensors.py, state.py, search_engine.py (+2) |
| 73 | `SEARXNG_BASE_URL` | FAZ A · RETINA yetenek kapilari (hepsi | `# ornek: http://127.0.0.1:8080 (kod gomulmez, yalniz HTTP)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_sensors.py, search_engine.py, test_retina_faz_a.py (+1) |
| 74 | `ENABLE_LOCAL_TTS` | FAZ C · SES & NEFES (C2 yerel TTS; ses | `false          # ses kapisi (kapaliyken hicbir motor cagrilmaz)` | varsayılan KAPALI kapı | Motor iki yoldan biriyle bulunur; ikisi de YERELDIR: 1) piper CLI -> PINEAL_PIPER_MODEL dolu olmali (piper PATH'te) 2) yerel TTS ucu -> PINEAL_TTS_URL (VoxCPM / MOSS-TTS / her yerel sunucu). Yalniz 127.0.0.1 / localhost / [::1] kabul edilir | adapters_voice.py, speech.py, test_speech_api_faz_c.py (+2) |
| 75 | `PINEAL_PIPER_MODEL` | FAZ C · SES & NEFES (C2 yerel TTS; ses | `# ornek: /opt/piper/tr-TR-fahrettin-medium.onnx` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py, test_speech_faz_c.py |
| 76 | `PINEAL_TTS_URL` | FAZ C · SES & NEFES (C2 yerel TTS; ses | `# ornek: http://127.0.0.1:8000/tts (YEREL olmak zorunda)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py, test_speech_api_faz_c.py, test_speech_faz_c.py |
| 77 | `PINEAL_TTS_VOICE` | FAZ C · SES & NEFES (C2 yerel TTS; ses | `# motorun konus/mac birimi (bos = motor varsayilani)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py |
| 78 | `PINEAL_SPEECH_DIR` | FAZ C · SES & NEFES (C2 yerel TTS; ses | `# bos = memory/speech (uretilen ses dosyalari)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py, conftest.py, test_speech_api_faz_c.py (+2) |
| 79 | `ENABLE_LOCAL_STT` | FAZ C · C3 DİNLEYEN GÖZ (yerel STT + m | `false          # dinleme kapisi (kapaliyken hicbir motor cagrilmaz)` | varsayılan KAPALI kapı | Mikrofon kaydi TARAYICIDA tutulur; yalniz transkript icin YEREL motora gider. Motor iki yoldan biriyle bulunur; ikisi de YERELDIR: 1) yerel STT ucu -> PINEAL_STT_URL (yalniz 127.0.0.1 / localhost / [::1]) 2) whisper CLI -> PINEAL_STT_CMD (b | adapters_voice.py, speech.py, test_speech_api_faz_c.py (+1) |
| 80 | `PINEAL_STT_URL` | FAZ C · C3 DİNLEYEN GÖZ (yerel STT + m | `# ornek: http://127.0.0.1:9000/stt (YEREL olmak zorunda)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py, test_speech_api_faz_c.py, test_speech_faz_c.py |
| 81 | `PINEAL_STT_CMD` | FAZ C · C3 DİNLEYEN GÖZ (yerel STT + m | `# bos = whisper (PATH'te olmali)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py |
| 82 | `PINEAL_STT_MODEL` | FAZ C · C3 DİNLEYEN GÖZ (yerel STT + m | `# bos = base (tiny|base|small|medium|large)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py |
| 83 | `PINEAL_STT_LANG` | FAZ C · C3 DİNLEYEN GÖZ (yerel STT + m | `# bos = tr (dil ipucu; motor desteklemezse yok sayilir)` | varsayılanlı (zorunlu değil) | (yorum yok) | adapters_voice.py |
| 84 | `ENABLE_LOCAL_TRANSLATE` | FAZ D · D4 DİL (tespit deterministik;  | `false    # cevirme kapisi (kapaliyken motor cagrilmaz)` | varsayılan KAPALI kapı | Tespit (POST /api/language/detect) modelsiz/agssizdir: Unicode yazı sistemi + durma sozcukleri. Sinyal yoksa etiket UYDURULMAZ: language=unknown + sebep. Ceviri (POST /api/language/translate) ses/dinlemeyle AYNI kurala baglidir: 1) yerel ce | adapters_language.py, state.py, translation.py (+7) |
| 85 | `PINEAL_TRANSLATE_URL` | FAZ D · D4 DİL (tespit deterministik;  | `# ornek: http://127.0.0.1:9100/translate (YEREL)` | varsayılanlı (zorunlu değil) | (yorum yok) | translation.py, test_language_api_faz_d.py, test_language_capabilities.py (+1) |
| 86 | `PINEAL_TRANSLATE_CMD` | FAZ D · D4 DİL (tespit deterministik;  | `# bos = trans (translate-shell; PATH'te olmali)` | varsayılanlı (zorunlu değil) | (yorum yok) | translation.py, test_language_api_faz_d.py, test_language_capabilities.py (+1) |
| 87 | `STEALTH_PROVIDER` | Stealth saglayici secici (FAZ 5; kapı  | `playwright_stealth` | varsayılanlı (zorunlu değil) | playwright_stealth (default, bugunku davranis) / invisible / cloak / none | platform_registry.py, stealth_provider.py, api.py (+1) |
| 88 | `INVISIBLE_BROWSER_BINARY` | Stealth saglayici secici (FAZ 5; kapı  | `# patched Firefox yolu (opsiyonel)` | varsayılanlı (zorunlu değil) | invisible/cloak binary INDIRMEZ; operator gosterirse available olur: | stealth_provider.py |
| 89 | `CLOAK_BROWSER_EXECUTABLE` | Stealth saglayici secici (FAZ 5; kapı  | `# CloakBrowser Chromium yolu (opsiyonel)` | varsayılanlı (zorunlu değil) | (yorum yok) | stealth_provider.py |
| 90 | `PINEAL_CHROMIUM_PATH` | Stealth saglayici secici (FAZ 5; kapı  | `(boş)` | belirsiz (boş bırakılmış) | Kokpit LCD canlı tarayıcısı: playwright chromium indirmeden sistem Chromium'unu kullanır (örn. /usr/bin/chromium). Boşsa playwright binary'si. | browser_session.py, api.py |
| 91 | `OSINT_INDUSTRIES_KEY` | Diger kullanilan ama orneklenmemis deg | `# doluysa osint_investigator gercek API'yi kullanir; bossa durust fallback` | varsayılanlı (zorunlu değil) | (yorum yok) | osint_investigator.py, test_support_flow_acceptance.py, test_holehe_scanner.py (+2) |
| 92 | `ENABLE_INTERPRETER` | Diger kullanilan ama orneklenmemis deg | `false        # interpreter ajanini etkinlestirir` | varsayılan KAPALI kapı | (yorum yok) | interpreter_agent.py, cognitive_router.py, dependency_health.py (+6) |
| 93 | `ALLOW_LOCAL_TO_CLOUD_FALLBACK` | Diger kullanilan ama orneklenmemis deg | `# bos bos; yerel-LLM yoksa buluta dusme izni (false: dusmez)` | varsayılanlı (zorunlu değil) | (yorum yok) | llm_gateway.py |
| 94 | `SERPAPI_KEY` | Diger kullanilan ama orneklenmemis deg | `# arama saglayici (SERPAPI_API_KEY'a alternatif okuma adi)` | varsayılanlı (zorunlu değil) | (yorum yok) | api.py, test_forensic_closers_vault_rack_gravity_carrier.py, test_vault_egress_lock.py |
| 95 | `PINEAL_MIN_SCRAPER_CONFIDENCE` | Instagram kaziyici: guven + zamansal z | `0.6  # 0.0..1.0; altinda HALT (anti-halusinasyon kapisi)` | varsayılanlı (zorunlu değil) | (yorum yok) | platform_registry.py, test_auditor_round2_findings.py, test_production_audit_findings.py |
| 96 | `PINEAL_POST_DETAIL_ENABLED` | Instagram kaziyici: guven + zamansal z | `true    # tekil post sayfalarindan caption/tarih/etkilesim tamamla` | varsayılanlı (zorunlu değil) | (yorum yok) | instagram_ghost.py, test_scraper_temporal_detail.py |
| 97 | `PINEAL_POST_DETAIL_LIMIT` | Instagram kaziyici: guven + zamansal z | `12        # 0..12; 0 = grid-verisiyle yetin (eski davranis)` | varsayılanlı (zorunlu değil) | (yorum yok) | instagram_ghost.py, test_scraper_temporal_detail.py |
| 98 | `PLAYWRIGHT_DOWNLOAD_HOST` | Docker build (build-time; runtime'i et | `(boş)` | belirsiz (boş bırakılmış) | Chromium indirmesi (cdn.playwright.dev) bolgenizde engelliyse/yavamsa ayna. Dockerfile 3 kez dener + 300 sn baglanti t/o kullanir; bu degisken ek ayna saglar. Ornek: PLAYWRIGHT_DOWNLOAD_HOST=https://cdn.npmmirror.com/binaries/playwright | — |

## Kodun okuduğu ama .env.example'da GEÇMEYEN adlar

- `AGENT_ID`
- `AGENT_NAME`
- `BACKEND_URL`
- `ENABLE_CROSS_PLATFORM`
- `OPENAI_API_KEY`
- `OPENAI_BASE_URL`
- `OPENROUTER_JUDGE_MODEL`
- `PINEAL_AGENT_TIERS_PATH`
- `PINEAL_CACHE_PATH`
- `PINEAL_CACHE_PRUNE_INTERVAL_SECONDS`
- `PINEAL_CACHE_TTL`
- `PINEAL_CALIB_DIR`
- `PINEAL_CALIB_MIN_SAMPLES`
- `PINEAL_CALIB_OBSERVE`
- `PINEAL_CHECKPOINT_PATH`
- `PINEAL_CRYSTAL`
- `PINEAL_CRYSTAL_DIR`
- `PINEAL_CRYSTAL_K`
- `PINEAL_CRYSTAL_MAX`
- `PINEAL_EMBEDDING_MODEL`
- `PINEAL_HARVESTER_CMD`
- `PINEAL_HARVESTER_SOURCES`
- `PINEAL_JURY_BINDING`
- `PINEAL_JURY_QUORUM`
- `PINEAL_LEARNINGS_BACKUP_KEEP`
- `PINEAL_LIFECYCLE_RETENTION_SECONDS`
- `PINEAL_MAX_BODY_BYTES`
- `PINEAL_MEDIA_DIR`
- `PINEAL_MEMORY_DB`
- `PINEAL_MINOR_LEDGER_PATH`
- `PINEAL_PROVIDER_COOLDOWN_SECONDS`
- `PINEAL_PROVIDER_FAILURE_THRESHOLD`
- `PINEAL_REPORT_DIR`
- `PINEAL_ROOM_ACTIVE_TASKS_CAP`
- `PINEAL_ROUTER_LIVE`
- `PINEAL_ROUTE_INTERPRETER`
- `PINEAL_ROUTING_STRATEGY`
- `PINEAL_RTK_ENABLED`
- `PINEAL_TASK_MAX_ATTEMPTS`
- `PINEAL_TASK_TIMEOUT_SECONDS`
- `PINEAL_TASTE_LOG`
- `PINEAL_TELEMETRY_DIR`
- `PINEAL_TOOL_OPTIMIZATION`
- `PINEAL_TRANSCRIBE_CMD`
- `PINEAL_TRANSCRIBE_URL`
- `PINEAL_VAULT_FILE`

## frontend/.env.example

```
# Dev: vite (5173) -> backend (8000) icin asagidakini acin:
# VITE_API_BASE=http://127.0.0.1:8000

# [AUDIT 2026-09-11 P0] Build-time token gomme kaldirildi: PINEAL_TOKEN
# bundle'a asla gomulmez. UI token'i calisma zamaninda Kasa ekranindan girilir.
```