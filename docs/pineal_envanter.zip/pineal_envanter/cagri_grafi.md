# ÇAĞRI GRAFİĞİ — `agent_core/task_executor.py`'den başlayan ağaç

Okuma biçimi: her satır bir modül; girintili satırlar onun İÇE AKTARDIKLARI (çağırabildikleri). Statik `import` ilişkisidir; `importlib`/`__import__` dinamik çağrıları ayrıca işaretlenir.

## 1) Ana ağaç (derinlik 2)
```
- agent_core/task_executor.py  (2693 satır)
  - agent_core/agents/authenticity_auditor.py  (115 satır)
    - agent_core/services/llm_gateway.py  (3241 satır)
      - … (8 içe aktarım daha; derinlik sınırı)
    - agent_core/services/upstream_findings.py  (87 satır)
  - agent_core/agents/autonomous_verifier.py  (966 satır)
    - agent_core/domain/evidence_models.py  (90 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/services/claim_decision_gate.py  (204 satır)
    - agent_core/services/jury_consensus.py  (191 satır)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/pillar_evidence_adapter.py  (617 satır)
      - … (4 içe aktarım daha; derinlik sınırı)
    - agent_core/services/quote_guard.py  (330 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/services/tier2_evidence_adapter.py  (161 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/agents/cognitive_profiler.py  (29 satır)
    - agent_core/agents/target_psyche_profiler.py  (310 satır)
      - … (3 içe aktarım daha; derinlik sınırı)
    - agent_core/domain/memory_models.py  (183 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/agents/depth_analyst.py  (189 satır)
    - agent_core/services/quote_guard.py  (330 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
  - agent_core/agents/friction_detector.py  (28 satır)
    - agent_core/agents/target_psyche_profiler.py  (310 satır)  ↩ (yukarıda görüldü)
    - agent_core/domain/memory_models.py  (183 satır)  ↩ (yukarıda görüldü)
  - agent_core/agents/human_behavior.py  (540 satır)
    - agent_core/capabilities/egress.py  (135 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
    - agent_core/utils/security.py  (500 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/agents/interpreter_agent.py  (118 satır)
  - agent_core/agents/mirror_truth.py  (177 satır)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
  - agent_core/agents/osint_investigator.py  (339 satır)
    - agent_core/capabilities/__init__.py  (67 satır)
      - … (4 içe aktarım daha; derinlik sınırı)
    - agent_core/capabilities/state.py  (93 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/capabilities/timeline_bridge.py  (63 satır)
      - … (3 içe aktarım daha; derinlik sınırı)
    - agent_core/safety/__init__.py  (32 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/scraper/vault_gate.py  (212 satır)
    - agent_core/services/holehe_scanner.py  (263 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/maigret_scanner.py  (323 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/agents/passion_mapper.py  (25 satır)
    - agent_core/agents/target_psyche_profiler.py  (310 satır)  ↩ (yukarıda görüldü)
    - agent_core/domain/memory_models.py  (183 satır)  ↩ (yukarıda görüldü)
  - agent_core/agents/pattern_interrupt.py  (250 satır)
    - agent_core/domain/message_context_models.py  (48 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/services/timing_forensics.py  (233 satır)
    - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
  - agent_core/agents/resonance_calculator.py  (546 satır)
  - agent_core/agents/resonance_synthesizer.py  (168 satır)
    - agent_core/domain/memory_models.py  (183 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
  - agent_core/capabilities/egress.py  (135 satır)  ↩ (yukarıda görüldü)
  - agent_core/config_loader.py  (101 satır)
  - agent_core/domain/evidence_models.py  (90 satır)  ↩ (yukarıda görüldü)
  - agent_core/domain/memory_models.py  (183 satır)  ↩ (yukarıda görüldü)
  - agent_core/domain/message_context_models.py  (48 satır)  ↩ (yukarıda görüldü)
  - agent_core/domain/pipeline_status.py  (25 satır)
  - agent_core/domain/responsibility.py  (242 satır)
  - agent_core/engines/pillar_orchestrator.py  (70 satır)
    - agent_core/domain/pillar_models.py  (160 satır)
    - agent_core/domain/pillar_wave2_models.py  (129 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/frequency_engine.py  (192 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/gravity_engine.py  (81 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/key_engine.py  (92 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/pulse_engine.py  (59 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/seismos_engine.py  (118 satır)
      - … (2 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/strata_engine.py  (91 satır)
      - … (4 içe aktarım daha; derinlik sınırı)
    - agent_core/engines/void_engine.py  (103 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/schemas/telemetry.py  (115 satır)
  - agent_core/services/__init__.py  (5 satır)
  - agent_core/services/agent_status_tracker.py  (165 satır)
    - agent_core/services/redis_bus.py  (165 satır)
  - agent_core/services/canonical_memory.py  (365 satır)
    - agent_core/utils/security.py  (500 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/change_tracker.py  (293 satır)
  - agent_core/services/claim_decision_gate.py  (204 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/cognitive_router.py  (175 satır)
  - agent_core/services/decision_engine.py  (139 satır)
    - agent_core/config_loader.py  (101 satır)  ↩ (yukarıda görüldü)
    - agent_core/domain/memory_models.py  (183 satır)  ↩ (yukarıda görüldü)
    - agent_core/domain/pipeline_status.py  (25 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/uncertainty_engine.py  (347 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
  - agent_core/services/evidence_timeline.py  (118 satır)
    - agent_core/domain/evidence_models.py  (90 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/follower_audit.py  (117 satır)
  - agent_core/services/hindsight_memory.py  (334 satır)
    - agent_core/services/canonical_memory.py  (365 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/memory_crystal.py  (492 satır)
  - agent_core/services/memory_injector.py  (157 satır)
  - agent_core/services/message_decision_context.py  (148 satır)
    - agent_core/domain/evidence_models.py  (90 satır)  ↩ (yukarıda görüldü)
    - agent_core/domain/message_context_models.py  (48 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/pillar_evidence_adapter.py  (617 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/psychodynamic_depth.py  (295 satır)
    - agent_core/services/theme_cluster.py  (121 satır)
  - agent_core/services/search_engine.py  (339 satır)
    - agent_core/capabilities/__init__.py  (67 satır)  ↩ (yukarıda görüldü)
    - agent_core/capabilities/egress.py  (135 satır)  ↩ (yukarıda görüldü)
    - agent_core/capabilities/state.py  (93 satır)  ↩ (yukarıda görüldü)
    - agent_core/utils/security.py  (500 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/tier2_evidence_adapter.py  (161 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/timing_forensics.py  (233 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/uncertainty_engine.py  (347 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/upstream_findings.py  (87 satır)  ↩ (yukarıda görüldü)
  - agent_core/services/vision_analyzer.py  (276 satır)
    - agent_core/capabilities/egress.py  (135 satır)  ↩ (yukarıda görüldü)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
    - agent_core/utils/security.py  (500 satır)  ↩ (yukarıda görüldü)
  - agent_core/shadow/shadow_executor.py  (256 satır)
    - agent_core/agents/mirror_truth.py  (177 satır)  ↩ (yukarıda görüldü)
    - agent_core/agents/pattern_interrupt.py  (250 satır)  ↩ (yukarıda görüldü)
    - agent_core/nlp/dark_nlp.py  (79 satır)
    - agent_core/psychology/dark_triad.py  (123 satır)
      - … (1 içe aktarım daha; derinlik sınırı)
    - agent_core/services/llm_gateway.py  (3241 satır)  ↩ (yukarıda görüldü)
  - agent_core/utils/security.py  (500 satır)  ↩ (yukarıda görüldü)
```

## 2) TAM erişim kümesi — 103 modül (statik importlar, sınırsız derinlik, döngüsüz)

| Modül | Derinlik | Satır | İçe aktarım |
|---|---|---|---|
| `agent_core/task_executor.py` | 0 | 2693 | 46 |
| `agent_core/agents/authenticity_auditor.py` | 1 | 115 | 2 |
| `agent_core/agents/autonomous_verifier.py` | 1 | 966 | 7 |
| `agent_core/agents/cognitive_profiler.py` | 1 | 29 | 2 |
| `agent_core/agents/depth_analyst.py` | 1 | 189 | 2 |
| `agent_core/agents/friction_detector.py` | 1 | 28 | 2 |
| `agent_core/agents/human_behavior.py` | 1 | 540 | 3 |
| `agent_core/agents/interpreter_agent.py` | 1 | 118 | 0 |
| `agent_core/agents/mirror_truth.py` | 1 | 177 | 2 |
| `agent_core/agents/osint_investigator.py` | 1 | 339 | 8 |
| `agent_core/agents/passion_mapper.py` | 1 | 25 | 2 |
| `agent_core/agents/pattern_interrupt.py` | 1 | 250 | 3 |
| `agent_core/agents/resonance_calculator.py` | 1 | 546 | 0 |
| `agent_core/agents/resonance_synthesizer.py` | 1 | 168 | 3 |
| `agent_core/capabilities/egress.py` | 1 | 135 | 1 |
| `agent_core/config_loader.py` | 1 | 101 | 0 |
| `agent_core/domain/evidence_models.py` | 1 | 90 | 1 |
| `agent_core/domain/memory_models.py` | 1 | 183 | 1 |
| `agent_core/domain/message_context_models.py` | 1 | 48 | 2 |
| `agent_core/domain/pipeline_status.py` | 1 | 25 | 0 |
| `agent_core/domain/responsibility.py` | 1 | 242 | 0 |
| `agent_core/engines/pillar_orchestrator.py` | 1 | 70 | 9 |
| `agent_core/schemas/telemetry.py` | 1 | 115 | 0 |
| `agent_core/services/__init__.py` | 1 | 5 | 0 |
| `agent_core/services/agent_status_tracker.py` | 1 | 165 | 1 |
| `agent_core/services/canonical_memory.py` | 1 | 365 | 1 |
| `agent_core/services/change_tracker.py` | 1 | 293 | 0 |
| `agent_core/services/claim_decision_gate.py` | 1 | 204 | 0 |
| `agent_core/services/cognitive_router.py` | 1 | 175 | 0 |
| `agent_core/services/decision_engine.py` | 1 | 139 | 4 |
| `agent_core/services/evidence_timeline.py` | 1 | 118 | 1 |
| `agent_core/services/follower_audit.py` | 1 | 117 | 0 |
| `agent_core/services/hindsight_memory.py` | 1 | 334 | 1 |
| `agent_core/services/llm_gateway.py` | 1 | 3241 | 8 |
| `agent_core/services/memory_crystal.py` | 1 | 492 | 0 |
| `agent_core/services/memory_injector.py` | 1 | 157 | 0 |
| `agent_core/services/message_decision_context.py` | 1 | 148 | 2 |
| `agent_core/services/pillar_evidence_adapter.py` | 1 | 617 | 4 |
| `agent_core/services/psychodynamic_depth.py` | 1 | 295 | 1 |
| `agent_core/services/search_engine.py` | 1 | 339 | 4 |
| `agent_core/services/tier2_evidence_adapter.py` | 1 | 161 | 1 |
| `agent_core/services/timing_forensics.py` | 1 | 233 | 0 |
| `agent_core/services/uncertainty_engine.py` | 1 | 347 | 1 |
| `agent_core/services/upstream_findings.py` | 1 | 87 | 0 |
| `agent_core/services/vision_analyzer.py` | 1 | 276 | 3 |
| `agent_core/shadow/shadow_executor.py` | 1 | 256 | 5 |
| `agent_core/utils/security.py` | 1 | 500 | 1 |
| `agent_core/agents/target_psyche_profiler.py` | 2 | 310 | 3 |
| `agent_core/capabilities/__init__.py` | 2 | 67 | 4 |
| `agent_core/capabilities/state.py` | 2 | 93 | 1 |
| `agent_core/capabilities/timeline_bridge.py` | 2 | 63 | 3 |
| `agent_core/domain/pillar_models.py` | 2 | 160 | 0 |
| `agent_core/domain/pillar_wave2_models.py` | 2 | 129 | 1 |
| `agent_core/engines/frequency_engine.py` | 2 | 192 | 2 |
| `agent_core/engines/gravity_engine.py` | 2 | 81 | 2 |
| `agent_core/engines/key_engine.py` | 2 | 92 | 2 |
| `agent_core/engines/pulse_engine.py` | 2 | 59 | 2 |
| `agent_core/engines/seismos_engine.py` | 2 | 118 | 2 |
| `agent_core/engines/strata_engine.py` | 2 | 91 | 4 |
| `agent_core/engines/void_engine.py` | 2 | 103 | 1 |
| `agent_core/nlp/dark_nlp.py` | 2 | 79 | 0 |
| `agent_core/psychology/dark_triad.py` | 2 | 123 | 1 |
| `agent_core/safety/__init__.py` | 2 | 32 | 1 |
| `agent_core/scraper/vault_gate.py` | 2 | 212 | 0 |
| `agent_core/services/final_routing_policy.py` | 2 | 354 | 0 |
| `agent_core/services/holehe_scanner.py` | 2 | 263 | 2 |
| `agent_core/services/jury_consensus.py` | 2 | 191 | 0 |
| `agent_core/services/maigret_scanner.py` | 2 | 323 | 1 |
| `agent_core/services/provider_manager.py` | 2 | 853 | 1 |
| `agent_core/services/quota_governor.py` | 2 | 330 | 2 |
| `agent_core/services/quote_guard.py` | 2 | 330 | 1 |
| `agent_core/services/redis_bus.py` | 2 | 165 | 0 |
| `agent_core/services/response_cache.py` | 2 | 396 | 0 |
| `agent_core/services/task_routing_resolver.py` | 2 | 82 | 0 |
| `agent_core/services/theme_cluster.py` | 2 | 121 | 0 |
| `agent_core/services/token_compressor.py` | 2 | 162 | 0 |
| `agent_core/capabilities/base.py` | 3 | 205 | 2 |
| `agent_core/capabilities/policy.py` | 3 | 107 | 0 |
| `agent_core/capabilities/registry.py` | 3 | 234 | 12 |
| `agent_core/capabilities/runner.py` | 3 | 192 | 4 |
| `agent_core/engines/spectrum.py` | 3 | 179 | 0 |
| `agent_core/safety/minor_gate.py` | 3 | 262 | 0 |
| `agent_core/services/maigret_db_refresh.py` | 3 | 461 | 0 |
| `agent_core/services/threshold_calibration.py` | 3 | 449 | 0 |
| `agent_core/capabilities/adapters_company.py` | 4 | 344 | 4 |
| `agent_core/capabilities/adapters_jury.py` | 4 | 139 | 3 |
| `agent_core/capabilities/adapters_language.py` | 4 | 167 | 5 |
| `agent_core/capabilities/adapters_media.py` | 4 | 337 | 4 |
| `agent_core/capabilities/adapters_osint.py` | 4 | 273 | 4 |
| `agent_core/capabilities/adapters_report.py` | 4 | 237 | 1 |
| `agent_core/capabilities/adapters_report_factory.py` | 4 | 197 | 4 |
| `agent_core/capabilities/adapters_sensors.py` | 4 | 464 | 3 |
| `agent_core/capabilities/adapters_voice.py` | 4 | 467 | 2 |
| `agent_core/capabilities/adapters_web.py` | 4 | 399 | 7 |
| `agent_core/services/company_recon.py` | 5 | 680 | 3 |
| `agent_core/services/crawl_enricher.py` | 5 | 197 | 1 |
| `agent_core/services/language.py` | 5 | 317 | 0 |
| `agent_core/services/local_jury.py` | 5 | 404 | 2 |
| `agent_core/services/media_forensics.py` | 5 | 630 | 4 |
| `agent_core/services/report_factory.py` | 5 | 487 | 2 |
| `agent_core/services/socid_enricher.py` | 5 | 138 | 2 |
| `agent_core/services/translation.py` | 5 | 236 | 2 |
| `agent_core/services/net_hygiene.py` | 6 | 53 | 0 |

## 3) Yürütücünün DOĞRUDAN çağırdığı modüller

```
agent_core/agents/authenticity_auditor.py  (115 satır)
agent_core/agents/autonomous_verifier.py  (966 satır)
agent_core/agents/cognitive_profiler.py  (29 satır)
agent_core/agents/depth_analyst.py  (189 satır)
agent_core/agents/friction_detector.py  (28 satır)
agent_core/agents/human_behavior.py  (540 satır)
agent_core/agents/interpreter_agent.py  (118 satır)
agent_core/agents/mirror_truth.py  (177 satır)
agent_core/agents/osint_investigator.py  (339 satır)
agent_core/agents/passion_mapper.py  (25 satır)
agent_core/agents/pattern_interrupt.py  (250 satır)
agent_core/agents/resonance_calculator.py  (546 satır)
agent_core/agents/resonance_synthesizer.py  (168 satır)
agent_core/capabilities/egress.py  (135 satır)
agent_core/config_loader.py  (101 satır)
agent_core/domain/evidence_models.py  (90 satır)
agent_core/domain/memory_models.py  (183 satır)
agent_core/domain/message_context_models.py  (48 satır)
agent_core/domain/pipeline_status.py  (25 satır)
agent_core/domain/responsibility.py  (242 satır)
agent_core/engines/pillar_orchestrator.py  (70 satır)
agent_core/schemas/telemetry.py  (115 satır)
agent_core/services/__init__.py  (5 satır)
agent_core/services/agent_status_tracker.py  (165 satır)
agent_core/services/canonical_memory.py  (365 satır)
agent_core/services/change_tracker.py  (293 satır)
agent_core/services/claim_decision_gate.py  (204 satır)
agent_core/services/cognitive_router.py  (175 satır)
agent_core/services/decision_engine.py  (139 satır)
agent_core/services/evidence_timeline.py  (118 satır)
agent_core/services/follower_audit.py  (117 satır)
agent_core/services/hindsight_memory.py  (334 satır)
agent_core/services/llm_gateway.py  (3241 satır)
agent_core/services/memory_crystal.py  (492 satır)
agent_core/services/memory_injector.py  (157 satır)
agent_core/services/message_decision_context.py  (148 satır)
agent_core/services/pillar_evidence_adapter.py  (617 satır)
agent_core/services/psychodynamic_depth.py  (295 satır)
agent_core/services/search_engine.py  (339 satır)
agent_core/services/tier2_evidence_adapter.py  (161 satır)
agent_core/services/timing_forensics.py  (233 satır)
agent_core/services/uncertainty_engine.py  (347 satır)
agent_core/services/upstream_findings.py  (87 satır)
agent_core/services/vision_analyzer.py  (276 satır)
agent_core/shadow/shadow_executor.py  (256 satır)
agent_core/utils/security.py  (500 satır)
```

## 4) Kim kimi çağırıyor — ters yön (import edenler)

| Modül | Import eden |
|---|---|
| `agent_core/__init__.py` | tests/audit/test_support_flow_acceptance.py, tests/unit/test_egress_single_spine.py, tests/unit/test_p1_5_scraper_errors.py |
| `agent_core/agents/authenticity_auditor.py` | agent_core/task_executor.py, scripts/archive/flow_roentgen.py, tests/audit/test_boss7_b9_wiring.py, tests/unit/test_authenticity_auditor.py, tests/unit/test_final_spec_compliance.py, tests/unit/test_p1_1_unavailable_contract.py |
| `agent_core/agents/autonomous_verifier.py` | agent_core/task_executor.py, tests/integration/test_claim_gate_executor.py, tests/integration/test_depth_verification_trace_executor.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/integration/test_resonance_executor_signature.py, tests/unit/test_jury_consensus_faz_b.py, tests/unit/test_model_chains.py |
| `agent_core/agents/cognitive_profiler.py` | agent_core/task_executor.py, tests/unit/test_cognitive_profiler.py, tests/unit/test_p1_1_unavailable_contract.py |
| `agent_core/agents/depth_analyst.py` | agent_core/task_executor.py, scripts/archive/flow_roentgen.py, tests/integration/test_agent_rack_wiring.py, tests/integration/test_claim_gate_executor.py, tests/integration/test_depth_verification_trace_executor.py, tests/integration/test_task_executor_flow.py, tests/unit/test_depth_analyst_verification_context.py, tests/unit/test_depth_failure_wiring.py |
| `agent_core/agents/friction_detector.py` | agent_core/task_executor.py, tests/unit/test_friction_detector.py, tests/unit/test_p1_1_unavailable_contract.py |
| `agent_core/agents/human_behavior.py` | agent_core/task_executor.py, scripts/archive/flow_roentgen.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/integration/test_resonance_executor_signature.py, tests/integration/test_task_executor_flow.py, tests/unit/test_final_spec_compliance.py, tests/unit/test_human_behavior.py |
| `agent_core/agents/interpreter_agent.py` | agent_core/task_executor.py, tests/test_interpreter_agent.py, tests/unit/test_p1_6_interpreter_registry.py |
| `agent_core/agents/mirror_truth.py` | agent_core/shadow/shadow_executor.py, agent_core/task_executor.py, scripts/archive/flow_roentgen.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/integration/test_resonance_executor_signature.py, tests/unit/test_config_contract.py, tests/unit/test_final_spec_compliance.py |
| `agent_core/agents/osint_investigator.py` | agent_core/task_executor.py, tests/audit/test_support_flow_acceptance.py, tests/unit/test_config_contract.py, tests/unit/test_holehe_scanner.py, tests/unit/test_maigret_scanner.py, tests/unit/test_minor_gate_api.py, tests/unit/test_osint_investigator.py |
| `agent_core/agents/passion_mapper.py` | agent_core/task_executor.py, tests/integration/test_live_fixes_2026_09.py, tests/unit/test_passion_mapper.py |
| `agent_core/agents/pattern_interrupt.py` | agent_core/shadow/shadow_executor.py, agent_core/task_executor.py, main.py, scripts/archive/flow_roentgen.py, tests/integration/test_claim_gate_executor.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/integration/test_resonance_executor_signature.py |
| `agent_core/agents/resonance_calculator.py` | agent_core/task_executor.py, tests/integration/test_resonance_executor_signature.py, tests/unit/test_authentic_vector_unavailable.py, tests/unit/test_no_decision_run_status.py, tests/unit/test_p0_repairs.py, tests/unit/test_p1_7_pydantic_v2.py, tests/unit/test_resonance.py, tests/unit/test_resonance_vector_provenance.py |
| `agent_core/agents/resonance_synthesizer.py` | agent_core/task_executor.py, scripts/archive/flow_roentgen.py, tests/unit/test_model_chains.py, tests/unit/test_resonance_synthesizer.py |
| `agent_core/agents/target_psyche_profiler.py` | agent_core/agents/cognitive_profiler.py, agent_core/agents/friction_detector.py, agent_core/agents/passion_mapper.py, scripts/archive/flow_roentgen.py |
| `agent_core/aspasia/aspasia_chief.py` | backend/api.py, scripts/archive/test_e2e_fixture.py, tests/integration/test_aspasia_chief.py, tests/integration/test_taste_filter_api_faz_c.py, tests/unit/test_aspasia_chief_layer.py, tests/unit/test_aspasia_depth_hukmu.py, tests/unit/test_aspasia_promotion.py, tests/unit/test_aspasia_state_consistency.py |
| `agent_core/aspasia/interface.py` | agent_core/aspasia/aspasia_chief.py, backend/api.py, tests/audit/test_round3_residue_findings.py, tests/unit/test_aspasia_chief_layer.py, tests/unit/test_aspasia_depth_hukmu.py, tests/unit/test_aspasia_promotion.py, tests/unit/test_aspasia_state_consistency.py, tests/unit/test_multi_provider_routing.py |
| `agent_core/capabilities/__init__.py` | agent_core/agents/osint_investigator.py, agent_core/services/platform_registry.py, agent_core/services/search_engine.py, backend/api.py, scripts/export_skills.py, tests/audit/test_support_flow_acceptance.py, tests/integration/test_mcp_api_status_faz_d.py, tests/integration/test_media_api_faz_d.py |
| `agent_core/capabilities/adapters_osint.py` | agent_core/capabilities/adapters_company.py, agent_core/capabilities/adapters_language.py, agent_core/capabilities/adapters_media.py, agent_core/capabilities/adapters_report_factory.py, agent_core/capabilities/adapters_sensors.py, agent_core/capabilities/adapters_web.py, agent_core/capabilities/registry.py, tests/unit/test_capability_spine_faz0.py |
| `agent_core/capabilities/adapters_sensors.py` | agent_core/capabilities/registry.py, tests/unit/test_retina_faz_a.py, tests/unit/test_retina_faz_a_wiring.py |
| `agent_core/capabilities/adapters_voice.py` | agent_core/capabilities/registry.py, agent_core/services/speech.py, backend/api.py, tests/unit/test_speech_faz_c.py |
| `agent_core/capabilities/adapters_web.py` | agent_core/capabilities/registry.py, backend/api.py, tests/unit/test_crawl_enricher.py, tests/unit/test_language_capabilities.py, tests/unit/test_retina_faz_a.py, tests/unit/test_retina_faz_a_wiring.py |
| `agent_core/capabilities/base.py` | agent_core/capabilities/__init__.py, agent_core/capabilities/adapters_company.py, agent_core/capabilities/adapters_jury.py, agent_core/capabilities/adapters_language.py, agent_core/capabilities/adapters_media.py, agent_core/capabilities/adapters_osint.py, agent_core/capabilities/adapters_report.py, agent_core/capabilities/adapters_report_factory.py |
| `agent_core/capabilities/egress.py` | agent_core/agents/human_behavior.py, agent_core/agents/lilith_growth.py, agent_core/capabilities/adapters_sensors.py, agent_core/capabilities/adapters_voice.py, agent_core/services/company_recon.py, agent_core/services/holehe_scanner.py, agent_core/services/llm_gateway.py, agent_core/services/local_jury.py |
| `agent_core/capabilities/policy.py` | agent_core/capabilities/__init__.py, agent_core/capabilities/registry.py, agent_core/capabilities/runner.py, agent_core/capabilities/state.py, agent_core/mcp/server.py, agent_core/mcp/state_bridge.py, agent_core/mcp/status.py, agent_core/services/speech.py |
| `agent_core/capabilities/registry.py` | agent_core/capabilities/__init__.py, agent_core/capabilities/runner.py, agent_core/mcp/server.py, agent_core/mcp/status.py, agent_core/mcp/tools.py, agent_core/services/speech.py, backend/api.py, backend/routes/language.py |
| `agent_core/capabilities/runner.py` | agent_core/capabilities/__init__.py, agent_core/capabilities/adapters_web.py, agent_core/mcp/server.py, agent_core/services/speech.py, backend/api.py, backend/routes/language.py, tests/integration/test_mcp_api_status_faz_d.py, tests/integration/test_media_api_faz_d.py |
| `agent_core/capabilities/state.py` | agent_core/agents/osint_investigator.py, agent_core/mcp/state_bridge.py, agent_core/services/platform_registry.py, agent_core/services/search_engine.py, backend/api.py, tests/unit/test_retina_faz_a_wiring.py |
| `agent_core/chat/dialogue_manager.py` | backend/api.py, tests/audit/test_production_audit_findings.py, tests/test_system_modules.py |
| `agent_core/config_loader.py` | agent_core/services/decision_engine.py, agent_core/services/uncertainty_engine.py, agent_core/task_executor.py, tests/audit/test_boss8_agent_timeout.py, tests/unit/test_config_contract.py, tests/unit/test_decision_engine.py, tests/unit/test_decision_engine_degraded.py, tests/unit/test_no_decision_run_status.py |
| `agent_core/domain/evidence_models.py` | agent_core/agents/autonomous_verifier.py, agent_core/capabilities/base.py, agent_core/capabilities/timeline_bridge.py, agent_core/domain/message_context_models.py, agent_core/services/evidence_timeline.py, agent_core/services/message_decision_context.py, agent_core/services/pillar_evidence_adapter.py, agent_core/services/report_factory.py |
| `agent_core/domain/memory_models.py` | agent_core/agents/cognitive_profiler.py, agent_core/agents/friction_detector.py, agent_core/agents/passion_mapper.py, agent_core/agents/resonance_synthesizer.py, agent_core/agents/target_psyche_profiler.py, agent_core/aspasia/aspasia_chief.py, agent_core/services/decision_engine.py, agent_core/task_executor.py |
| `agent_core/domain/message_context_models.py` | agent_core/agents/pattern_interrupt.py, agent_core/services/message_decision_context.py, agent_core/task_executor.py |
| `agent_core/domain/pillar_models.py` | agent_core/capabilities/base.py, agent_core/domain/evidence_models.py, agent_core/domain/message_context_models.py, agent_core/domain/pillar_wave2_models.py, agent_core/engines/frequency_engine.py, agent_core/engines/gravity_engine.py, agent_core/engines/key_engine.py, agent_core/engines/pillar_orchestrator.py |
| `agent_core/domain/pillar_wave2_models.py` | agent_core/engines/gravity_engine.py, agent_core/engines/key_engine.py, agent_core/engines/pillar_orchestrator.py, agent_core/engines/pulse_engine.py, agent_core/engines/strata_engine.py, agent_core/services/pillar_evidence_adapter.py, tests/integration/test_task_executor_flow.py, tests/test_pillar_engines.py |
| `agent_core/domain/pipeline_status.py` | agent_core/domain/memory_models.py, agent_core/services/decision_engine.py, agent_core/task_executor.py, backend/api.py, tests/audit/test_boss8_agent_timeout.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/unit/test_aspasia_state_consistency.py |
| `agent_core/engines/frequency_engine.py` | agent_core/engines/pillar_orchestrator.py, agent_core/engines/seismos_engine.py, agent_core/engines/strata_engine.py, agent_core/services/pillar_evidence_adapter.py, tests/test_pillar_engines.py, tests/unit/test_spectrum_faz_b.py |
| `agent_core/engines/gravity_engine.py` | agent_core/engines/pillar_orchestrator.py, tests/test_pillar_engines.py, tests/unit/test_forensic_closers_vault_rack_gravity_carrier.py |
| `agent_core/engines/pillar_orchestrator.py` | agent_core/task_executor.py, tests/integration/test_task_executor_flow.py, tests/test_pillar_engines.py, tests/unit/test_engine_determinism.py, tests/unit/test_pillar_component_failure.py, tests/unit/test_pillar_failure_policy.py |
| `agent_core/engines/void_engine.py` | agent_core/engines/pillar_orchestrator.py, agent_core/engines/strata_engine.py, tests/test_pillar_engines.py |
| `agent_core/mcp/__init__.py` | agent_core/mcp/server.py, backend/api.py, scripts/export_skills.py, tests/integration/test_mcp_api_status_faz_d.py, tests/integration/test_mcp_server_stdio.py, tests/unit/test_export_skills.py, tests/unit/test_mcp_protocol.py, tests/unit/test_mcp_results.py |
| `agent_core/mcp/protocol.py` | agent_core/mcp/__init__.py, agent_core/mcp/server.py, backend/api.py, tests/integration/test_mcp_api_status_faz_d.py, tests/integration/test_mcp_server_stdio.py, tests/unit/test_mcp_protocol.py, tests/unit/test_mcp_results.py, tests/unit/test_mcp_server.py |
| `agent_core/mcp/server.py` | agent_core/mcp/__init__.py, agent_core/mcp/__main__.py, backend/api.py, tests/unit/test_mcp_server.py, tests/unit/test_version_identity.py |
| `agent_core/mcp/state_bridge.py` | agent_core/mcp/server.py, backend/api.py, tests/unit/test_mcp_server.py, tests/unit/test_mcp_state_bridge.py |
| `agent_core/mcp/tools.py` | agent_core/mcp/__init__.py, agent_core/mcp/server.py, backend/api.py, scripts/export_skills.py, tests/integration/test_mcp_api_status_faz_d.py, tests/unit/test_export_skills.py, tests/unit/test_local_jury_capability.py, tests/unit/test_mcp_tools.py |
| `agent_core/psychology/dark_triad.py` | agent_core/shadow/shadow_executor.py, backend/api.py, tests/test_system_modules.py, tests/unit/test_dark_nlp_and_shadow.py, tests/unit/test_final_sweep_honesty.py, tests/unit/test_gorev2_artiklar.py, tests/unit/test_gorev2_depth_engine.py, tests/unit/test_shadow_evidence_gate.py |
| `agent_core/safety/__init__.py` | agent_core/agents/osint_investigator.py, agent_core/capabilities/runner.py, backend/api.py, tests/unit/test_minor_gate_api.py, tests/unit/test_minor_gate_faz0.py |
| `agent_core/safety/minor_gate.py` | agent_core/mcp/state_bridge.py, agent_core/safety/__init__.py, tests/unit/test_mcp_state_bridge.py |
| `agent_core/schemas/telemetry.py` | agent_core/services/task_lifecycle.py, agent_core/task_executor.py, backend/api.py, tests/audit/test_auditor_round2_findings.py, tests/audit/test_support_flow_acceptance.py, tests/unit/test_security_hardening.py, tests/unit/test_task_lifecycle.py |
| `agent_core/scraper/instagram_ghost.py` | agent_core/scraper/run_scraper.py, agent_core/services/platform_registry.py, backend/api.py, tests/audit/test_auditor_round2_findings.py, tests/audit/test_production_audit_findings.py, tests/integration/test_scraper_error_handling.py, tests/test_instagram_ghost.py, tests/test_scrape.py |
| `agent_core/scraper/vault_gate.py` | agent_core/agents/osint_investigator.py, agent_core/capabilities/egress.py, agent_core/scraper/run_scraper.py, agent_core/services/holehe_scanner.py, backend/api.py, tests/audit/test_support_flow_acceptance.py, tests/integration/test_support_cockpit.py, tests/unit/test_egress_single_spine.py |
| `agent_core/services/__init__.py` | agent_core/aspasia/interface.py, agent_core/capabilities/adapters_company.py, agent_core/capabilities/adapters_jury.py, agent_core/capabilities/adapters_language.py, agent_core/capabilities/adapters_media.py, agent_core/capabilities/adapters_report_factory.py, agent_core/capabilities/adapters_web.py, agent_core/services/company_recon.py |
| `agent_core/services/agent_status_tracker.py` | agent_core/task_executor.py, backend/api.py, tests/integration/test_agent_rack_wiring.py, tests/unit/test_agent_worker.py, tests/unit/test_status_source_honesty.py, tests/unit/test_ui_honesty_contract.py |
| `agent_core/services/browser_session.py` | backend/api.py, tests/unit/test_minor_gate_api.py, tests/unit/test_vault_egress_lock.py |
| `agent_core/services/canonical_memory.py` | agent_core/services/hindsight_memory.py, agent_core/task_executor.py, tests/audit/test_production_audit_findings.py, tests/integration/test_canonical_memory.py, tests/integration/test_critical_paths.py, tests/integration/test_live_fixes_2026_09.py, tests/integration/test_resonance_executor_signature.py, tests/unit/test_aspasia_chief_layer.py |
| `agent_core/services/change_tracker.py` | agent_core/task_executor.py, backend/api.py, tests/unit/test_change_tracker_faz_b.py |
| `agent_core/services/claim_decision_gate.py` | agent_core/agents/autonomous_verifier.py, agent_core/task_executor.py, tests/integration/test_claim_gate_executor.py, tests/integration/test_depth_verification_trace_executor.py, tests/unit/test_claim_decision_gate.py |
| `agent_core/services/cognitive_router.py` | agent_core/aspasia/interface.py, agent_core/task_executor.py, tests/integration/test_task_executor_flow.py, tests/unit/test_aspasia_chief_layer.py, tests/unit/test_osint_execution_ownership.py, tests/unit/test_p1_6_interpreter_registry.py, tests/unit/test_router_readiness.py |
| `agent_core/services/company_recon.py` | agent_core/capabilities/adapters_company.py, backend/api.py, tests/integration/test_company_api_faz_d.py, tests/unit/test_company_capabilities.py, tests/unit/test_company_recon.py |
| `agent_core/services/crawl_enricher.py` | agent_core/capabilities/adapters_web.py, backend/api.py, tests/unit/test_crawl_enricher.py, tests/unit/test_experimental_engine_contract.py, tests/unit/test_language_capabilities.py, tests/unit/test_minor_gate_api.py, tests/unit/test_retina_faz_a_wiring.py |
| `agent_core/services/decision_engine.py` | agent_core/task_executor.py, tests/unit/test_decision_engine.py, tests/unit/test_decision_engine_degraded.py, tests/unit/test_no_decision_run_status.py, tests/unit/test_shadow_evidence_gate.py |
| `agent_core/services/evidence_timeline.py` | agent_core/capabilities/timeline_bridge.py, agent_core/services/report_factory.py, agent_core/task_executor.py, tests/integration/test_task_executor_flow.py, tests/unit/test_evidence_timeline.py, tests/unit/test_message_decision_context.py, tests/unit/test_tier2_evidence_adapter.py |
| `agent_core/services/final_routing_policy.py` | agent_core/aspasia/interface.py, agent_core/services/llm_gateway.py, agent_core/services/quota_governor.py, agent_core/services/routed_chat.py, scripts/archive/live_provider_probe.py, tests/unit/test_final_routing_policy.py, tests/unit/test_final_spec_compliance.py, tests/unit/test_google_gemini_direct.py |
| `agent_core/services/follower_audit.py` | agent_core/task_executor.py, tests/unit/test_depth_and_forensics.py, tests/unit/test_glue_forensics_wiring.py, tests/unit/test_wiring_follower.py |
| `agent_core/services/hindsight_memory.py` | agent_core/task_executor.py, tests/unit/test_dependency_health.py, tests/unit/test_hindsight_memory.py, tests/unit/test_security_isolation.py |
| `agent_core/services/holehe_scanner.py` | agent_core/agents/osint_investigator.py, agent_core/capabilities/adapters_osint.py, backend/api.py, tests/unit/test_capability_spine_faz0.py, tests/unit/test_consolidation_faz1_5.py, tests/unit/test_experimental_engine_contract.py, tests/unit/test_holehe_scanner.py, tests/unit/test_minor_gate_api.py |
| `agent_core/services/jury_consensus.py` | agent_core/agents/autonomous_verifier.py, agent_core/services/local_jury.py, tests/unit/test_jury_consensus_faz_b.py, tests/unit/test_local_jury.py, tests/unit/test_local_jury_capability.py |
| `agent_core/services/language.py` | agent_core/capabilities/adapters_language.py, agent_core/capabilities/adapters_web.py, agent_core/services/media_forensics.py, agent_core/services/translation.py, backend/routes/language.py, tests/integration/test_language_api_faz_d.py, tests/unit/test_language_capabilities.py, tests/unit/test_language_detect.py |
| `agent_core/services/llm_gateway.py` | agent_core/agents/authenticity_auditor.py, agent_core/agents/autonomous_verifier.py, agent_core/agents/lilith_growth.py, agent_core/agents/mirror_truth.py, agent_core/agents/osint_investigator.py, agent_core/agents/resonance_synthesizer.py, agent_core/agents/target_psyche_profiler.py, agent_core/aspasia/aspasia_chief.py |
| `agent_core/services/local_jury.py` | agent_core/capabilities/adapters_jury.py, backend/api.py, tests/unit/test_local_jury.py |
| `agent_core/services/maigret_scanner.py` | agent_core/agents/osint_investigator.py, agent_core/capabilities/adapters_osint.py, backend/api.py, tests/unit/test_capability_spine_faz0.py, tests/unit/test_consolidation_faz1_5.py, tests/unit/test_experimental_engine_contract.py, tests/unit/test_maigret_db_env.py, tests/unit/test_maigret_scanner.py |
| `agent_core/services/media_forensics.py` | agent_core/capabilities/adapters_media.py, backend/api.py, tests/integration/test_media_api_faz_d.py, tests/unit/test_media_forensics.py |
| `agent_core/services/memory_crystal.py` | agent_core/task_executor.py, backend/api.py, tests/integration/test_memory_crystal_api_faz_b.py, tests/unit/test_memory_crystal_faz_b.py |
| `agent_core/services/memory_injector.py` | agent_core/task_executor.py, tests/integration/test_live_fixes_2026_09.py, tests/unit/test_memory_injector.py |
| `agent_core/services/message_decision_context.py` | agent_core/task_executor.py, tests/integration/test_task_executor_flow.py, tests/unit/test_message_decision_context.py, tests/unit/test_tier2_evidence_adapter.py |
| `agent_core/services/pillar_evidence_adapter.py` | agent_core/agents/autonomous_verifier.py, agent_core/task_executor.py, tests/integration/test_task_executor_flow.py, tests/unit/test_pillar_evidence_adapter.py, tests/unit/test_verifier_dual_mode.py |
| `agent_core/services/platform_registry.py` | backend/api.py, scripts/archive/flow_roentgen.py, scripts/run_task.py, tests/audit/test_auditor_round2_findings.py, tests/audit/test_production_audit_findings.py, tests/audit/test_round3_residue_findings.py, tests/unit/test_gorev1_reel_video_chrono.py, tests/unit/test_resonance_synthesizer.py |
| `agent_core/services/provider_manager.py` | agent_core/services/llm_gateway.py, agent_core/services/quota_governor.py, agent_core/services/routed_chat.py, agent_core/services/unified_router.py, tests/conftest.py, tests/unit/test_aspasia_state_consistency.py, tests/unit/test_final_spec_compliance.py, tests/unit/test_multi_provider_routing.py |
| `agent_core/services/psychodynamic_depth.py` | agent_core/task_executor.py, tests/unit/test_gorev2_artiklar.py, tests/unit/test_gorev2_depth_engine.py |
| `agent_core/services/quota_governor.py` | agent_core/services/llm_gateway.py, agent_core/services/routed_chat.py, tests/unit/test_final_spec_compliance.py, tests/unit/test_quota_governor.py |
| `agent_core/services/quote_guard.py` | agent_core/agents/autonomous_verifier.py, agent_core/agents/depth_analyst.py, tests/unit/test_crawl_enricher.py, tests/unit/test_depth_and_forensics.py, tests/unit/test_depth_verification_trace.py, tests/unit/test_threshold_calibration_faz_b.py |
| `agent_core/services/redis_bus.py` | agent_core/services/agent_status_tracker.py, agent_core/workers/agent_worker.py, tests/unit/test_status_source_honesty.py |
| `agent_core/services/report_factory.py` | agent_core/capabilities/adapters_report_factory.py, backend/api.py, tests/integration/test_report_capabilities.py, tests/unit/test_report_factory.py |
| `agent_core/services/response_cache.py` | agent_core/services/llm_gateway.py, tests/audit/test_production_audit_findings.py, tests/integration/test_live_fixes_2026_09.py, tests/unit/test_response_cache.py |
| `agent_core/services/routed_chat.py` | backend/api.py, tests/e2e/test_openai_compatibility.py, tests/unit/test_routed_chat.py, tests/unit/test_routing_cost_firewall.py |
| `agent_core/services/search_engine.py` | agent_core/task_executor.py, tests/audit/test_support_flow_acceptance.py, tests/integration/test_holistic_e2e.py, tests/integration/test_p2_release_gate.py, tests/test_six_stamps_integration.py, tests/unit/test_alternative_web_research.py, tests/unit/test_crawl_enricher.py, tests/unit/test_depth_and_forensics.py |
| `agent_core/services/socid_enricher.py` | agent_core/capabilities/adapters_osint.py, backend/api.py, tests/unit/test_capability_spine_faz0.py, tests/unit/test_experimental_engine_contract.py, tests/unit/test_gather_contract.py, tests/unit/test_minor_gate_api.py, tests/unit/test_socid_enricher.py |
| `agent_core/services/speech.py` | backend/api.py, tests/unit/test_speech_faz_c.py, tests/unit/test_speech_report_faz_c.py |
| `agent_core/services/stealth_provider.py` | agent_core/services/platform_registry.py, backend/api.py, tests/unit/test_stealth_provider.py |
| `agent_core/services/task_lifecycle.py` | backend/api.py, tests/audit/test_auditor_round2_findings.py, tests/unit/test_task_lifecycle.py |
| `agent_core/services/task_routing_resolver.py` | agent_core/services/llm_gateway.py, tests/unit/test_frontend_agent_model_contract.py, tests/unit/test_task_routing_step1.py |
| `agent_core/services/taste_filter.py` | agent_core/aspasia/aspasia_chief.py, backend/api.py, tests/integration/test_taste_filter_api_faz_c.py, tests/unit/test_taste_filter_faz_c.py |
| `agent_core/services/theme_cluster.py` | agent_core/psychology/dark_triad.py, agent_core/services/psychodynamic_depth.py, tests/unit/test_gorev2_depth_engine.py |
| `agent_core/services/threshold_calibration.py` | agent_core/services/quote_guard.py, agent_core/services/taste_filter.py, backend/api.py, tests/integration/test_calibration_api_faz_b.py, tests/unit/test_threshold_calibration_faz_b.py |
| `agent_core/services/tier2_evidence_adapter.py` | agent_core/agents/autonomous_verifier.py, agent_core/task_executor.py, tests/integration/test_claim_gate_executor.py, tests/unit/test_tier2_evidence_adapter.py |
| `agent_core/services/timing_forensics.py` | agent_core/agents/pattern_interrupt.py, agent_core/task_executor.py, tests/unit/test_depth_and_forensics.py, tests/unit/test_gorev2_depth_engine.py |
| `agent_core/services/translation.py` | agent_core/capabilities/adapters_language.py, backend/routes/language.py, tests/unit/test_language_capabilities.py, tests/unit/test_translation_local.py |
| `agent_core/services/uncertainty_engine.py` | agent_core/services/decision_engine.py, agent_core/task_executor.py, tests/audit/test_support_flow_acceptance.py, tests/integration/test_resonance_executor_signature.py, tests/integration/test_support_cockpit.py, tests/unit/test_evidence_hash_and_fallback_gate.py, tests/unit/test_no_decision_run_status.py, tests/unit/test_p0_repairs.py |
| `agent_core/services/unified_router.py` | agent_core/services/routed_chat.py, backend/api.py, tests/unit/test_routed_chat.py, tests/unit/test_unified_router.py |
| `agent_core/services/upstream_findings.py` | agent_core/agents/authenticity_auditor.py, agent_core/agents/depth_analyst.py, agent_core/agents/human_behavior.py, agent_core/agents/mirror_truth.py, agent_core/agents/pattern_interrupt.py, agent_core/agents/resonance_synthesizer.py, agent_core/agents/target_psyche_profiler.py, agent_core/task_executor.py |
| `agent_core/services/vision_analyzer.py` | agent_core/task_executor.py, tests/unit/test_vision_analyzer.py, tests/unit/test_vision_analyzer_gate.py, tests/unit/test_wave3_honesty_contracts.py |
| `agent_core/shadow/shadow_executor.py` | agent_core/task_executor.py, backend/api.py, tests/audit/test_boss7_b9_wiring.py, tests/integration/test_claim_gate_executor.py, tests/unit/test_config_contract.py, tests/unit/test_dark_nlp_and_shadow.py, tests/unit/test_final_sweep_honesty.py, tests/unit/test_glue_forensics_wiring.py |
| `agent_core/task_executor.py` | backend/api.py, backend/routes/support.py, live_llm_gate.py, main.py, scripts/archive/analyze_target_instagram.py, scripts/archive/benchmark_download.py, scripts/archive/e2e_test.py, scripts/archive/test_e2e_fixture.py |
| `agent_core/utils/security.py` | agent_core/agents/human_behavior.py, agent_core/capabilities/adapters_web.py, agent_core/services/canonical_memory.py, agent_core/services/crawl_enricher.py, agent_core/services/provider_manager.py, agent_core/services/search_engine.py, agent_core/services/socid_enricher.py, agent_core/services/vision_analyzer.py |
| `agent_core/version.py` | agent_core/mcp/server.py, backend/api.py, tests/unit/test_version_identity.py |
| `backend/api.py` | scripts/archive/flow_roentgen.py, tests/audit/test_auditor_round2_findings.py, tests/audit/test_boss11_frame_contract.py, tests/audit/test_boss2_ghost_task_lock.py, tests/audit/test_boss8_agent_timeout.py, tests/audit/test_production_audit_findings.py, tests/audit/test_round3_residue_findings.py, tests/conftest.py |
| `backend/security/principal.py` | backend/api.py, backend/routes/websocket.py, tests/unit/test_room_ownership_idor.py |
| `backend/security/task_access.py` | backend/api.py, backend/routes/support.py, backend/routes/tasks.py |
| `backend/security/task_ownership.py` | backend/api.py, backend/routes/support.py, backend/routes/tasks.py, backend/security/task_access.py, tests/unit/test_task_ownership.py |

## 5) Dinamik çağrı izleri (statik import ile görünmeyen bağlar)

- `agent_core/capabilities/adapters_osint.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `agent_core/services/dependency_health.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `agent_core/services/hindsight_memory.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `agent_core/services/report_factory.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `agent_core/services/stealth_provider.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `backend/api.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/integration/test_calibration_api_faz_b.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_audit_regression.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_consolidation_faz1_5.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_engine_determinism.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_export_skills.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_frontend_agent_model_contract.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_intervention_safety.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_inventory_page.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_no_mock_in_production.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_retina_faz_a.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.
- `tests/unit/test_routing_shadows.py`: dinamik import kullanıyor → statik grafikte hedefi görünmez.